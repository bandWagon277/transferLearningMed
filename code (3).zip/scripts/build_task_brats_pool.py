"""Build Task550_BraTS_AllMRI from BraTS21 + BraTS24 fold-0 TRAIN cases only.

The fold-0 val cases from BOTH source tasks are excluded so that downstream
evaluations of pool->BraTS21 and pool->BraTS24 on each task's fold-0 val
set stay free of train-time leakage.

After this script, run nnU-Net plan_and_preprocess on Task550.
"""
from __future__ import annotations
import json, os, pickle, sys

REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
RAW = f'{REPO}/data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data'
PRE = f'{REPO}/data/nnUNet/nnUNet_preprocessed'

SRC500 = f'{RAW}/Task500_BraTS2021'
SRC502 = f'{RAW}/Task502_BraTS2024Post'
DST = f'{RAW}/Task550_BraTS_AllMRI'

os.makedirs(f'{DST}/imagesTr', exist_ok=True)
os.makedirs(f'{DST}/labelsTr', exist_ok=True)


def fold0_train(task):
    s = pickle.load(open(f'{PRE}/{task}/splits_final.pkl', 'rb'))
    return list(s[0]['train'])


def link(src, dst):
    if not os.path.lexists(dst):
        os.symlink(src, dst)


train_500 = fold0_train('Task500_BraTS2021')
train_502 = fold0_train('Task502_BraTS2024Post')
print(f'Task500 fold-0 train: {len(train_500)}')
print(f'Task502 fold-0 train: {len(train_502)}')

n = 0
training_entries = []
for cid in train_500:
    src_img = f'{SRC500}/imagesTr/{cid}_0000.nii.gz'
    src_lbl = f'{SRC500}/labelsTr/{cid}.nii.gz'
    if not (os.path.exists(src_img) and os.path.exists(src_lbl)):
        continue
    link(src_img, f'{DST}/imagesTr/{cid}_0000.nii.gz')
    link(src_lbl, f'{DST}/labelsTr/{cid}.nii.gz')
    training_entries.append({'image': f'./imagesTr/{cid}.nii.gz',
                             'label': f'./labelsTr/{cid}.nii.gz'})
    n += 1

for cid in train_502:
    src_img = f'{SRC502}/imagesTr/{cid}_0000.nii.gz'
    src_lbl = f'{SRC502}/labelsTr/{cid}.nii.gz'
    if not (os.path.exists(src_img) and os.path.exists(src_lbl)):
        continue
    link(src_img, f'{DST}/imagesTr/{cid}_0000.nii.gz')
    link(src_lbl, f'{DST}/labelsTr/{cid}.nii.gz')
    training_entries.append({'image': f'./imagesTr/{cid}.nii.gz',
                             'label': f'./labelsTr/{cid}.nii.gz'})
    n += 1

print(f'Total linked: {n}')

dataset = {
    'name': 'Task550_BraTS_AllMRI',
    'description': ('Pool of BraTS21 + BraTS24 GLI Post-Treatment clean cohort '
                    'fold-0 TRAIN cases (val cases held out from BOTH source '
                    'splits to keep downstream pool->BraTS21 and pool->BraTS24 '
                    'evaluations honest).'),
    'reference': 'BraTS 2021 + BraTS 2024 Adult Glioma Post-Treatment',
    'licence': 'CC-BY-NC',
    'release': '1.0 (2026-06-22)',
    'tensorImageSize': '4D',
    'modality': {'0': 'FLAIR'},
    'labels': {'0': 'background', '1': 'tumor'},
    'numTraining': n,
    'numTest': 0,
    'training': training_entries,
    'test': []
}
with open(f'{DST}/dataset.json', 'w') as f:
    json.dump(dataset, f, indent=2)
print(f'Wrote {DST}/dataset.json with {n} training cases.')
