"""K=5 seed CKA trajectory + scratch-trajectory comparator.

For each cell in {MSD->BraTS/full, MSD->BraTS/freeze1} and the BraTS-scratch
baseline, load all available seeds and compute layer-wise CKA at each saved
intermediate checkpoint against the SAME reference source f_S_MSD.

Outputs:
  runs/cka_kseed_trajectory_0612.json  -- per-seed CKA at each layer/epoch
                                          plus aggregate mean / std per layer/epoch

The companion plotter (posthoc_kseed_trajectory_0612.py) renders a band per
cell with FT band overlaid on scratch band per layer.

Three runs per cell are expected to map to the same epoch grid (20, 40, 60,
80, 100, best). Seeds that ended early (early-stop before epoch 100) have
fewer intermediate ckpts and contribute only to the epochs they have.
"""
from __future__ import annotations
import glob
import json
import os
import re
import sys

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

import numpy as np  # noqa: E402

from affinity import (  # noqa: E402
    DatasetSpec, list_cases, linear_cka, _extract_layer_ladder_features,
)

REPO = os.path.dirname(THIS)
N_PROBES = 40

F_S_MSD = os.path.join(REPO,
    'code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt')

# Map each cell -> list of (seed_label, run_dir). Existing seed-42 v1/freeze1
# runs are reused so we get K=5 with only 4 new seeds per cell.
CELL_RUNS = {
    'MSD_to_BraTS/full': [
        ('seed42', 'code/pretrained/brats_flair_pretrain/brats_from_msd_v1'),
        ('seed1',  'code/pretrained/brats_flair_pretrain/brats_from_msd_seed1'),
        ('seed2',  'code/pretrained/brats_flair_pretrain/brats_from_msd_seed2'),
        ('seed3',  'code/pretrained/brats_flair_pretrain/brats_from_msd_seed3'),
        ('seed4',  'code/pretrained/brats_flair_pretrain/brats_from_msd_seed4'),
    ],
    'MSD_to_BraTS/freeze1': [
        ('seed42', 'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze1'),
        ('seed1',  'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze1_seed1'),
        ('seed2',  'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze1_seed2'),
        ('seed3',  'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze1_seed3'),
        ('seed4',  'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze1_seed4'),
    ],
    # Scratch BraTS = "training-noise trajectory" baseline. CKA against the
    # same f_S_MSD reference. At every epoch, this measures "how much does
    # a target-trained scratch model accidentally resemble the source?"
    'BraTS_scratch': [
        ('seed0', 'code/pretrained/brats_flair_pretrain/brats_vanilla_seed0'),
        ('seed1', 'code/pretrained/brats_flair_pretrain/brats_vanilla_seed1'),
        ('seed2', 'code/pretrained/brats_flair_pretrain/brats_vanilla_seed2'),
        ('seed3', 'code/pretrained/brats_flair_pretrain/brats_vanilla_seed3'),
        ('seed4', 'code/pretrained/brats_flair_pretrain/brats_vanilla_seed4'),
    ],
}


def _gather_probes(layout: str, root: str, n: int) -> list[str]:
    spec = DatasetSpec(name='probe', root=root, layout=layout)
    cases = list_cases(spec)
    rng = np.random.default_rng(42)
    idx = rng.permutation(len(cases))[:n]
    return [cases[i]['image'] for i in sorted(idx.tolist())]


def _list_ckpts(run_dir: str) -> list[tuple[int | None, str]]:
    """Return [(epoch_or_None, path)]. None = 'best' (validation-selected)."""
    ckpts = []
    for p in sorted(glob.glob(os.path.join(run_dir, 'checkpoint_epoch_*.pt'))):
        m = re.match(r'checkpoint_epoch_0*(\d+)\.pt', os.path.basename(p))
        if m:
            ckpts.append((int(m.group(1)), p))
    best = os.path.join(run_dir, 'best.pt')
    if os.path.exists(best):
        ckpts.append((None, best))
    return ckpts


def main():
    out_path = os.path.join(REPO, 'runs/cka_kseed_trajectory_0612.json')
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    brats_probes = _gather_probes('brats_flair',
        os.path.join(REPO, 'data/BraTS2021_Training'), N_PROBES)
    print(f'[probes] {len(brats_probes)} BraTS')

    feats_s = _extract_layer_ladder_features(
        ckpt_path=F_S_MSD, probe_paths=brats_probes,
        in_channels=1, out_channels=1, layout='brats_flair',
    )
    layers = list(feats_s.keys())

    out = {
        'f_s': F_S_MSD,
        'n_probes': N_PROBES,
        'probe_paths': brats_probes,
        'layers': layers,
        'per_seed': {},          # cell -> seed_label -> [{epoch, cka_per_layer}]
        'aggregate': {},         # cell -> epoch -> {layer: {mean, std, k}}
    }

    for cell, seed_specs in CELL_RUNS.items():
        out['per_seed'][cell] = {}
        epoch_table = {}  # epoch (int or 'best') -> layer -> [cka, cka, ...]
        for seed_label, rel in seed_specs:
            run_dir = os.path.join(REPO, rel)
            if not os.path.isdir(run_dir):
                print(f'[skip] {cell} {seed_label}: {run_dir} missing')
                continue
            ckpts = _list_ckpts(run_dir)
            if not ckpts:
                print(f'[skip] {cell} {seed_label}: no ckpts in {run_dir}')
                continue
            entries = []
            for ep, ck in ckpts:
                feats_t = _extract_layer_ladder_features(
                    ckpt_path=ck, probe_paths=brats_probes,
                    in_channels=1, out_channels=1, layout='brats_flair',
                )
                per_layer = {L: float(linear_cka(feats_s[L], feats_t[L]))
                             for L in layers}
                entries.append({'epoch': ep,
                                'ckpt_name': os.path.basename(ck),
                                'cka_per_layer': per_layer})
                key = 'best' if ep is None else ep
                slot = epoch_table.setdefault(key, {L: [] for L in layers})
                for L in layers:
                    slot[L].append(per_layer[L])
                print(f'[{cell} {seed_label}] ep={ep!s:>4}: '
                      + ' '.join(f'{L.split("_")[0]}={per_layer[L]:.3f}'
                                 for L in layers))
            out['per_seed'][cell][seed_label] = entries

        # Aggregate per epoch
        agg = {}
        for key, layer_map in epoch_table.items():
            agg[str(key)] = {L: {
                'mean': float(np.mean(v)),
                'std':  float(np.std(v, ddof=1)) if len(v) > 1 else 0.0,
                'k':    len(v),
            } for L, v in layer_map.items()}
        out['aggregate'][cell] = agg

    with open(out_path, 'w') as f:
        json.dump(out, f, indent=2)
    print(f'\n[saved] {out_path}')

    for cell, agg in out['aggregate'].items():
        print(f'\n=== {cell} (K={max(len(v) for v in CELL_RUNS.values())}) ===')
        # sort epochs (ints first, then 'best')
        keys = sorted([k for k in agg if k != 'best'], key=int) + (
            ['best'] if 'best' in agg else [])
        header = ['epoch'] + [L.split('_')[0] for L in layers]
        print(' '.join(f'{h:>14}' for h in header))
        for k in keys:
            row = [k]
            for L in layers:
                m = agg[k][L]
                row.append(f"{m['mean']:.3f}±{m['std']:.3f}")
            print(' '.join(f'{x:>14}' for x in row))


if __name__ == '__main__':
    main()
