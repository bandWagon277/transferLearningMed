"""Training entry point for the transfer-learning ablation.

CLI surface mirrors the experimental sweep axes in meet/training_plan_0513.md:

  python train.py \
      --init {random,brain,lung} --pretrained-ckpt <path-or-empty> \
      --freeze {none,encoder,encoder_bottleneck,all_but_head} \
      --train-frac 0.10 \
      --epochs 200 --batch-size 2 \
      --out runs/init-brain_freeze-encoder_frac-0.10

Sliding-window validation, Dice per region (TC, WT, ET), best-Dice
checkpoint, JSONL metrics log. Designed to be launched via Slurm — see
code/submit_train.slurm for the template.
"""
from __future__ import annotations
import argparse, json, os, time
from contextlib import nullcontext

import torch
from monai.data import decollate_batch
from monai.inferers import sliding_window_inference
from monai.losses import DiceCELoss
from monai.metrics import DiceMetric
from monai.transforms import Activations, AsDiscrete

from data import make_loaders
from models import build_model


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--root', default='/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/BraTS2021_Training')
    p.add_argument('--arch', default='segresnet', choices=['segresnet', 'swinunetr', 'unet'])
    p.add_argument('--init', default='random',
                   choices=['random', 'ct_ssl', 'lung_genesis', 'lungtumormask', 'brain'])
    p.add_argument('--pretrained-ckpt', default=None)
    p.add_argument('--freeze', default='none',
                   choices=['none', 'encoder', 'encoder_bottleneck', 'all_but_head'])
    p.add_argument('--train-frac', type=float, default=1.0)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--epochs', type=int, default=200)
    p.add_argument('--batch-size', type=int, default=2)
    p.add_argument('--num-workers', type=int, default=4)
    p.add_argument('--cache-rate', type=float, default=0.0)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--weight-decay', type=float, default=1e-5)
    p.add_argument('--val-every', type=int, default=5)
    p.add_argument('--out', required=True)
    p.add_argument('--amp', action='store_true', default=True)
    p.add_argument('--no-amp', dest='amp', action='store_false',
                   help='Disable mixed precision. Required for init=lungtumormask: '
                        'its conv weights have std~7 (vs Kaiming std~0.02) and the '
                        'level-3 down conv overflows fp16. Diagnosed in v3 collapse — '
                        'see runs/v3_unet_lungtumormask_none_*/.')
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, 'config.json'), 'w') as f:
        json.dump(vars(args), f, indent=2)

    torch.manual_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'[device] {device} ({torch.cuda.get_device_name(0) if device.type=="cuda" else "cpu"})')

    train_loader, val_loader, info = make_loaders(
        root=args.root, batch_size=args.batch_size, num_workers=args.num_workers,
        train_frac=args.train_frac, seed=args.seed, cache_rate=args.cache_rate,
    )
    print(f'[data] n_train={info["n_train"]} n_val={info["n_val"]} of n_total={info["n_total"]}')

    model = build_model(arch=args.arch, in_channels=4, out_channels=3,
                        init=args.init, pretrained_ckpt=args.pretrained_ckpt,
                        freeze=args.freeze).to(device)

    loss_fn = DiceCELoss(sigmoid=True, lambda_dice=1.0, lambda_ce=1.0)
    optim = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
                              lr=args.lr, weight_decay=args.weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=args.epochs)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp and device.type == 'cuda')

    post_pred = Activations(sigmoid=True)
    post_thr  = AsDiscrete(threshold=0.5)
    dice_metric = DiceMetric(include_background=True, reduction='mean_batch')

    best_dice = -1.0
    log_path = os.path.join(args.out, 'metrics.jsonl')
    ckpt_path = os.path.join(args.out, 'best.pt')

    for epoch in range(args.epochs):
        model.train()
        epoch_loss = 0.0
        t0 = time.time()
        for batch in train_loader:
            x = batch['image'].to(device, non_blocking=True)
            y = batch['label'].to(device, non_blocking=True).float()
            optim.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=args.amp and device.type == 'cuda'):
                logits = model(x)
                loss = loss_fn(logits, y)
            if not torch.isfinite(loss):
                raise RuntimeError(
                    f'non-finite loss at epoch={epoch} (loss={loss.item()}). '
                    f'logits stats: min={logits.float().min().item():.3e} '
                    f'max={logits.float().max().item():.3e} '
                    f'has_nan={torch.isnan(logits).any().item()} '
                    f'has_inf={torch.isinf(logits).any().item()}. '
                    f'If init=lungtumormask, retry with --no-amp.')
            scaler.scale(loss).backward()
            scaler.step(optim)
            scaler.update()
            epoch_loss += loss.item()
        sched.step()
        epoch_loss /= max(1, len(train_loader))
        rec = {'epoch': epoch, 'train_loss': epoch_loss, 'epoch_time_s': round(time.time()-t0, 1)}

        # Unconditional checkpoint each epoch so we always have a saved model
        # on disk before the first (slow) validation cycle finishes.
        torch.save({'state_dict': model.state_dict(), 'epoch': epoch,
                    'train_loss': epoch_loss},
                   os.path.join(args.out, 'last.pt'))

        if (epoch + 1) % args.val_every == 0 or epoch == args.epochs - 1:
            model.eval()
            dice_metric.reset()
            with torch.no_grad():
                for vbatch in val_loader:
                    vx = vbatch['image'].to(device, non_blocking=True)
                    vy = vbatch['label'].to(device, non_blocking=True).float()
                    with torch.cuda.amp.autocast(enabled=args.amp and device.type == 'cuda'):
                        vy_logits = sliding_window_inference(vx, roi_size=(128,128,128),
                                                             sw_batch_size=1, predictor=model,
                                                             overlap=0.5)
                    vy_prob = [post_pred(p) for p in decollate_batch(vy_logits)]
                    vy_bin  = [post_thr(p)  for p in vy_prob]
                    dice_metric(y_pred=vy_bin, y=decollate_batch(vy))
            per_region = dice_metric.aggregate().tolist()
            mean_dice  = sum(per_region) / len(per_region)
            rec.update({'val_dice_TC': per_region[0], 'val_dice_WT': per_region[1],
                        'val_dice_ET': per_region[2], 'val_dice_mean': mean_dice})
            if mean_dice > best_dice:
                best_dice = mean_dice
                torch.save({'state_dict': model.state_dict(),
                            'epoch': epoch, 'val_dice': mean_dice}, ckpt_path)
                rec['saved_best'] = True
            # Release cached allocator blocks held over from sliding-window val
            # so the next training step doesn't OOM (this fixed the V100 16GB
            # crashes on SwinUNETR runs).
            if device.type == 'cuda':
                torch.cuda.empty_cache()

        with open(log_path, 'a') as f:
            f.write(json.dumps(rec) + '\n')
        print(json.dumps(rec))

    print(f'[done] best mean Dice = {best_dice:.4f}; checkpoint at {ckpt_path}')


if __name__ == '__main__':
    main()
