# Scripts that produced the saved results

Full inventory of every driver + support library needed to reproduce the
current deliverable, grouped by function.

## Raw data -> NIfTI, per dataset

| Dataset (nnU-Net task) | Raw form | Converter | What it does |
|---|---|---|---|
| BraTS 2021 (Task500)     | already NIfTI, 4 modalities per case | `convert_brats2021_to_nnunet.py` | Pick FLAIR only; binarize `label > 0` -> WT; write nnU-Net layout. |
| BraTS 2024 (Task502)     | already NIfTI, 4 modalities per case | `convert_brats2024_to_nnunet.py` | Same recipe as BraTS21 + drop 38 patients with IDs < 2000 + one canonical post-treatment timepoint per patient. |
| MSD-Lung (Task006)       | already NIfTI (Medical Segmentation Decathlon) | `msd_lung_stage.py` | Rename `<case>.nii.gz` -> `<case>_0000.nii.gz` on the image side; write `dataset.json`. No content transform. |
| MSD-Lung n=51 sweep      | Task006 splits | `build_sweep_splits.py` | Deterministic random subsets of Task006 training cases at n = 8/16/32/51 for the target-size sweep. |
| RIDER Lung CT (Task514)  | zipped DICOM series + DICOM-SEG masks | `dicom_to_nifti_rider.py` | Per patient: extract every CT zip, pick the largest CT series, decode DICOM-SEG mask, resample onto CT grid, save NIfTI + populate Task514. |
| QIN Lung CT DICOM        | DICOM series + separate mask NIfTIs | `dicom_to_nifti_qin.py` | DICOM -> NIfTI via `SimpleITK.ImageSeriesReader`, pair with tumor mask, binarize non-zero labels, drop non-tumor cases. |
| QIN Lung CT (Task512)    | NIfTIs from the step above | `build_task_qin.py` | Filter to the 10 canonical cases + populate Task512. |
| Brain-MRI pool (Task550) | Task500 + Task502 case symlinks | `build_task_brats_pool.py` | Concatenate BraTS21 and BraTS24 training cases into a single pretraining task. |
| Everything pool (Task650)| Task500/502/006/512/514 case symlinks | `build_task_everything_pool.py` | Single-channel grayscale pool of all 5 datasets, CT + MRI treated as one channel. |

Minimal generic DICOM converter for any directory not on this list:

```bash
python scripts/dicom_series_to_nifti.py <dicom_dir> <out.nii.gz>
```

### DICOM-SEG (segmentation) note

A DICOM-SEG is *one* `.dcm` file holding the entire mask, not a series of
slices. The reference decode + resample pattern is in
`dicom_to_nifti_rider.py::decode_seg` (lines ~89-131).

## Production training drivers

Wide versions of the minimal `../training.py`, with K-fold dispatch,
multi-source logic, augmentation knobs, and SLURM-safe checkpoint cleanup.

| Script | What it does |
|---|---|
| `train.py`              | Generic MONAI 3D U-Net trainer entry point. |
| `pretrain_brats_flair.py` | 5-fold BraTS-21 or BraTS-24 scratch training, one modality per run. Referenced by `../README.md`. |
| `pretrain_oktaykurt.py` | 5-fold MSD-Lung scratch / transfer trainer (the oktaykurt UNet recipe). |
| `models.py`             | Model factory with LungTumorMask + Genesis Chest CT + SwinViT CT-SSL initialization sources. Referenced in `../../results.md`. |

## Foundation-model comparison (Q3)

Independent-baseline benchmarks for the LungTumorMask published weights,
which are the concrete audit example in the Q3 chapter.

| Script | What it does |
|---|---|
| `benchmark_lungtumormask_naive.py`                 | v1: dc_student.pth + naive sliding-window over full CT. Uninformative (~0.03 Dice). |
| `benchmark_lungtumormask_authorpipeline.py` | v2-A: dc_student.pth with the authors' own preprocessing (lung-cropped, per-case z-score, 1x1x1.5 mm). |
| `benchmark_lungtumormask_nnunet.py`       | v2-B: dc_student.pth with nnU-Net Task006_Lung preprocessing (global stats, sliding window). |

## CKA + representation analysis

Support library:

| File | What it exposes |
|---|---|
| `affinity.py` | Yang-2024 image/mask affinity, `jon_metric` (diagonal-off-diagonal cosine), `orthohash_metric` (InfoNCE-style). Referenced in `../../results.md`. |

Driver scripts (each reproduces one JSON in `../../data/`, one PNG in `../../figures/`, or both):

| Script | Result it produced |
|---|---|
| `compute_jon_method_pairs.py`           | `data/jon_method_all_pairs_0603.json` + `data/orthohash_all_pairs_0605.json` |
| `run_cka_brats_qin.py`             | `data/cka_before_after_0608.json` |
| `run_cka_brats_msd.py`             | `data/cka_before_after_msd_0608.json` + `data/dice_summary_msd_0608.json` |
| `run_cka_epoch_trajectory.py`      | `data/cka_epoch_trajectory_0611.json` |
| `run_cka_kseed_trajectory.py`      | K-seed scratch-trajectory CKA bands (5 seeds x 4 checkpoints). |
| `run_random_pair_cka.py`           | `data/random_pair_cka_0615.json` |
| `run_cka_finegrid_trajectory.py`   | `data/cka_finegrid_trajectory_0616.json` + `figures/cka_finegrid_trajectory.png` |
| `run_cka_5fold_trajectory.py`      | 5-fold CKA trajectory driver (drives the newer 5-fold band in the deck). |
| `run_cka_norm_probesize.py`        | `data/cka_norm_probesize_0617.json` + `figures/cka_norm_probesize.png` |
| `run_cka_dippattern_compare.py`    | `data/cka_dippattern_compare_0617.json` + `figures/cka_dippattern_compare.png` |
| `run_cka_transunet_attention.py`   | `data/cka_transunet_attention_0617.json` + attention CKA figure. |
| `run_cka_transunet_conv.py`        | `data/cka_transunet_conv_0619.json` + conv-layer CKA figure. |
| `sim_cka_gaussian_probes.py`       | `data/sim_cka_gaussian_probes_0619.json` + `figures/sim_cka_gaussian_probes.png` |
| `posthoc_cka.py`                   | Post-hoc analyses across all CKA JSONs above. |

## Diameter, brightness, and other analytics

| Script | Result it produced |
|---|---|
| `tumor_diameter.py`                     | `deliverable/measurements/<dataset>_diameter.csv` (ground-truth longest 3D diameter per case). |
| `report_pred_diameter.py`          | `deliverable/measurements/pred_diameter_0624/<condition>.csv` (predicted diameter + Dice per case per condition) -- the source data for `meet/email_diameter_0629.md`. |
| `encoder_brightness_bias.py`            | Encoder-brightness-bias-by-percentile analysis. |
| `qin_filter_tumor.py`                   | `data/qin_lung_ct/filter_stats.json` |
| `qin_region_diagnostic.py`              | `runs/figures/qin_train_label_distribution.png` |

## Visualization / rendering

| Script | What it produces |
|---|---|
| `render_dataset_samples.py`              | Per-dataset sample montages. |
| `render_prediction_overlays.py`  | Best/worst prediction overlays used in the deck. |
| `render_brats_msd_orbit_gifs.py`      | The volume-rendered BraTS + MSD-Lung orbit GIFs embedded in Q4 (slide 23). |

## What is *not* copied here

The following live only under `../../code/` on the working filesystem and
were intentionally left out of the deliverable because they are either
one-off data-acquisition scripts, ephemeral diagnostics, or utilities whose
output has already been captured elsewhere:

- **Data acquisition** -- `download_rider_lungct_seg.py`, `download_brats2024_post_treatment.py`, `stack_lgg_to_nifti.py`.
- **Ephemeral diagnostics** -- `diagnose_v3_collapse.py`, `sanity_cka_epoch0.py`, `sanity_cka_gap_vs_spatial_0616.py`, `sanity_cka_trained_pairs_0616.py`, `rider_seg_audit_0624.py`, `extract_dice_msd_0608.py`, `compute_cka_pairs.py`, `run_metric_audit_0611.py`.
- **Deck / plot one-offs** -- `build_best_worst_overlay_0629.py`, `build_questions_figures_0629.py`, `build_deck_pptx_0630.py`, `plot_auc_meetplan.py`, `plot_transfer_curves.py`.
- **Inference / rendering utilities that duplicate the above** -- `render_rider_3d_0626.py`, `render_rider_3d_gallery_0626.py`, `render_rider_overlays_0624.py`, `render_transfer_diff_genericunet.py`, `render_brats_msd_orbit_gifs.py` (v1, superseded by v2), `run_brain_pretrained_inference.py`, `summarize_runs.py`, `visualize_3d.py`, `visualize_predictions.py`.
- **LGG-specific pretrainer** -- `pretrain_lgg.py` (LGG is a candidate 5th encoder slot per Item 3.1; the deliverable does not depend on it yet).
- **`data_generic.py`** -- generic data loader kept only in `../../code/`; the deliverable uses the class-based `../data.py` instead.

Each of the excluded files is a single-file self-contained script; they can
be pulled in on request by copying from `../../code/<name>.py` into this
folder.

## What lives outside this folder

- 3D TransUNet training/inference runs -- see `../TRANSUNET.md` for how they
  are configured; the vendored clone lives at
  `../../code/external/3D-TransUNet/`.
