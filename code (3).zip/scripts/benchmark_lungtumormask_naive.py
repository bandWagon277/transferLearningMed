"""Out-of-the-box benchmark of LungTumorMask (Fredriksen et al. 2022) on our
CT-tumor datasets, compared head-to-head with our trained models.

The Fredriksen et al. checkpoint (`dc_student.pth`) is a MONAI UNet trained on
lung-tumor CT to predict a 1-channel sigmoid tumor mask. We are NOT using it
as a transfer-source init here -- we are running it AS-IS as an independent
baseline. The fair use of the published weights.

Caveats acknowledged upfront:

* The author's full inference pipeline crops the volume to per-lung bounding
  boxes (via the `lungmask` Python package) before running the network. We do
  NOT do that here -- we run sliding-window inference on the full volume.
  Expect their model to underperform its paper numbers by some margin.
* The author trained on MSD Task06 Lung (their primary training set). So
  benchmarking on MSD-Lung is *leaky* for their model; the only truly external
  comparison is RIDER (or other unseen CTs). Both are reported with that flag.
* No test-time augmentation, no ensembling -- raw single-forward inference,
  same as we run our own models in `inference.py`.

Output: deliverable/measurements/lungtumormask_benchmark_0629/<task>.csv
plus a summary.csv. Each row: case, dice, gt_diameter_mm, pred_diameter_mm, ...
"""
from __future__ import annotations
import argparse, csv, json, time
from pathlib import Path
import numpy as np
import nibabel as nib
import torch
from monai.networks.nets import UNet
from monai.inferers import SlidingWindowInferer
from scipy.ndimage import label as cc_label

REPO = Path("/nfs/turbo/jiankanggroup/gengyh/transferMRI")
RAW  = REPO / "data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data"
CKPT = REPO / "code/pretrained/lungtumormask/dc_student.pth"
OUT  = REPO / "deliverable/measurements/lungtumormask_benchmark_0629"
OUT.mkdir(parents=True, exist_ok=True)


def load_model(device: torch.device) -> torch.nn.Module:
    model = UNet(spatial_dims=3, in_channels=1, out_channels=1,
                 channels=(64, 128, 256, 512, 1024),
                 strides=(2, 2, 2, 2), num_res_units=0)
    sd = torch.load(CKPT, map_location="cpu", weights_only=False)
    sd = sd.get("state_dict", sd) if isinstance(sd, dict) else sd
    renamed, dropped = {}, 0
    for k, v in sd.items():
        if k.startswith("model2."):
            dropped += 1; continue
        if k.startswith("model1."):
            renamed["model." + k[len("model1."):]] = v
    missing, unexpected = model.load_state_dict(renamed, strict=True)
    print(f"loaded {len(renamed)} tensors, dropped aux {dropped}, "
          f"missing={missing}, unexpected={unexpected}")
    return model.to(device).eval()


def lung_norm(ct: np.ndarray, lo_hu: float = -1024, hi_hu: float = 600) -> np.ndarray:
    """Clip + scale to [-1, 1] (LungTumorMask's normalization)."""
    a = np.clip(ct.astype(np.float32), lo_hu, hi_hu)
    a = 2.0 * (a - lo_hu) / (hi_hu - lo_hu) - 1.0
    return a


def dice_score(p: np.ndarray, g: np.ndarray) -> float:
    p, g = p > 0, g > 0
    s = p.sum() + g.sum()
    return float(2 * np.logical_and(p, g).sum() / s) if s else 0.0


def longest_diameter_3d(mask: np.ndarray, spacing) -> float:
    """Max Euclidean distance (in mm) between any two voxels of the largest CC.

    Uses a surface + convex-hull trick to stay sub-second on big masks.
    """
    if mask.sum() == 0:
        return 0.0
    lab, n = cc_label(mask)
    if n == 0:
        return 0.0
    sizes = np.bincount(lab.ravel())
    sizes[0] = 0
    biggest = int(np.argmax(sizes))
    coords = np.argwhere(lab == biggest)
    if coords.shape[0] < 2:
        return 0.0
    # Use ScipPy's ConvexHull when available to prune; otherwise fall back
    # to a sample if too many surface voxels.
    try:
        from scipy.spatial import ConvexHull
        # ConvexHull needs >=4 non-coplanar points for 3D
        if coords.shape[0] >= 4:
            ch = ConvexHull(coords)
            coords = coords[ch.vertices]
    except Exception:
        if coords.shape[0] > 4096:
            idx = np.linspace(0, coords.shape[0] - 1, 4096).astype(int)
            coords = coords[idx]
    pts_mm = coords.astype(np.float32) * np.array(spacing, dtype=np.float32)[::-1]  # (Z,Y,X)
    # Brute-force pairwise distance on the hull (typically <100 vertices)
    diffs = pts_mm[:, None, :] - pts_mm[None, :, :]
    d2 = (diffs ** 2).sum(-1)
    return float(np.sqrt(d2.max()))


def predict_one(model: torch.nn.Module, ct_path: Path, device: torch.device,
                roi=(128, 128, 128)) -> tuple[np.ndarray, np.ndarray, tuple]:
    nii = nib.load(str(ct_path))
    ct  = np.asarray(nii.dataobj)
    spacing = nii.header.get_zooms()[:3]  # (X, Y, Z) in mm
    a = lung_norm(ct)
    x = torch.from_numpy(a).unsqueeze(0).unsqueeze(0).to(device)  # (1,1,X,Y,Z)
    inferer = SlidingWindowInferer(roi_size=roi, sw_batch_size=1, overlap=0.5,
                                    mode="gaussian", padding_mode="replicate")
    with torch.no_grad():
        logits = inferer(x, model)
    prob = torch.sigmoid(logits)[0, 0].cpu().numpy().astype(np.float32)
    pred = (prob > 0.5).astype(np.uint8)
    return pred, prob, spacing


def benchmark_task(task_dir: Path, val_cases: list[str], task_name: str,
                   leaky: bool, model: torch.nn.Module, device: torch.device):
    rows, started = [], time.time()
    for i, case in enumerate(val_cases):
        ct_path = task_dir / "imagesTr" / f"{case}_0000.nii.gz"
        gt_path = task_dir / "labelsTr" / f"{case}.nii.gz"
        if not ct_path.exists() or not gt_path.exists():
            print(f"  [skip] missing {case}")
            continue
        pred, prob, spacing = predict_one(model, ct_path, device)
        gt = (np.asarray(nib.load(str(gt_path)).dataobj) > 0).astype(np.uint8)
        d = dice_score(pred, gt)
        gt_diam = longest_diameter_3d(gt, spacing)
        pr_diam = longest_diameter_3d(pred, spacing)
        v_gt = float(gt.sum() * np.prod(spacing) / 1000.0)
        v_pr = float(pred.sum() * np.prod(spacing) / 1000.0)
        rows.append(dict(case=case, dice=d,
                         gt_volume_cm3=v_gt, pred_volume_cm3=v_pr,
                         gt_diameter_3d_mm=gt_diam, pred_diameter_3d_mm=pr_diam,
                         abs_err_3d_mm=abs(gt_diam - pr_diam),
                         spacing_mm=",".join(f"{s:.4f}" for s in spacing)))
        print(f"  [{i+1:2d}/{len(val_cases)}] {case:25s} dice={d:.3f}  "
              f"gt_diam={gt_diam:6.1f}  pred_diam={pr_diam:6.1f}  "
              f"abs_err={abs(gt_diam - pr_diam):5.1f}")
    out_csv = OUT / f"{task_name}.csv"
    with open(out_csv, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f"wrote {out_csv}   ({len(rows)} cases, {time.time()-started:.0f}s)  "
          f"{'LEAKY (training data)' if leaky else 'external'}")
    return rows


def get_val_cases(task: str, fold: int = 0) -> list[str]:
    import pickle
    splits = pickle.load(open(REPO / "data/nnUNet/nnUNet_preprocessed" / task / "splits_final.pkl", "rb"))
    return list(splits[fold]["val"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="+",
                    default=["Task006_Lung", "Task514_RIDER", "Task512_QIN_Tumor10"])
    ap.add_argument("--device", default=None)
    args = ap.parse_args()

    device = torch.device(args.device or ("cuda" if torch.cuda.is_available() else "cpu"))
    print(f"device = {device}")
    model = load_model(device)

    # Fredriksen et al. trained on MSD Task06 Lung (LIDC + MSD), so MSD = leaky.
    LEAKY = {"Task006_Lung"}

    summary = []
    for task in args.tasks:
        task_dir = RAW / task
        if not task_dir.exists():
            print(f"[skip] {task_dir} not found"); continue
        val = get_val_cases(task)
        print(f"\n=== {task}  n={len(val)}  leaky={task in LEAKY} ===")
        rows = benchmark_task(task_dir, val, task, task in LEAKY, model, device)
        if rows:
            summary.append(dict(task=task, n=len(rows),
                                leaky=task in LEAKY,
                                mean_dice=float(np.mean([r["dice"] for r in rows])),
                                mean_abs_err_diam=float(np.mean([r["abs_err_3d_mm"] for r in rows])),
                                median_abs_err_diam=float(np.median([r["abs_err_3d_mm"] for r in rows])),
                                mean_gt_diam=float(np.mean([r["gt_diameter_3d_mm"] for r in rows])),
                                mean_pred_diam=float(np.mean([r["pred_diameter_3d_mm"] for r in rows])),
                                ))
    with open(OUT / "summary.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(summary[0].keys()))
        w.writeheader(); w.writerows(summary)
    print("\nSUMMARY:")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
