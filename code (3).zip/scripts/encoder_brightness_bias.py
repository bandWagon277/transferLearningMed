"""Item-5a of meetplan0605: encoder activation magnitude as a function of
input voxel-intensity percentile bin.

For each encoder × probe × percentile bin:
  1. Z-score (FLAIR) / HU-window-clip (CT) the volume.
  2. Bin the non-zero voxels by intensity percentile (10 bins, 0–10, 10–20,
     …, 90–100).
  3. For each bin, zero out every voxel NOT in that bin and forward-propagate
     the resulting masked input through the encoder.
  4. Record `||bottleneck||_2 / sqrt(d)` — the per-feature RMS activation,
     which normalizes away the absolute feature-dim count between
     32768-D UNet bottleneck and 2048-D ResNet50 avgpool. Within each
     encoder we also divide by the "all-mode" reference (no masking) to
     produce a relative-activation curve that's comparable across
     encoders independent of overall scale.

Hypothesis (per Item-4 finding): QIN's training labels are 78% whole-lung
masks (HU≈−850), so its bottleneck should fire more strongly on low-percentile
inputs than other encoders. BraTS / MSD-Lung were trained on tumor masks
inside soft tissue / bright FLAIR, so they should fire on high-percentile
inputs. ResNet50 (natural-image priors) should be relatively flat.

Run:
    sbatch code/sbatch_encoder_brightness_bias.slurm
Outputs:
    scratch/encoder_brightness_bias_0605.json
    runs/figures/encoder_brightness_bias_by_percentile.png
"""
from __future__ import annotations
import json, os, sys, time

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, 'code')
from affinity import _build_vanilla_unet, _bottleneck_module, _center_crop_pad


REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
PROBE_JSON = f'{REPO}/scratch/latent_sim_brats_qin_0531.json'
OUT_JSON   = f'{REPO}/scratch/encoder_brightness_bias_0605.json'
OUT_FIG    = f'{REPO}/runs/figures/encoder_brightness_bias_by_percentile.png'

PERCENTILES = list(range(0, 100, 10))   # bin edges: [0,10), [10,20), ..., [90,100]
BIN_LABELS  = [f'{p}-{p+10}' for p in PERCENTILES]


# ---------------------------------------------------------------------------
# Encoder activation under masked input
# ---------------------------------------------------------------------------

def _prep_brats_flair(arr: np.ndarray, roi=(128, 128, 128)) -> np.ndarray:
    """Probes are BraTS FLAIR — z-score on non-zero brain voxels, then
    EXPLICITLY zero out the originally-zero background. Without the zero-out,
    background voxels become a constant negative z-score and contaminate
    every low-percentile bin in the downstream brightness-bias analysis
    (which uses `arr != 0` to select brain voxels)."""
    if arr.ndim == 4:
        arr = arr[..., 0]
    arr = arr.astype(np.float32)
    m = arr > 0
    if m.any():
        z = (arr - arr[m].mean()) / (arr[m].std() + 1e-6)
        z[~m] = 0.0                            # background → 0, brain → z-score
    else:
        z = arr
    return _center_crop_pad(z, roi)


def _mask_to_percentile_bin(arr: np.ndarray, lo_pct: float, hi_pct: float) -> np.ndarray:
    """Return a copy of `arr` with voxels OUTSIDE the [lo_pct, hi_pct]
    intensity percentile of the non-zero region zeroed out."""
    v = arr[arr != 0]
    if v.size == 0:
        return arr * 0
    lo = np.percentile(v, lo_pct)
    hi = np.percentile(v, hi_pct)
    out = arr.copy()
    out[(arr < lo) | (arr > hi)] = 0
    return out


def _encode_3d(ckpt_path: str, vol_arrays: list[np.ndarray],
               in_channels=1, out_channels=1,
               channels=(32, 64, 128, 256, 512), device='cuda') -> np.ndarray:
    """Run each pre-prepared volume through the 3D UNet bottleneck."""
    model = _build_vanilla_unet(in_channels, out_channels, channels)
    sd = torch.load(ckpt_path, map_location='cpu', weights_only=False)
    sd = sd.get('state_dict', sd) if isinstance(sd, dict) else sd
    model.load_state_dict(sd)
    model.eval().to(device)
    captured = {}
    def hook(_m, _i, output):
        captured['z'] = output.detach()
    h = _bottleneck_module(model).register_forward_hook(hook)
    feats = []
    with torch.no_grad():
        for arr in vol_arrays:
            x = torch.from_numpy(arr).float().unsqueeze(0).unsqueeze(0).to(device)
            if in_channels > 1:
                x = x.repeat(1, in_channels, 1, 1, 1)
            _ = model(x)
            feats.append(captured['z'].flatten().cpu().numpy())
    h.remove()
    return np.stack(feats, axis=0)


def _encode_resnet50_2d(vol_arrays: list[np.ndarray], device='cuda') -> np.ndarray:
    """For each masked 3D volume, slice axially → 224x224 resize → 3-channel
    replicate → ResNet50 trunk → mean-pool over depth. Mirrors the path in
    compute_jon_method_pairs._resnet50_extract but accepts already-prepared
    arrays."""
    import torchvision.models as M
    from scipy.ndimage import zoom
    m = M.resnet50(weights=M.ResNet50_Weights.IMAGENET1K_V2)
    trunk = nn.Sequential(*list(m.children())[:-1]).eval().to(device)
    mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1).to(device)
    std  = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1).to(device)
    feats = []
    with torch.no_grad():
        for arr in vol_arrays:
            lo, hi = arr.min(), arr.max()
            denom = (hi - lo) if (hi - lo) > 1e-6 else 1.0
            arr01 = (arr - lo) / denom
            slices = []
            for k in range(arr01.shape[2]):
                sl = arr01[:, :, k]
                zy, zx = 224.0 / sl.shape[0], 224.0 / sl.shape[1]
                slices.append(zoom(sl, (zy, zx), order=1))
            stack = np.stack(slices, axis=0)
            x = torch.from_numpy(stack).float().unsqueeze(1).to(device)
            x = x.repeat(1, 3, 1, 1)
            x = (x - mean) / std
            chunks = []
            for s in range(0, x.size(0), 32):
                chunks.append(trunk(x[s:s+32]).squeeze(-1).squeeze(-1))
            per_slice = torch.cat(chunks, dim=0).cpu().numpy()
            feats.append(per_slice.mean(axis=0))
    return np.stack(feats, axis=0)


def main():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f'[device] {device}', flush=True)

    probes = json.load(open(PROBE_JSON))['probes']
    print(f'[probes] {len(probes)}', flush=True)

    import nibabel as nib
    prepped = [_prep_brats_flair(nib.load(p).get_fdata()) for p in probes]

    encoders_3d = {
        'brats': f'{REPO}/code/pretrained/brats_flair_pretrain/brats_vanilla_kfold/fold0/best.pt',
        'qin':   f'{REPO}/code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_kfold/fold0/best.pt',
        'msd':   f'{REPO}/code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt',
    }

    enc_names = list(encoders_3d.keys()) + ['resnet50']

    # ----- baseline (all-mode, no masking) -----
    baseline = {}
    for name, ckpt in encoders_3d.items():
        t0 = time.time()
        f = _encode_3d(ckpt, prepped, device=device)
        baseline[name] = float(np.sqrt((f**2).mean()))    # RMS per feature
        print(f'[base] {name}  rms={baseline[name]:.4f}  dt={time.time()-t0:.1f}s', flush=True)
    t0 = time.time()
    f = _encode_resnet50_2d(prepped, device=device)
    baseline['resnet50'] = float(np.sqrt((f**2).mean()))
    print(f'[base] resnet50  rms={baseline["resnet50"]:.4f}  dt={time.time()-t0:.1f}s', flush=True)

    # ----- per-percentile-bin -----
    rms = {n: [] for n in enc_names}      # mean over probes per bin
    rms_norm = {n: [] for n in enc_names} # divided by baseline[n]
    for lo_pct in PERCENTILES:
        hi_pct = lo_pct + 10
        masked = [_mask_to_percentile_bin(a, lo_pct, hi_pct) for a in prepped]
        for name, ckpt in encoders_3d.items():
            t0 = time.time()
            f = _encode_3d(ckpt, masked, device=device)
            r = float(np.sqrt((f**2).mean()))
            rms[name].append(r)
            rms_norm[name].append(r / max(1e-9, baseline[name]))
            print(f'[bin {lo_pct:>2}–{hi_pct:>2}] {name}  rms={r:.4f}  '
                  f'rel={r/baseline[name]:.3f}  dt={time.time()-t0:.1f}s', flush=True)
        t0 = time.time()
        f = _encode_resnet50_2d(masked, device=device)
        r = float(np.sqrt((f**2).mean()))
        rms['resnet50'].append(r)
        rms_norm['resnet50'].append(r / max(1e-9, baseline['resnet50']))
        print(f'[bin {lo_pct:>2}–{hi_pct:>2}] resnet50  rms={r:.4f}  '
              f'rel={r/baseline["resnet50"]:.3f}  dt={time.time()-t0:.1f}s', flush=True)

    out = {
        'probes': probes,
        'encoders': encoders_3d,
        'percentile_bins': BIN_LABELS,
        'baseline_rms_unmasked': baseline,
        'rms_by_bin': rms,
        'rms_relative_to_baseline': rms_norm,
    }
    os.makedirs(os.path.dirname(OUT_JSON), exist_ok=True)
    with open(OUT_JSON, 'w') as f:
        json.dump(out, f, indent=2)
    print(f'\nsaved -> {OUT_JSON}')

    # ----- figure -----
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    colors = {'brats': 'C0', 'qin': 'C3', 'msd': 'C2', 'resnet50': 'k'}
    for name in enc_names:
        ax1.plot(BIN_LABELS, rms[name], marker='o', label=name,
                 color=colors.get(name, None))
        ax2.plot(BIN_LABELS, rms_norm[name], marker='o', label=name,
                 color=colors.get(name, None))
    ax1.set_xlabel('voxel-intensity percentile bin')
    ax1.set_ylabel('RMS bottleneck activation')
    ax1.set_title('Raw RMS by percentile')
    ax1.tick_params(axis='x', rotation=30)
    ax1.legend()
    ax2.set_xlabel('voxel-intensity percentile bin')
    ax2.set_ylabel('RMS / RMS(unmasked baseline)')
    ax2.set_title('Relative-to-baseline RMS (per encoder)')
    ax2.tick_params(axis='x', rotation=30)
    ax2.axhline(1.0, color='gray', lw=0.5, ls='--')
    ax2.legend()
    plt.suptitle('Encoder activation magnitude vs input intensity percentile\n'
                 'BraTS FLAIR probes (n=12), bottleneck RMS / sqrt(d)')
    plt.tight_layout()
    os.makedirs(os.path.dirname(OUT_FIG), exist_ok=True)
    plt.savefig(OUT_FIG, dpi=140)
    plt.close()
    print(f'saved -> {OUT_FIG}')


if __name__ == '__main__':
    main()
