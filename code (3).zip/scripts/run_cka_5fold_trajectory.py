"""5-fold CKA trajectory for the BraTS21 <-> MSD-Lung pair.

For each of fold 0..4 in each of the two transfer directions, walk every
checkpoint_epoch_<E>.pt and compute CKA at the decoder layer ladder against
the matched source encoder. Aggregate fold-mean / fold-SD per epoch.

Inputs (all assumed to exist after submit_5fold_cka_training_0629.sh runs):

  MSD source ckpts (fixed) :
    code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold{0..4}/best.pt

  BraTS source ckpts (fixed):
    code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt              (fold 0)
    code/pretrained/brats_flair_pretrain/brats_vanilla_v1_fold{1..4}/best.pt

  Transfer dirs (the things we measure CKA on):
    code/pretrained/brats_flair_pretrain/brats_from_msd_fold{0..4}/
    code/pretrained/oktaykurt_retrain/msd_from_brats_fold{0..4}/

For each direction we use ONE fixed source (fold-0 of the source dataset) as
the f_S argument to CKA -- so that variance across folds reflects variance in
the *target's* trajectory, not in the source. This matches how the existing
plot in the deck is set up.

Output:
  runs/cka_5fold_trajectory_0629.json
  runs/figures/0629/cka_5fold_trajectory.png

Wall-clock note: each checkpoint -> feature extraction over 40 probes is
~30-60 s on GPU. 20 folds × ~6 epoch checkpoints each = ~120 ckpts ~= 1-2 h.
"""
from __future__ import annotations
import glob, json, os, re, sys
from collections import defaultdict

import numpy as np

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)
from affinity import (DatasetSpec, list_cases, linear_cka,
                       _extract_layer_ladder_features)

REPO = os.path.dirname(THIS)
N_PROBES = 40
SEED = 42

# Fixed source ckpts (fold-0 of each source dataset)
F_S_MSD   = os.path.join(REPO, 'code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt')
F_S_BRATS = os.path.join(REPO, 'code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt')

# (direction, fold) -> (transfer-run dir, source ckpt, probe layout, probe root)
RUNS = {}
for f in range(5):
    RUNS[("MSD->BraTS", f)] = (
        f'code/pretrained/brats_flair_pretrain/brats_from_msd_fold{f}',
        F_S_MSD, 'brats_flair', 'data/BraTS2021_Training')
    RUNS[("BraTS->MSD", f)] = (
        f'code/pretrained/oktaykurt_retrain/msd_from_brats_fold{f}',
        F_S_BRATS, 'msd', 'data/MSD_Task06_Lung/Task06_Lung')


def _gather_probes(layout: str, root: str, n: int) -> list[str]:
    spec = DatasetSpec(name='probe', root=root, layout=layout)
    cases = list_cases(spec)
    rng = np.random.default_rng(SEED)
    idx = rng.permutation(len(cases))[:n]
    return [cases[i]['image'] for i in sorted(idx.tolist())]


def _epoch_from_name(name: str) -> int | None:
    m = re.match(r'checkpoint_epoch_0*(\d+)\.pt', name)
    if m: return int(m.group(1))
    if name == 'best.pt': return None
    if name == 'last.pt': return -1
    return None


def main():
    out_json = os.path.join(REPO, 'runs/cka_5fold_trajectory_0629.json')
    fig_dir  = os.path.join(REPO, 'runs/figures/0629')
    fig_path = os.path.join(fig_dir, 'cka_5fold_trajectory.png')
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    probe_cache: dict[str, list[str]] = {}
    src_feats_cache: dict[tuple, dict] = {}

    def _src_feats(src_ckpt, layout, root):
        key = (src_ckpt, layout, root)
        if key not in src_feats_cache:
            probes = _gather_probes(layout, os.path.join(REPO, root), N_PROBES)
            probe_cache[layout] = probes
            print(f'[probes] {len(probes)} {layout}')
            feats = _extract_layer_ladder_features(
                ckpt_path=src_ckpt, probe_paths=probes,
                in_channels=1, out_channels=1, layout=layout)
            src_feats_cache[key] = feats
        return src_feats_cache[key], probe_cache[layout]

    results = defaultdict(dict)
    for (direction, fold), (rel, src_ckpt, layout, root) in RUNS.items():
        run_dir = os.path.join(REPO, rel)
        if not os.path.isdir(run_dir):
            print(f'[skip] {direction} fold {fold}: dir missing {run_dir}')
            continue
        feats_s, probes = _src_feats(src_ckpt, layout, root)
        ckpts = sorted(glob.glob(os.path.join(run_dir, 'checkpoint_epoch_*.pt')))
        for extra in ('best.pt', 'last.pt'):
            p = os.path.join(run_dir, extra)
            if os.path.isfile(p): ckpts.append(p)
        if not ckpts:
            print(f'[skip] {direction} fold {fold}: no checkpoints'); continue
        epoch_recs = []
        for ck in ckpts:
            name = os.path.basename(ck)
            ep = _epoch_from_name(name)
            print(f'[{direction} fold {fold}] {name} (ep={ep})')
            try:
                feats_t = _extract_layer_ladder_features(
                    ckpt_path=ck, probe_paths=probes,
                    in_channels=1, out_channels=1, layout=layout)
            except Exception as e:
                print(f'  extract FAILED: {e}'); continue
            per_layer = {L: float(linear_cka(feats_s[L], feats_t[L]))
                         for L in feats_s}
            epoch_recs.append({'ckpt': name, 'epoch': ep,
                                'cka_per_layer': per_layer})
        results[direction][fold] = dict(run_dir=rel, src_ckpt=src_ckpt,
                                         epochs=epoch_recs)

    out = {'n_probes': N_PROBES, 'seed': SEED,
           'src_msd': F_S_MSD, 'src_brats': F_S_BRATS,
           'directions': dict(results)}
    with open(out_json, 'w') as fh:
        json.dump(out, fh, indent=2)
    print(f'[saved] {out_json}')

    # ----- Plot fold-mean ± SD trajectory at a chosen ladder layer (D1) -----
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    LAYERS_TO_PLOT = ['L0_stem', 'L1_down', 'L2_down', 'L3_down',
                       'bottleneck', 'D1_up_outer']
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5), sharey=True)
    for ax, direction in zip(axes, ["MSD->BraTS", "BraTS->MSD"]):
        if direction not in results:
            ax.set_title(f"{direction} (no data)"); continue
        # for each epoch, gather per-fold CKA[layer]
        all_epochs = set()
        for fold, rec in results[direction].items():
            for e in rec['epochs']:
                if e['epoch'] is not None and e['epoch'] >= 0:
                    all_epochs.add(e['epoch'])
        all_epochs = sorted(all_epochs)
        target_layer = 'D1_up_outer'
        ymeans, ysds = [], []
        for ep in all_epochs:
            ys = []
            for fold, rec in results[direction].items():
                vals = [e['cka_per_layer'].get(target_layer)
                        for e in rec['epochs'] if e['epoch'] == ep]
                if vals and vals[0] is not None: ys.append(vals[0])
            if not ys: ymeans.append(np.nan); ysds.append(np.nan); continue
            ymeans.append(float(np.mean(ys))); ysds.append(float(np.std(ys, ddof=1) if len(ys) > 1 else 0))
        ymeans = np.array(ymeans); ysds = np.array(ysds)
        ax.errorbar(all_epochs, ymeans, yerr=ysds, marker='o',
                    color='#2c3e50', ecolor='#7f8c8d', capsize=3, label='5-fold mean ± SD')
        ax.set_title(f"{direction} (CKA @ D1_up_outer)")
        ax.set_xlabel("epoch"); ax.set_ylabel("CKA(source, transfer)")
        ax.set_ylim(0, 1)
        ax.grid(alpha=0.3); ax.legend(loc='lower right', fontsize=9)
    fig.suptitle("5-fold CKA trajectory  -- BraTS21 <-> MSD-Lung transfer", fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(fig_path, dpi=140, bbox_inches='tight')
    print(f'[saved] {fig_path}')


if __name__ == "__main__":
    main()
