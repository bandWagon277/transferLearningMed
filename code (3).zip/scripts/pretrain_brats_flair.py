"""Pretrain a matched-architecture S_brain on BraTS FLAIR-only, WT mask.

Phase E "option (ii)" of the cross-organ × cross-modality plan: instead
of integrating DeepBrainSeg's custom multi-resolution architecture
(166 state-dict keys, BatchNorm, parallel 3×3/5×5/7×7 conv branches that
don't fit our MONAI UNet ladder), we **train our own brain-MRI source**
using the same UNet architecture as the lung source (Phase D). This
preserves the controlled-experiment design: only source data varies
across the 2×2 cells, not architecture.

Setup:
  - Input: BraTS-FLAIR only (1 channel) — single-modality match to the
    lung-CT source's 1-channel input.
  - Label: any-tumor binary mask = WT region (labels {1,2,4} unioned).
  - Architecture: MONAI UNet with channels (64,128,256,512,1024),
    num_res_units=0 — identical to S_lung (Phase D).
  - Loss: DiceCELoss(sigmoid=True), binary.
  - Output: `code/pretrained/brats_flair_pretrain/brats_flair.pt`.

The resulting checkpoint slots into `--arch unet --init brats_flair` once
the loader is added in `code/models.py`.

Run:
  sbatch code/submit_pretrain.slurm \\
      --epochs 50 --batch-size 2 --no-amp \\
      --out code/pretrained/brats_flair_pretrain
  # but with the pretrain target switched — use this alternate slurm wrapper:
  # `code/submit_pretrain_brats.slurm` (creates the right --script-path).
"""
from __future__ import annotations
import argparse, glob, json, os, random, time

import torch
from monai import transforms as T
from monai.data import CacheDataset, DataLoader, decollate_batch
from monai.inferers import sliding_window_inference
from monai.losses import DiceCELoss
from monai.metrics import DiceMetric
from monai.transforms import Activations, AsDiscrete, MapTransform

from models import build_model
from monai.networks.nets import UNet as MonaiUNet


BRATS_ROOT_DEFAULT = '/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/BraTS2021_Training'
BRATS2024_ROOT_DEFAULT = '/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/BraTS2024_AdultGlioma_PostTreatment'
BRATS2024_PATIENT_ID_THRESHOLD = 2000  # drop UCSF cases with IDs <2000 (BraTS21 overlap)


class BratsWholeTumord(MapTransform):
    """Convert the BraTS multi-class label to a binary whole-tumor mask:
       background (0) ↔ tumor (anywhere {1, 2, 4} is present).
    """
    def __call__(self, data):
        d = dict(data)
        for key in self.key_iterator(d):
            d[key] = (d[key] > 0).float()
        return d


def list_brats_flair_cases(root: str) -> list[dict]:
    """One case per patient; image = FLAIR only, label = seg."""
    cases = []
    for case_dir in sorted(glob.glob(os.path.join(root, 'BraTS2021_*'))):
        cid = os.path.basename(case_dir)
        flair = os.path.join(case_dir, f'{cid}_flair.nii.gz')
        seg   = os.path.join(case_dir, f'{cid}_seg.nii.gz')
        if os.path.exists(flair) and os.path.exists(seg):
            cases.append({'image': flair, 'label': seg, 'id': cid})
    return cases


def list_brats2024_clean_cases(root: str) -> list[dict]:
    """BraTS-GLI 2024 Post-Treatment clean cohort: one canonical -101+ scan
    per patient with ID >= 2000 (drops 38 UCSF patients in the BraTS 2021
    overlap range). FLAIR in BraTS 2024 is `t2f`. See
    `code/convert_brats2024_to_nnunet_task502.py` for the original rule.
    """
    import re
    case_re = re.compile(r'BraTS-GLI-(\d+)-(\d+)$')
    by_patient: dict[int, list[tuple[int, str]]] = {}
    for sub in ('training_data1_v2', 'training_data_additional'):
        sub_root = os.path.join(root, sub)
        if not os.path.isdir(sub_root):
            continue
        for entry in os.listdir(sub_root):
            m = case_re.match(entry)
            if not m:
                continue
            patient, tp = int(m.group(1)), int(m.group(2))
            if patient < BRATS2024_PATIENT_ID_THRESHOLD or tp < 101:
                continue
            by_patient.setdefault(patient, []).append((tp, os.path.join(sub_root, entry)))
    cases = []
    for patient, tps in by_patient.items():
        tps.sort()  # earliest -101+ first
        tp, case_dir = tps[0]
        cid = os.path.basename(case_dir)
        flair = os.path.join(case_dir, f'{cid}-t2f.nii.gz')
        seg   = os.path.join(case_dir, f'{cid}-seg.nii.gz')
        if os.path.exists(flair) and os.path.exists(seg):
            cases.append({'image': flair, 'label': seg, 'id': cid})
    cases.sort(key=lambda c: c['id'])
    return cases


class BraTS2024WholeTumord(BratsWholeTumord):
    """Same WT collapse as BraTS21: any non-zero label -> 1. BraTS 2024 has
    {1=NETC, 2=edema, 3=ET, 4=resection cavity}; we collapse all to WT."""
    pass


def brats_flair_train_transforms(roi=(192, 192, 144),
                                 rotation_deg: float = 30.0) -> T.Compose:
    return T.Compose([
        T.LoadImaged(keys=['image', 'label']),
        T.EnsureChannelFirstd(keys=['image', 'label']),
        T.EnsureTyped(keys=['image', 'label']),
        T.Orientationd(keys=['image', 'label'], axcodes='RAS'),
        T.Spacingd(keys=['image', 'label'], pixdim=(1.0, 1.0, 1.0),
                   mode=('bilinear', 'nearest')),
        BratsWholeTumord(keys='label'),
        T.CropForegroundd(keys=['image', 'label'], source_key='image',
                          k_divisible=16),
        T.SpatialPadd(keys=['image', 'label'], spatial_size=roi),
        T.RandSpatialCropd(keys=['image', 'label'], roi_size=roi, random_size=False),
        T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=0),
        T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=1),
        T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=2),
        # ±rotation_deg arbitrary-axis rotation (meetplan0522 item 1).
        T.RandRotated(
            keys=['image', 'label'],
            range_x=rotation_deg * 3.14159 / 180.0,
            range_y=rotation_deg * 3.14159 / 180.0,
            range_z=rotation_deg * 3.14159 / 180.0,
            mode=('bilinear', 'nearest'),
            padding_mode='zeros',
            prob=0.5,
        ),
        T.NormalizeIntensityd(keys='image', nonzero=True, channel_wise=True),
        T.RandScaleIntensityd(keys='image', factors=0.1, prob=1.0),
        T.RandShiftIntensityd(keys='image', offsets=0.1, prob=1.0),
    ])


def brats_flair_val_transforms() -> T.Compose:
    return T.Compose([
        T.LoadImaged(keys=['image', 'label']),
        T.EnsureChannelFirstd(keys=['image', 'label']),
        T.EnsureTyped(keys=['image', 'label']),
        T.Orientationd(keys=['image', 'label'], axcodes='RAS'),
        T.Spacingd(keys=['image', 'label'], pixdim=(1.0, 1.0, 1.0),
                   mode=('bilinear', 'nearest')),
        BratsWholeTumord(keys='label'),
        T.NormalizeIntensityd(keys='image', nonzero=True, channel_wise=True),
    ])


def split_cases(cases, val_frac=0.2, seed=42):
    rng = random.Random(seed)
    shuffled = list(cases)
    rng.shuffle(shuffled)
    n_val = max(1, int(round(len(shuffled) * val_frac)))
    return shuffled[n_val:], shuffled[:n_val]


def split_kfold(cases, fold: int, n_folds: int, seed: int = 42):
    """Deterministic K-fold split. See pretrain_oktaykurt.split_kfold."""
    rng = random.Random(seed)
    shuffled = list(cases)
    rng.shuffle(shuffled)
    n = len(shuffled)
    fold_size = n // n_folds
    val_start = fold * fold_size
    val_end = (fold + 1) * fold_size if fold < n_folds - 1 else n
    val = shuffled[val_start:val_end]
    train = shuffled[:val_start] + shuffled[val_end:]
    return train, val


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--source', choices=['brats21', 'brats24_clean'],
                   default='brats21',
                   help='brats21 = original BraTS 2021 1251 cases at --root. '
                        'brats24_clean = BraTS-GLI 2024 Post-Treatment '
                        'clean cohort (ID>=2000, canonical -101+ per patient).')
    p.add_argument('--root', default=None,
                   help='Data root. Defaults: BraTS2021_Training for brats21, '
                        'BraTS2024_AdultGlioma_PostTreatment for brats24_clean.')
    p.add_argument('--out',  required=True)
    p.add_argument('--epochs', type=int, default=50)
    p.add_argument('--batch-size', type=int, default=2)
    p.add_argument('--num-workers', type=int, default=4)
    p.add_argument('--cache-rate', type=float, default=0.0)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--weight-decay', type=float, default=1e-5)
    p.add_argument('--val-every', type=int, default=5)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--train-frac', type=float, default=1.0,
                   help='Subsample train for ablation; default 1.0 (full BraTS).')
    p.add_argument('--amp', action='store_true', default=True)
    p.add_argument('--no-amp', dest='amp', action='store_false')
    p.add_argument('--channels', default=None,
                   help='Comma-separated 5 channel ladder, e.g. '
                        '"32,64,128,256,512" for vanilla. When unset, '
                        'uses wide LungTumorMask ladder (64,128,256,512,1024).')
    p.add_argument('--rotation-deg', type=float, default=30.0,
                   help='Max rotation angle (deg) for RandRotated on each '
                        'axis. Default 30. Set 0 to disable.')
    p.add_argument('--early-stop-patience', type=int, default=0,
                   help='Stop if val_dice has not improved for this many '
                        'validation rounds. 0 disables.')
    p.add_argument('--pretrained', default=None,
                   help='Path to a checkpoint (best.pt) to load as initial '
                        'weights before training. Architecture must match. '
                        'Used for cross-domain transfer experiments.')
    p.add_argument('--freeze-depth', type=int, default=0, choices=[0, 1, 2],
                   help='Freeze depth for Matsoukas analysis: 0=full fine-tune, '
                        '1=freeze encoder, 2=freeze encoder+bottleneck.')
    p.add_argument('--ckpt-every', type=int, default=20,
                   help='Save a periodic checkpoint every N epochs.')
    p.add_argument('--keep-checkpoints', action='store_true',
                   help='Skip the post-training cleanup that deletes '
                        '`checkpoint_epoch_*.pt`. Use for CKA-trajectory '
                        'runs where the intermediate weights are needed.')
    p.add_argument('--norm', default='instance', choices=['instance', 'batch'],
                   help='Normalization layer in the UNet. Default instance '
                        '(matches the rest of the project). Use batch for the '
                        'meetplan0617 BN-RI-RI vs BN-scratch-scratch comparison.')
    p.add_argument('--resume', default=None,
                   help='Path to last.pt or checkpoint_epoch_NNN.pt to '
                        'resume training from.')
    p.add_argument('--fold', type=int, default=0,
                   help='K-fold index (0 .. n_folds-1). Default 0 reproduces '
                        'the legacy 80/20 split.')
    p.add_argument('--n-folds', type=int, default=5,
                   help='Number of K-fold splits. Default 5.')
    p.add_argument('--roi', default='192,192,144',
                   help='Comma-separated training patch size (3 ints). '
                        'Default 192,192,144 (anisotropic to fit native '
                        '240x240x155 BraTS volumes). Sliding-window val '
                        'inference uses the same ROI.')
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, 'config.json'), 'w') as f:
        json.dump(vars(args), f, indent=2)

    torch.manual_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'[device] {device} ({torch.cuda.get_device_name(0) if device.type=="cuda" else "cpu"})')

    if args.root is None:
        args.root = (BRATS_ROOT_DEFAULT if args.source == 'brats21'
                     else BRATS2024_ROOT_DEFAULT)
    if args.source == 'brats21':
        cases = list_brats_flair_cases(args.root)
    elif args.source == 'brats24_clean':
        cases = list_brats2024_clean_cases(args.root)
    else:
        raise ValueError(f'unknown --source {args.source!r}')
    if not cases:
        raise FileNotFoundError(f'no {args.source} cases under {args.root}')
    train, val = split_kfold(cases, fold=args.fold, n_folds=args.n_folds,
                             seed=args.seed)
    if args.train_frac < 1.0:
        n_keep = max(1, int(round(len(train) * args.train_frac)))
        train = train[:n_keep]
    print(f'[data] fold={args.fold}/{args.n_folds}  n_train={len(train)} '
          f'n_val={len(val)} of n_total={len(cases)}')

    roi = tuple(int(x) for x in args.roi.split(','))
    if len(roi) != 3:
        raise ValueError(f'--roi must give 3 ints, got {roi}')
    train_ds = CacheDataset(train,
                            transform=brats_flair_train_transforms(
                                roi=roi, rotation_deg=args.rotation_deg),
                            cache_rate=args.cache_rate, num_workers=args.num_workers)
    val_ds   = CacheDataset(val,   transform=brats_flair_val_transforms(),
                            cache_rate=args.cache_rate, num_workers=args.num_workers)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.num_workers, pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=1, shuffle=False,
                              num_workers=args.num_workers, pin_memory=True)

    if args.channels:
        ch = tuple(int(x) for x in args.channels.split(','))
        if len(ch) != 5:
            raise ValueError(f'--channels must give 5 ints, got {ch}')
        # Normalization: MONAI default for num_res_units=0 is InstanceNorm.
        # For BN experiments we pass norm='BATCH'. Affects every conv block.
        _norm = 'BATCH' if (args.norm or 'instance').lower() == 'batch' else 'INSTANCE'
        model = MonaiUNet(spatial_dims=3, in_channels=1, out_channels=1,
                          channels=ch, strides=(2, 2, 2, 2),
                          num_res_units=0, norm=_norm).to(device)
        ladder = f'channels={ch} norm={_norm}'
    else:
        model = build_model(arch='unet', in_channels=1, out_channels=1,
                            init='random', freeze='none').to(device)
        ladder = 'channels=LungTumorMask-wide (64,128,256,512,1024)'
    if args.pretrained:
        ckpt = torch.load(args.pretrained, map_location=device, weights_only=True)
        sd = ckpt['state_dict'] if 'state_dict' in ckpt else ckpt
        model.load_state_dict(sd)
        src_dice = ckpt.get('val_dice', '?')
        src_epoch = ckpt.get('epoch', '?')
        init_tag = f'pretrained from {args.pretrained} (dice={src_dice}, ep={src_epoch})'
    else:
        init_tag = 'random init'

    ENCODER_PREFIXES = [
        'model.0.',
        'model.1.submodule.0.',
        'model.1.submodule.1.submodule.0.',
        'model.1.submodule.1.submodule.1.submodule.0.',
    ]
    BOTTLENECK_PREFIX = 'model.1.submodule.1.submodule.1.submodule.1.submodule.'
    if args.freeze_depth >= 1:
        freeze_prefixes = list(ENCODER_PREFIXES)
        if args.freeze_depth >= 2:
            freeze_prefixes.append(BOTTLENECK_PREFIX)
        for name, param in model.named_parameters():
            if any(name.startswith(p) for p in freeze_prefixes):
                param.requires_grad = False
        n_frozen = sum(1 for p in model.parameters() if not p.requires_grad)
        n_total_p = sum(1 for p in model.parameters())
        depth_label = {1: 'encoder', 2: 'encoder+bottleneck'}[args.freeze_depth]
        init_tag += f'; {depth_label} frozen ({n_frozen}/{n_total_p} param tensors)'

    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    n_trainable = sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6
    print(f'[model] unet {n_params:.1f}M params ({n_trainable:.1f}M trainable); {init_tag}; {ladder}')

    loss_fn = DiceCELoss(sigmoid=True, lambda_dice=1.0, lambda_ce=1.0)
    optim = torch.optim.AdamW(model.parameters(), lr=args.lr,
                              weight_decay=args.weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=args.epochs)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp and device.type == 'cuda')

    post_pred = Activations(sigmoid=True)
    post_thr  = AsDiscrete(threshold=0.5)
    dice_metric = DiceMetric(include_background=False, reduction='mean')

    best_dice = -1.0
    stale_rounds = 0
    start_epoch = 0
    log_path = os.path.join(args.out, 'metrics.jsonl')
    ckpt_path = os.path.join(args.out, 'best.pt')

    if args.resume:
        rck = torch.load(args.resume, map_location=device, weights_only=True)
        model.load_state_dict(rck['state_dict'])
        if 'optimizer' in rck:
            optim.load_state_dict(rck['optimizer'])
        if 'scheduler' in rck:
            sched.load_state_dict(rck['scheduler'])
        if 'scaler' in rck and scaler is not None:
            scaler.load_state_dict(rck['scaler'])
        start_epoch = rck.get('epoch', 0) + 1
        best_dice = rck.get('best_dice', rck.get('val_dice', -1.0))
        print(f'[resume] from {args.resume}, epoch={start_epoch}, best_dice={best_dice:.4f}')

    for epoch in range(start_epoch, args.epochs):
        model.train()
        epoch_loss = 0.0
        t0 = time.time()
        for batch in train_loader:
            x = batch['image'].to(device, non_blocking=True)
            y = batch['label'].to(device, non_blocking=True).float()
            optim.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=args.amp and device.type == 'cuda'):
                logits = model(x)
                loss = loss_fn(logits, y)
            if not torch.isfinite(loss):
                raise RuntimeError(f'non-finite loss at epoch={epoch}')
            scaler.scale(loss).backward()
            scaler.step(optim)
            scaler.update()
            epoch_loss += loss.item()
        sched.step()
        epoch_loss /= max(1, len(train_loader))
        rec = {'epoch': epoch, 'train_loss': epoch_loss,
               'epoch_time_s': round(time.time() - t0, 1)}

        save_payload = {
            'state_dict': model.state_dict(), 'epoch': epoch,
            'train_loss': epoch_loss, 'best_dice': best_dice,
            'optimizer': optim.state_dict(),
            'scheduler': sched.state_dict(),
            'scaler': scaler.state_dict() if scaler else None,
        }
        torch.save(save_payload, os.path.join(args.out, 'last.pt'))

        if args.ckpt_every > 0 and (epoch + 1) % args.ckpt_every == 0:
            torch.save(save_payload,
                       os.path.join(args.out, f'checkpoint_epoch_{epoch+1:03d}.pt'))

        if (epoch + 1) % args.val_every == 0 or epoch == args.epochs - 1:
            model.eval()
            dice_metric.reset()
            with torch.no_grad():
                for vbatch in val_loader:
                    vx = vbatch['image'].to(device, non_blocking=True)
                    vy = vbatch['label'].to(device, non_blocking=True).float()
                    with torch.cuda.amp.autocast(enabled=args.amp and device.type == 'cuda'):
                        vy_logits = sliding_window_inference(
                            vx, roi_size=roi, sw_batch_size=1,
                            predictor=model, overlap=0.5)
                    vy_prob = [post_pred(p) for p in decollate_batch(vy_logits)]
                    vy_bin  = [post_thr(p)  for p in vy_prob]
                    dice_metric(y_pred=vy_bin, y=decollate_batch(vy))
            mean_dice = dice_metric.aggregate().item()
            rec['val_dice'] = mean_dice
            if mean_dice > best_dice:
                best_dice = mean_dice
                stale_rounds = 0
                torch.save({'state_dict': model.state_dict(),
                            'epoch': epoch, 'val_dice': mean_dice}, ckpt_path)
                rec['saved_best'] = True
            else:
                stale_rounds += 1
                rec['stale_rounds'] = stale_rounds
            if device.type == 'cuda':
                torch.cuda.empty_cache()

        with open(log_path, 'a') as f:
            f.write(json.dumps(rec) + '\n')
        print(json.dumps(rec))

        if args.early_stop_patience > 0 and stale_rounds >= args.early_stop_patience:
            print(f'[early-stop] no val_dice improvement for '
                  f'{stale_rounds} validation rounds (patience='
                  f'{args.early_stop_patience}); stopping at epoch {epoch}.')
            break

    if not args.keep_checkpoints:
        import glob as _glob
        for f in _glob.glob(os.path.join(args.out, 'checkpoint_epoch_*.pt')):
            os.remove(f)
        print(f'[cleanup] removed periodic checkpoints')
    else:
        print(f'[cleanup] --keep-checkpoints set; periodic checkpoints retained')
    print(f'[done] best val Dice = {best_dice:.4f}; checkpoint at {ckpt_path}')


if __name__ == '__main__':
    main()
