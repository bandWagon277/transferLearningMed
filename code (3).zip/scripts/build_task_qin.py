"""Build Task512_QIN_Tumor10 from the 10 QIN-LSC/QIN-LUNG cases with tumor
segmentations under data/qin_lung_ct_tumor10/.

Each source case is `<CASE>/image.nii.gz + label.nii.gz`. Labels may have
non-zero non-tumor values; we binarize (> 0 -> 1).
"""
from __future__ import annotations
import json, os, glob
import nibabel as nib
import numpy as np

REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
SRC = f'{REPO}/data/qin_lung_ct_tumor10'
DST = f'{REPO}/data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data/Task512_QIN_Tumor10'

os.makedirs(f'{DST}/imagesTr', exist_ok=True)
os.makedirs(f'{DST}/labelsTr', exist_ok=True)

cases = sorted(d for d in os.listdir(SRC)
               if os.path.isdir(f'{SRC}/{d}'))
print(f'Found {len(cases)} cases: {cases}')

training = []
for i, cid in enumerate(cases):
    src_img = f'{SRC}/{cid}/image.nii.gz'
    src_lbl = f'{SRC}/{cid}/label.nii.gz'
    if not (os.path.exists(src_img) and os.path.exists(src_lbl)):
        print(f'  skip {cid}: missing image or label')
        continue
    safe = cid.replace('-', '_')
    out_img = f'{DST}/imagesTr/{safe}_0000.nii.gz'
    out_lbl = f'{DST}/labelsTr/{safe}.nii.gz'

    img = nib.load(src_img)
    nib.save(img, out_img)

    lab = nib.load(src_lbl)
    arr = lab.get_fdata()
    arr_bin = (arr > 0).astype(np.uint8)
    nib.save(nib.Nifti1Image(arr_bin, lab.affine, lab.header), out_lbl)

    training.append({'image': f'./imagesTr/{safe}.nii.gz',
                     'label': f'./labelsTr/{safe}.nii.gz'})
    print(f'  {cid} -> {safe}  tumor voxels={int(arr_bin.sum())}')

dataset = {
    'name': 'Task512_QIN_Tumor10',
    'description': 'QIN Lung CT tumor-only subset (10 cases with focal-tumor segs).',
    'reference': 'QIN Lung CT (TCIA)',
    'licence': 'CC-BY-NC',
    'release': '1.0 (2026-06-22)',
    'tensorImageSize': '4D',
    'modality': {'0': 'CT'},
    'labels': {'0': 'background', '1': 'tumor'},
    'numTraining': len(training),
    'numTest': 0,
    'training': training,
    'test': []
}
with open(f'{DST}/dataset.json', 'w') as f:
    json.dump(dataset, f, indent=2)
print(f'Wrote {DST}/dataset.json with {len(training)} cases.')
