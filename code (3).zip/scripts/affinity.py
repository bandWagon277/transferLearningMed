"""Yang-2024-style source-target affinity AND Jon's latent-space similarity.

Two complementary metrics for transfer-learning planning:

1. **Data-side** (Yang 2024, function `affinity_matrix`): how different are
   the raw images/masks between two datasets?

       D_image  = sliced Wasserstein on PCA-16 image features
       D_mask   = 1 - SSIM(prototype_mask_A, prototype_mask_B)

   Higher D => smaller affinity => transfer expected to be harder.

2. **Model-side** (Jon 2026-05-30, function `latent_self_similarity`): given
   two encoders trained on different datasets, do they embed the same probe
   image more similarly to itself than to other images?

       score_AB(x) = sim(f_A(x), f_B(x)) / mean_{y!=x} sim(f_A(x), f_B(y))

   sim is cosine similarity in a per-encoder PCA-reduced latent space.
   score >> 1 means the two encoders share representation structure for x.
   Averaged over a probe set this gives a single representation-overlap
   score per encoder pair.

Usage (data-side):
    python code/affinity.py data \\
        --dataset brats_flair:/path/to/BraTS \\
        --dataset msd:/path/to/MSD_Task06 \\
        --out runs/affinity_0522.json

Usage (model-side):
    python code/affinity.py latent \\
        --encoder brats:code/pretrained/brats_flair_pretrain/brats_vanilla_kfold/fold0/best.pt \\
        --encoder msd:code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt \\
        --probe-root data/BraTS2021_Training --probe-layout brats_flair \\
        --out runs/latent_sim_0531.json

Both subcommands write JSON. The Yang-side uses SLICED Wasserstein with 100
random 1D projections (no POT dependency).
"""
from __future__ import annotations
import argparse, glob, json, os
from dataclasses import dataclass

import numpy as np
import nibabel as nib
from scipy.ndimage import zoom
from scipy.stats import wasserstein_distance
from skimage.metrics import structural_similarity as ssim
from sklearn.decomposition import PCA

DOWNSAMPLE_TO = (64, 64, 64)
N_PCA = 16
N_PROJECTIONS = 100
RNG = np.random.default_rng(42)


@dataclass
class DatasetSpec:
    name: str
    root: str
    layout: str  # 'msd' | 'qin' | 'brats_flair' | 'lgg' | 'generic'


def list_cases(spec: DatasetSpec) -> list[dict]:
    """Return a list of {'image': path, 'label': path} for the dataset."""
    if spec.layout == 'msd':
        return [
            {'image': p, 'label': os.path.join(spec.root, 'labelsTr', os.path.basename(p))}
            for p in sorted(glob.glob(os.path.join(spec.root, 'imagesTr', '*.nii.gz')))
            if not os.path.basename(p).startswith('._') and
            os.path.exists(os.path.join(spec.root, 'labelsTr', os.path.basename(p)))
        ]
    elif spec.layout == 'qin':
        return [
            {'image': os.path.join(d, 'image.nii.gz'),
             'label': os.path.join(d, 'label.nii.gz')}
            for d in sorted(glob.glob(os.path.join(spec.root, '*')))
            if os.path.isdir(d) and
            os.path.exists(os.path.join(d, 'image.nii.gz')) and
            os.path.exists(os.path.join(d, 'label.nii.gz'))
        ]
    elif spec.layout == 'brats_flair':
        cases = []
        for d in sorted(glob.glob(os.path.join(spec.root, 'BraTS2021_*'))):
            cid = os.path.basename(d)
            img = os.path.join(d, f'{cid}_flair.nii.gz')
            lbl = os.path.join(d, f'{cid}_seg.nii.gz')
            if os.path.exists(img) and os.path.exists(lbl):
                cases.append({'image': img, 'label': lbl})
        return cases
    elif spec.layout == 'lgg':
        # Buda LGG-MRI: per-patient folder, slice stacks. Skip for now —
        # needs the slice-stacking helper. Caller can build NIfTI offline.
        cases = []
        for d in sorted(glob.glob(os.path.join(spec.root, '*'))):
            img = os.path.join(d, 'image.nii.gz')
            lbl = os.path.join(d, 'label.nii.gz')
            if os.path.exists(img) and os.path.exists(lbl):
                cases.append({'image': img, 'label': lbl})
        return cases
    else:
        raise ValueError(f'unknown layout {spec.layout!r}')


def load_and_resample(path: str, target_shape=DOWNSAMPLE_TO, is_label=False):
    """Load a NIfTI volume and resample to target_shape (trilinear / nearest)."""
    img = nib.load(path).get_fdata().astype(np.float32)
    if img.ndim == 4:
        img = img[..., 0]
    factors = [t / s for t, s in zip(target_shape, img.shape)]
    order = 0 if is_label else 1
    arr = zoom(img, factors, order=order)
    # crop / pad to exact shape (zoom can be off-by-one)
    out = np.zeros(target_shape, dtype=np.float32)
    sl = tuple(slice(0, min(a, b)) for a, b in zip(arr.shape, target_shape))
    out[sl] = arr[sl]
    return out


def binarize_label(arr: np.ndarray, layout: str) -> np.ndarray:
    """Binarize a label volume to {0, 1}.

    For BraTS, the raw labels are {0, 1, 2, 4}; WT = any of {1,2,4} > 0.
    For everything else, treat any non-zero voxel as foreground.
    """
    return (arr > 0).astype(np.float32)


def image_features_per_case(volume: np.ndarray, n_pca: int) -> np.ndarray:
    """Flatten + PCA-reduce a single 64^3 volume to n_pca floats."""
    # The flat vector is the case-level feature. PCA across cases is fit
    # outside this function. Here we just normalize and flatten.
    v = volume.flatten()
    # Per-volume z-score so MR / CT scales don't dominate Wasserstein.
    v = (v - v.mean()) / (v.std() + 1e-6)
    return v


def sliced_wasserstein(X: np.ndarray, Y: np.ndarray,
                       n_proj: int = N_PROJECTIONS) -> float:
    """Sliced Wasserstein distance between two sets of d-dim feature vectors.

    Average of 1D Wasserstein over `n_proj` random unit projections. No POT
    dependency; uses scipy.stats.wasserstein_distance per projection.
    """
    d = X.shape[1]
    rng = np.random.default_rng(0)
    projs = rng.standard_normal((n_proj, d))
    projs /= np.linalg.norm(projs, axis=1, keepdims=True) + 1e-12
    dists = []
    for p in projs:
        dists.append(wasserstein_distance(X @ p, Y @ p))
    return float(np.mean(dists))


def mask_prototype(masks: list[np.ndarray]) -> np.ndarray:
    """Per-voxel mean mask after stacking. All inputs must be same shape."""
    return np.mean(np.stack(masks, axis=0), axis=0)


def mask_distance(proto_a: np.ndarray, proto_b: np.ndarray) -> float:
    """1 - SSIM. Higher = more different shape distribution."""
    s = ssim(proto_a, proto_b, data_range=1.0)
    return float(1.0 - s)


def compute_dataset_stats(spec: DatasetSpec, max_cases: int = 50):
    """Load up to max_cases volumes + masks and return:
        feature_matrix [N x prod(DOWNSAMPLE_TO)] flattened image features
        prototype_mask  [DOWNSAMPLE_TO] mean binary mask
    """
    cases = list_cases(spec)
    if not cases:
        raise FileNotFoundError(f'no cases for {spec.name} under {spec.root}')
    cases = cases[:max_cases]
    print(f'[{spec.name}] {len(cases)} cases')
    feats, masks = [], []
    for i, c in enumerate(cases):
        try:
            img = load_and_resample(c['image'], is_label=False)
            lbl = load_and_resample(c['label'], is_label=True)
            lbl = binarize_label(lbl, spec.layout)
            feats.append(image_features_per_case(img, N_PCA))
            masks.append(lbl)
        except Exception as e:
            print(f'  [{spec.name}] skip case {i}: {e}')
    if not feats:
        raise RuntimeError(f'no usable cases for {spec.name}')
    feats = np.stack(feats, axis=0)
    proto = mask_prototype(masks)
    return feats, proto


def fit_global_pca(all_features: dict[str, np.ndarray], n_pca: int = N_PCA) -> PCA:
    """Fit a SHARED PCA across all datasets' image features so the reduced
    coords live in the same space.
    """
    X = np.concatenate(list(all_features.values()), axis=0)
    # PCA constraint: n_components <= min(n_samples, n_features). Clamp.
    effective_n = min(n_pca, X.shape[0] - 1, X.shape[1])
    if effective_n < n_pca:
        print(f'[pca] WARN: clamping n_components from {n_pca} to {effective_n} '
              f'(n_samples={X.shape[0]}, n_features={X.shape[1]})')
    pca = PCA(n_components=effective_n, random_state=42)
    pca.fit(X)
    print(f'[pca] fit on {X.shape[0]} cases x {X.shape[1]} dim -> {effective_n} components; '
          f'explained variance ratio sum = {pca.explained_variance_ratio_.sum():.3f}')
    return pca


def affinity_matrix(specs: list[DatasetSpec], max_cases: int = 50):
    stats = {s.name: compute_dataset_stats(s, max_cases=max_cases) for s in specs}
    raw_feats = {n: f for n, (f, _) in stats.items()}
    pca = fit_global_pca(raw_feats)
    pca_feats = {n: pca.transform(f) for n, f in raw_feats.items()}
    protos = {n: p for n, (_, p) in stats.items()}

    names = [s.name for s in specs]
    D_img = np.zeros((len(names), len(names)))
    D_msk = np.zeros((len(names), len(names)))
    for i, a in enumerate(names):
        for j, b in enumerate(names):
            if i == j:
                continue
            D_img[i, j] = sliced_wasserstein(pca_feats[a], pca_feats[b])
            D_msk[i, j] = mask_distance(protos[a], protos[b])
    return names, D_img, D_msk, pca


def parse_dataset_arg(s: str) -> DatasetSpec:
    """Parse 'name:layout:/path' or 'name:/path' (with default layout=name)."""
    parts = s.split(':', 2)
    if len(parts) == 2:
        name, path = parts
        layout = name
    else:
        name, layout, path = parts
    return DatasetSpec(name=name, root=path, layout=layout)


# ----------------------------------------------------------------------
# Jon's model-side latent-space similarity
# ----------------------------------------------------------------------
#
# Concept (email_xuewei_0530.md item 6): given two encoders trained on
# different datasets, feed the same probe image x into both, compare the
# resulting bottleneck activations. A "high" cross-encoder similarity for
# x with itself (versus x with random other y) means the two encoders have
# learned overlapping representations for x.
#
# Implementation:
#   1. For each encoder, register a forward hook on its bottleneck module
#      (deepest submodule of the MONAI UNet — `model.1.submodule.1.submodule.
#      1.submodule.1.submodule`). The hook stores the post-bottleneck tensor.
#   2. Push each probe image once through each encoder, collect a flat
#      feature vector per (encoder, image).
#   3. Per-encoder PCA-reduce flattened bottleneck features to LATENT_PCA dim.
#      (Each encoder has its own PCA basis — Jon's metric just needs the two
#      embeddings to be in fixed-dim spaces, not aligned.)
#   4. Cosine-normalize each PCA-reduced vector so the dot products live in
#      [-1, 1] and the ratio is interpretable.
#   5. For each probe i:
#          sim(i)      = <z_A^i, z_B^i>                          (diagonal)
#          baseline(i) = mean_{j != i} <z_A^i, z_B^j>            (off-diag)
#          score(i)    = sim(i) / baseline(i)                    if baseline > 0
#                      = +inf if baseline ≤ 0 (random sims happen to cancel
#                        out, sim is meaningful) — flagged in output.
#   6. Aggregate: mean and std of `score` over probes.

LATENT_PCA = 16


# ----------------------------------------------------------------------
# Pairwise similarity scoring functions (jon_metric & orthohash_metric)
# ----------------------------------------------------------------------
#
# Both consume two row-aligned matrices Za, Zb of shape (N, *) where row i
# is the same probe x_i seen by encoder A vs B (after per-encoder PCA, NOT
# necessarily normalized). They return dicts of summary scalars.
#
# `jon_metric` (Jon 2026-05-30): mean over probes of `cos(z_a^i, z_b^i) -
# mean_{j!=i} cos(z_a^i, z_b^j)`. Numerically stable in [-2, 2]. Treats
# all off-diagonal probes as equally-weighted distractors.
#
# `orthohash_metric` (Hoe NeurIPS 2021 §3.1–3.2): treats each probe's
# similarity row as a `softmax(scaled-cos)` retrieval problem. For probe
# i with `s_ij = (1/T) · cos(z_a^i, z_b^j)`, the loss is
#     L_OH = -1/N · Σ_i log[ exp(s_ii) / Σ_j exp(s_ij) ]
# and `accuracy_at_1` = fraction of probes where argmax_j s_ij == i.
# Lower L_OH = better calibrated matching; reaches 0 only when each
# probe's diagonal cosine is much larger than every off-diagonal.
# Temperature T controls how peaked the softmax is; default T = 1/sqrt(d)
# matches the scaled-dot-product convention.

def _ensure_normalized_padded(Za: np.ndarray, Zb: np.ndarray):
    """L2-normalize per row, then zero-pad the narrower matrix so columns
    align (PCA component count may differ when N < n_pca for one encoder)."""
    Za = Za / (np.linalg.norm(Za, axis=1, keepdims=True) + 1e-12)
    Zb = Zb / (np.linalg.norm(Zb, axis=1, keepdims=True) + 1e-12)
    if Za.shape[1] != Zb.shape[1]:
        d = max(Za.shape[1], Zb.shape[1])
        if Za.shape[1] < d:
            Za = np.pad(Za, ((0, 0), (0, d - Za.shape[1])))
        if Zb.shape[1] < d:
            Zb = np.pad(Zb, ((0, 0), (0, d - Zb.shape[1])))
    return Za, Zb


def jon_metric(Za: np.ndarray, Zb: np.ndarray) -> dict:
    Za, Zb = _ensure_normalized_padded(Za, Zb)
    S = Za @ Zb.T
    n = S.shape[0]
    diag = np.diag(S)
    row_off = (S.sum(axis=1) - diag) / max(1, n - 1)
    gap = diag - row_off
    with np.errstate(divide='ignore', invalid='ignore'):
        ratio = np.where(np.abs(row_off) > 1e-3, diag / row_off, np.nan)
    return {
        'mean_gap':       float(gap.mean()),
        'median_gap':     float(np.median(gap)),
        'std_gap':        float(gap.std()),
        'mean_diag_cos':  float(diag.mean()),
        'mean_offdiag_cos': float(row_off.mean()),
        'mean_ratio':     float(np.nanmean(ratio)) if np.isfinite(ratio).any() else float('nan'),
        'median_ratio':   float(np.nanmedian(ratio)) if np.isfinite(ratio).any() else float('nan'),
        'n_probes_ratio_valid': int(np.isfinite(ratio).sum()),
        'n_probes':       int(n),
    }


def orthohash_metric(Za: np.ndarray, Zb: np.ndarray,
                     T: float | None = None) -> dict:
    """OrthoHash-style metric (Hoe NeurIPS 2021 §3.1–3.2).

    Each row of the cosine matrix S = Za @ Zb.T is treated as a softmax
    distribution over N "class prototypes," and the diagonal is the
    correct class. The mean negative log-likelihood (`L_OH`) is the loss;
    `accuracy_at_1` reports how often the diagonal wins argmax.

    Parameters
    ----------
    T : temperature for the softmax. If None, defaults to 1/sqrt(d) — the
        scaled-dot-product attention convention. OrthoHash uses T = 1/K
        with K = number of hash bits (here, the PCA dim).
    """
    Za, Zb = _ensure_normalized_padded(Za, Zb)
    n, d = Za.shape
    if T is None:
        T = 1.0 / float(np.sqrt(max(1, d)))
    S = (Za @ Zb.T) / T                                # (n, n)
    # Numerically-stable log-softmax over each row.
    S_max = S.max(axis=1, keepdims=True)
    logZ = S_max.squeeze(-1) + np.log(np.exp(S - S_max).sum(axis=1))
    log_p_diag = np.diag(S) - logZ                     # log P(diag | row)
    L_OH = float(-np.mean(log_p_diag))
    # Uniform-distractor baseline: -log(1/n) = log n
    L_OH_random = float(np.log(max(1, n)))
    acc1 = float(np.mean(np.argmax(S, axis=1) == np.arange(n)))
    # Gap of mean-log-prob between diagonal vs. uniform-distractor offdiag:
    #   diag contribution = log P(i=i) ; uniform offdiag = log(1/n) when
    #   the row is flat. The signed gap is the diagonal "log-odds advantage."
    log_p_offdiag_uniform = -L_OH_random
    return {
        'T':                       float(T),
        'L_OH':                    L_OH,
        'L_OH_random_baseline':    L_OH_random,
        'L_OH_normalized':         float(L_OH / max(1e-9, L_OH_random)),
        'accuracy_at_1':           acc1,
        'log_odds_advantage':      float(np.mean(log_p_diag) - log_p_offdiag_uniform),
        'n_probes':                int(n),
        'feature_dim_after_pad':   int(d),
    }


def _bottleneck_module(model: 'torch.nn.Module') -> 'torch.nn.Module':
    """Return the MONAI UNet's deepest submodule (bottleneck), reached via
    the nested `submodule` chain used by MONAI's UNet construction.

    Path: `model.1.submodule.1.submodule.1.submodule.1.submodule` —
    matches the BOTTLENECK_PREFIX freeze chain in pretrain_oktaykurt.py
    (a 5-level UNet has 4 down-up pairs around the bottleneck).
    """
    m = model.model[1].submodule[1].submodule[1].submodule[1].submodule
    return m


def _encoder_ladder_modules(model: 'torch.nn.Module') -> dict:
    """5 capture points across the encoder of a 5-level MONAI UNet
    (channels of length 5, strides of length 4).

    Returns an OrderedDict-style dict {layer_name -> nn.Module} so the
    caller can register one forward hook per entry. Ordered shallow->deep.
    """
    m = model.model
    return {
        'L0_stem':       m[0],
        'L1_down':       m[1].submodule[0],
        'L2_down':       m[1].submodule[1].submodule[0],
        'L3_down':       m[1].submodule[1].submodule[1].submodule[0],
        'L4_bottleneck': m[1].submodule[1].submodule[1].submodule[1].submodule,
    }


def _full_ladder_modules(model: 'torch.nn.Module') -> dict:
    """Like _encoder_ladder_modules but also adds decoder-side capture
    points. Per the 2026-06-08 methodology consult (e): UNet
    segmentation is not classification, so encoder-only ladders miss
    where skip connections + decoder layers carry localization/mask
    information. Add the outermost-decoder up-conv (`D1_up`) and
    second-outermost (`D2_up`).

    Falls back to encoder-only if the decoder paths aren't present
    in this model (shouldn't happen for our 5-level UNet but be safe).
    """
    out = _encoder_ladder_modules(model)
    m = model.model
    try:
        out['D1_up_outer'] = m[1].submodule[2]                              # outermost up
    except Exception:
        pass
    try:
        out['D2_up_inner'] = m[1].submodule[1].submodule[2]                 # next outer up
    except Exception:
        pass
    return out


# ----------------------------------------------------------------------
# Linear CKA (Kornblith 2019, HSIC form)
# ----------------------------------------------------------------------
#
# For two centered feature matrices X (n x d_x) and Y (n x d_y):
#
#     CKA(X, Y) = || X̃^T Ỹ ||_F^2  /  ( ||X̃^T X̃||_F * ||Ỹ^T Ỹ||_F )
#
# where ~ denotes per-feature centering across the n probes. This is the
# linear-kernel HSIC normalized to [0, 1]; CKA(X, X) = 1, CKA(X, random)
# ~ 0 for n >> 1. Crucially CKA is invariant to orthogonal rotations and
# isotropic rescaling of X or Y, so it compares two encoders whose feature
# dimensions and bases differ — exactly the f_S vs. f_{S->T} situation.

def linear_cka(X: np.ndarray, Y: np.ndarray) -> float:
    Xc = X - X.mean(axis=0, keepdims=True)
    Yc = Y - Y.mean(axis=0, keepdims=True)
    num   = float(np.linalg.norm(Yc.T @ Xc, ord='fro') ** 2)
    den_x = float(np.linalg.norm(Xc.T @ Xc, ord='fro'))
    den_y = float(np.linalg.norm(Yc.T @ Yc, ord='fro'))
    return num / (den_x * den_y + 1e-12)


# ----------------------------------------------------------------------
# Codex-recommended additions (2026-06-08 methodology consult)
# ----------------------------------------------------------------------
#
# Three companions to linear CKA:
#
#   procrustes_shape_distance  -- Williams 2021 generalized shape metric;
#       d_P^2(X, Y) = 2 - 2 ||X^T Y||_*  after centering + Frobenius
#       normalization, where ||.||_* is the nuclear (trace) norm. Better
#       metric behavior than CKA: triangle inequality holds, rotation
#       invariance is the only invariance.
#
#   rsa_spearman                -- representational similarity analysis:
#       build within-encoder cosine-distance RDM per encoder, then
#       Spearman-correlate the upper triangles. Insensitive to feature
#       basis on either side; captures whether the two encoders organize
#       the same probes similarly. Cleanest cross-encoder "geometry"
#       statistic at our scale.
#
#   null_corrected_cka_with_ci  -- linear CKA point estimate + N_boot case
#       bootstrap CI + N_perm row-permutation null. Returns the
#       null-corrected score R = (CKA - median_null) / (1 - median_null).
#       Permutation null is the right baseline at n=40 where raw CKA is
#       heavily upward-biased.


def procrustes_shape_distance(X: np.ndarray, Y: np.ndarray) -> dict:
    """Williams 2021 orthogonal Procrustes shape distance.

    Center per-feature, Frobenius-normalize, then compute the squared
    distance d_P^2 = 2 - 2 * sigma_sum(X^T Y), where sigma_sum is the
    sum of singular values (= nuclear norm). Returns distance + matching
    similarity 1 - d_P^2 / 2 (which equals the nuclear norm for unit-
    normalized inputs). Both invariant to orthogonal rotations of either
    feature space.
    """
    Xc = X - X.mean(axis=0, keepdims=True)
    Yc = Y - Y.mean(axis=0, keepdims=True)
    nX = np.linalg.norm(Xc, ord='fro')
    nY = np.linalg.norm(Yc, ord='fro')
    if nX < 1e-12 or nY < 1e-12:
        return {'d_procrustes': float('nan'), 'sim_procrustes': float('nan')}
    Xn = Xc / nX
    Yn = Yc / nY
    nuc = float(np.linalg.norm(Xn.T @ Yn, ord='nuc'))
    d2 = max(0.0, 2.0 - 2.0 * nuc)
    return {
        'd_procrustes':   float(d2 ** 0.5),
        'sim_procrustes': float(nuc),       # in [0, 1]; 1 == perfect rotation match
    }


def rsa_spearman(X: np.ndarray, Y: np.ndarray) -> dict:
    """Representational similarity analysis (RSA) with cosine RDM + Spearman.

    For each side, build the (n, n) representational dissimilarity matrix
    using cosine distance, then Spearman-correlate the upper triangles.
    rho in [-1, 1]; 1 = identical relational geometry; 0 = unrelated.
    """
    from scipy.stats import spearmanr
    Xn = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
    Yn = Y / (np.linalg.norm(Y, axis=1, keepdims=True) + 1e-12)
    Dx = 1.0 - Xn @ Xn.T
    Dy = 1.0 - Yn @ Yn.T
    iu = np.triu_indices_from(Dx, k=1)
    rho, _ = spearmanr(Dx[iu], Dy[iu])
    if not np.isfinite(rho):
        rho = float('nan')
    return {'rsa_spearman': float(rho)}


def null_corrected_cka_with_ci(X: np.ndarray, Y: np.ndarray,
                                n_boot: int = 200, n_perm: int = 200,
                                seed: int = 0) -> dict:
    """Linear CKA with case-bootstrap CI and row-permutation null.

    Returns:
      cka                : point estimate (same as `linear_cka`)
      cka_ci_lo/hi       : 2.5%/97.5% case-bootstrap quantiles
      null_median        : median CKA under row-permutation null
      null_p95           : 95th-percentile null
      permutation_p_value: fraction of null trials at >= point estimate
      cka_null_corrected : (point - null_median) / (1 - null_median)
                           (the Codex-recommended "R" scale)
    """
    rng = np.random.default_rng(seed)
    n = X.shape[0]
    point = linear_cka(X, Y)

    boot = np.empty(n_boot, dtype=np.float64)
    for b in range(n_boot):
        idx = rng.integers(0, n, size=n)
        boot[b] = linear_cka(X[idx], Y[idx])
    ci_lo, ci_hi = np.quantile(boot, [0.025, 0.975])

    null = np.empty(n_perm, dtype=np.float64)
    for k in range(n_perm):
        perm = rng.permutation(n)
        null[k] = linear_cka(X, Y[perm])
    null_median = float(np.median(null))
    null_p95 = float(np.quantile(null, 0.95))
    p_val = float((null >= point).mean())
    R = (point - null_median) / (1.0 - null_median + 1e-12)
    return {
        'cka':                 float(point),
        'cka_ci_lo':           float(ci_lo),
        'cka_ci_hi':           float(ci_hi),
        'null_median':         null_median,
        'null_p95':            null_p95,
        'permutation_p_value': p_val,
        'cka_null_corrected':  float(R),
        'n_probes':            int(n),
        'n_bootstrap':         int(n_boot),
        'n_permutations':      int(n_perm),
    }


def metric_audit_pair(X: np.ndarray, Y: np.ndarray,
                      n_boot: int = 200, n_perm: int = 200,
                      seed: int = 0) -> dict:
    """Run all three Codex-recommended metrics on a single (X, Y) pair.

    Returns a single dict with `cka_*`, `d_procrustes` / `sim_procrustes`,
    and `rsa_spearman`. Suitable for dropping into a per-layer table.
    """
    out = null_corrected_cka_with_ci(X, Y, n_boot=n_boot, n_perm=n_perm, seed=seed)
    out.update(procrustes_shape_distance(X, Y))
    out.update(rsa_spearman(X, Y))
    return out


def _build_vanilla_unet(in_channels: int, out_channels: int, channels: tuple):
    """Mirror the K-fold UNet build (channels=32,64,128,256,512)."""
    import torch  # local: avoid hard torch dep when only the data CLI is used
    from monai.networks.nets import UNet as MonaiUNet
    return MonaiUNet(spatial_dims=3, in_channels=in_channels,
                     out_channels=out_channels, channels=channels,
                     strides=(2, 2, 2, 2), num_res_units=0)


def _extract_bottleneck_features(
    ckpt_path: str,
    probe_paths: list[str],
    in_channels: int,
    out_channels: int,
    channels: tuple = (32, 64, 128, 256, 512),
    device: str = 'cuda',
    roi: tuple[int, int, int] = (128, 128, 128),
    layout: str = 'msd',
) -> np.ndarray:
    """Run each probe image through the encoder defined by `ckpt_path` and
    return a [N x D] array of flattened bottleneck activations.

    `in_channels` / `out_channels` / `channels` must match how the checkpoint
    was trained. For our K-fold UNets that's (1, 1, (32..512)) for lung CT
    and (4, 3, (32..512)) for BraTS multi-region.

    `layout` controls intensity normalization: 'msd' / 'qin' / 'lgg' use the
    lung-CT HU window [-1000, 300]→[0,1]; 'brats_flair' uses per-volume
    z-score on the FLAIR channel.
    """
    import torch
    model = _build_vanilla_unet(in_channels, out_channels, channels)
    sd = torch.load(ckpt_path, map_location='cpu', weights_only=False)
    sd = sd.get('state_dict', sd) if isinstance(sd, dict) else sd
    model.load_state_dict(sd)
    model.eval().to(device)

    captured = {}

    def hook(_module, _inputs, output):
        captured['z'] = output.detach()

    bn = _bottleneck_module(model)
    handle = bn.register_forward_hook(hook)

    feats = []
    with torch.no_grad():
        for p in probe_paths:
            arr = nib.load(p).get_fdata().astype(np.float32)
            if arr.ndim == 4:
                arr = arr[..., 0]
            # Normalize per layout.
            if layout in ('msd', 'qin', 'lgg', 'qin-lung-ct', 'msd-lung'):
                # HU window → [0, 1].
                arr = np.clip(arr, -1000.0, 300.0)
                arr = (arr - (-1000.0)) / (300.0 - (-1000.0))
            elif layout == 'brats_flair':
                # FLAIR z-score on non-zero voxels.
                mask = arr > 0
                if mask.any():
                    arr = (arr - arr[mask].mean()) / (arr[mask].std() + 1e-6)
            # Center-crop / pad to the training ROI so the bottleneck shape is fixed.
            arr = _center_crop_pad(arr, roi)
            x = torch.from_numpy(arr).float().unsqueeze(0).unsqueeze(0).to(device)
            # For multi-channel encoders (BraTS, 4ch) we tile the single
            # probe channel — adequate for representation overlap checks.
            if in_channels > 1:
                x = x.repeat(1, in_channels, 1, 1, 1)
            _ = model(x)
            feats.append(captured['z'].flatten().cpu().numpy())
    handle.remove()
    return np.stack(feats, axis=0)


def _center_crop_pad(arr: np.ndarray, roi: tuple[int, int, int]) -> np.ndarray:
    out = np.zeros(roi, dtype=arr.dtype)
    src = [slice(max(0, (s - r) // 2), max(0, (s - r) // 2) + min(s, r))
           for s, r in zip(arr.shape, roi)]
    dst = [slice(max(0, (r - s) // 2), max(0, (r - s) // 2) + min(s, r))
           for s, r in zip(arr.shape, roi)]
    out[tuple(dst)] = arr[tuple(src)]
    return out


def _extract_layer_ladder_features(
    ckpt_path: str,
    probe_paths: list[str],
    in_channels: int,
    out_channels: int,
    channels: tuple = (32, 64, 128, 256, 512),
    device: str = 'cuda',
    roi: tuple[int, int, int] = (128, 128, 128),
    layout: str = 'msd',
    random_init_seed: int = 0,
) -> dict:
    """Like _extract_bottleneck_features but captures 5 encoder layers.

    Per-layer features are spatially global-avg-pooled, giving a
    (n_probes, n_channels_at_layer) matrix per layer. Returns
    {layer_name -> np.ndarray}.
    """
    import torch
    model = _build_vanilla_unet(in_channels, out_channels, channels)
    if ckpt_path is None:
        # Random-init noise-floor baseline. Seed is configurable via
        # `random_init_seed` so callers can produce K independent
        # random-init noise floors and report mean +/- std across them
        # (per meetplan0611 item 5).
        torch.manual_seed(int(random_init_seed))
        for p in model.parameters():
            if p.ndim > 1:
                torch.nn.init.kaiming_normal_(p)
            else:
                torch.nn.init.zeros_(p)
    else:
        sd = torch.load(ckpt_path, map_location='cpu', weights_only=False)
        sd = sd.get('state_dict', sd) if isinstance(sd, dict) else sd
        model.load_state_dict(sd)
    model.eval().to(device)

    layer_modules = _full_ladder_modules(model)
    captured = {name: None for name in layer_modules}

    def make_hook(name):
        def _hook(_module, _inputs, output):
            # Global-avg-pool over spatial dims => (B, C).
            captured[name] = output.detach().mean(dim=tuple(range(2, output.ndim)))
        return _hook

    handles = [m.register_forward_hook(make_hook(name))
               for name, m in layer_modules.items()]

    feats_per_layer = {name: [] for name in layer_modules}
    with torch.no_grad():
        for i, p in enumerate(probe_paths):
            arr = nib.load(p).get_fdata().astype(np.float32)
            if arr.ndim == 4:
                arr = arr[..., 0]
            if layout in ('msd', 'qin', 'lgg', 'qin-lung-ct', 'msd-lung'):
                arr = np.clip(arr, -1000.0, 300.0)
                arr = (arr - (-1000.0)) / (300.0 - (-1000.0))
            elif layout == 'brats_flair':
                mask = arr > 0
                if mask.any():
                    arr = (arr - arr[mask].mean()) / (arr[mask].std() + 1e-6)
            arr = _center_crop_pad(arr, roi)
            x = torch.from_numpy(arr).float().unsqueeze(0).unsqueeze(0).to(device)
            if in_channels > 1:
                x = x.repeat(1, in_channels, 1, 1, 1)
            _ = model(x)
            for name in layer_modules:
                feats_per_layer[name].append(captured[name].squeeze(0).cpu().numpy())
            if i == 0:
                print(f'  [ladder] first-probe shapes: '
                      + ', '.join(f'{n}={f[0].shape}' for n, f in feats_per_layer.items()))
    for h in handles:
        h.remove()
    return {name: np.stack(arrs, axis=0) for name, arrs in feats_per_layer.items()}


def before_after_cka(
    f_s_ckpt: str, f_s_in: int, f_s_out: int,
    f_t_ckpt: str, f_t_in: int, f_t_out: int,
    probe_paths: list[str], probe_layout: str,
    channels: tuple = (32, 64, 128, 256, 512),
    device: str = 'cuda',
    roi: tuple[int, int, int] = (128, 128, 128),
) -> dict:
    """Compute per-layer linear CKA between f_S (source pretrain) and
    f_{S->T} (same encoder after target fine-tune), evaluated on target
    probes.

    The two encoders may have different (in_channels, out_channels) because
    the input convolution is reinitialized during cross-modality transfer.
    The probe pipeline upcasts the single-channel probe to the encoder's
    expected channel count via tiling — adequate for representation-overlap
    measurements (and the same convention as Jon's latent-self-similarity).

    Returns {layer_name -> cka_score} for the 5 layer-ladder capture points.
    Also reports diagnostic feature-norm ratios.
    """
    print(f'[cka] f_S      = {f_s_ckpt}  (in={f_s_in}, out={f_s_out})')
    print(f'[cka] f_{{S→T}} = {f_t_ckpt}  (in={f_t_in}, out={f_t_out})')
    print(f'[cka] {len(probe_paths)} {probe_layout} probes')

    feats_s = _extract_layer_ladder_features(
        ckpt_path=f_s_ckpt, probe_paths=probe_paths,
        in_channels=f_s_in, out_channels=f_s_out, channels=channels,
        device=device, roi=roi, layout=probe_layout,
    )
    feats_t = _extract_layer_ladder_features(
        ckpt_path=f_t_ckpt, probe_paths=probe_paths,
        in_channels=f_t_in, out_channels=f_t_out, channels=channels,
        device=device, roi=roi, layout=probe_layout,
    )

    out = {}
    for name in feats_s:
        Xs = feats_s[name]
        Xt = feats_t[name]
        out[name] = {
            'cka': linear_cka(Xs, Xt),
            'd_features': int(Xs.shape[1]),
            'n_probes': int(Xs.shape[0]),
            'feat_norm_ratio_t_over_s': float(
                np.linalg.norm(Xt) / (np.linalg.norm(Xs) + 1e-12)
            ),
        }
    return out


def latent_self_similarity(
    encoder_paths: dict[str, str],
    encoder_io: dict[str, tuple[int, int]],
    probe_paths: list[str],
    probe_layout: str = 'brats_flair',
    channels: tuple = (32, 64, 128, 256, 512),
    n_pca: int = LATENT_PCA,
    device: str = 'cuda',
):
    """Compute Jon's score for every ordered encoder pair.

    Returns a dict mapping `(name_A, name_B)` to:
      mean_score, std_score, median_score, n_probes_used, raw_scores

    `encoder_paths`: {name: ckpt_path}
    `encoder_io`:    {name: (in_channels, out_channels)} — must match the ckpt
    `probe_paths`:   list of NIfTI paths used as probe images for ALL encoders
    `probe_layout`:  intensity-normalization layout for the probes
    """
    # 1) Extract bottleneck features per encoder.
    raw = {}
    for name, ckpt in encoder_paths.items():
        in_ch, out_ch = encoder_io[name]
        print(f'[latent] {name}: extracting from {ckpt}')
        raw[name] = _extract_bottleneck_features(
            ckpt_path=ckpt, probe_paths=probe_paths,
            in_channels=in_ch, out_channels=out_ch,
            channels=channels, device=device, layout=probe_layout,
        )
        print(f'  -> features shape {raw[name].shape}')

    # 2) Per-encoder PCA + cosine normalization.
    reduced = {}
    for name, F in raw.items():
        n_samples, n_features = F.shape
        eff = min(n_pca, n_samples - 1, n_features)
        if eff < n_pca:
            print(f'[latent] WARN {name}: clamping n_pca {n_pca}->{eff} '
                  f'(n_samples={n_samples} n_features={n_features})')
        pca = PCA(n_components=eff, random_state=42).fit(F)
        Z = pca.transform(F)
        Z /= (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)
        reduced[name] = Z

    # 3) Pairwise score per encoder pair.
    #
    # Two ways to summarize cross-encoder agreement for a probe i:
    #   (a) Jon's ratio:  diag_cos(i) / mean_offdiag_cos(i)
    #       Clean when offdiag is well above zero. Explodes (or sign-flips)
    #       when offdiag is near zero or negative — which is the COMMON case
    #       in practice, because randomly-paired latents are near-orthogonal
    #       in any reasonable PCA basis.
    #   (b) cosine gap: diag_cos(i) - mean_offdiag_cos(i)
    #       Numerically stable in [-2, 2]. Cleanly interpretable as
    #       "how much MORE similar is image i to itself across encoders than
    #       to other images." Recommend reporting this as the headline number;
    #       the ratio stays in the JSON for fidelity to Jon's original
    #       formulation.
    names = list(encoder_paths.keys())
    results = {}
    n = len(probe_paths)
    for a in names:
        for b in names:
            if a == b:
                continue
            Za, Zb = reduced[a], reduced[b]
            if Za.shape[1] != Zb.shape[1]:
                d = max(Za.shape[1], Zb.shape[1])
                if Za.shape[1] < d:
                    Za = np.pad(Za, ((0, 0), (0, d - Za.shape[1])))
                if Zb.shape[1] < d:
                    Zb = np.pad(Zb, ((0, 0), (0, d - Zb.shape[1])))
            S = Za @ Zb.T  # [N x N] cosine sim matrix
            diag = np.diag(S)
            row_off_mean = (S.sum(axis=1) - diag) / max(1, n - 1)
            gap = diag - row_off_mean
            with np.errstate(divide='ignore', invalid='ignore'):
                ratio = np.where(np.abs(row_off_mean) > 1e-3,
                                 diag / row_off_mean, np.nan)
            results[f'{a}->{b}'] = {
                'mean_gap': float(gap.mean()),
                'median_gap': float(np.median(gap)),
                'std_gap': float(gap.std()),
                'mean_ratio': float(np.nanmean(ratio)) if np.isfinite(ratio).any() else float('nan'),
                'median_ratio': float(np.nanmedian(ratio)) if np.isfinite(ratio).any() else float('nan'),
                'mean_diag_cos': float(diag.mean()),
                'mean_offdiag_cos': float(row_off_mean.mean()),
                'n_probes': int(n),
                'n_probes_ratio_valid': int(np.isfinite(ratio).sum()),
            }
    return results


def parse_encoder_arg(s: str) -> tuple[str, str]:
    """Parse 'name:/ckpt/path' into (name, path)."""
    name, path = s.split(':', 1)
    return name, path


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest='cmd', required=False)

    # --- data subcommand: Yang 2024 affinity matrix ---
    pd = sub.add_parser('data', help='Yang 2024 data-side affinity matrix')
    pd.add_argument('--dataset', action='append', required=True,
                    help='name:layout:/path  (or name:/path; layout defaults to name)')
    pd.add_argument('--max-cases', type=int, default=50)
    pd.add_argument('--out', required=True)

    # --- latent subcommand: Jon's model-side latent similarity ---
    pl = sub.add_parser('latent', help="Jon's model-side latent similarity")
    pl.add_argument('--encoder', action='append', required=True,
                    help='name:/path/to/best.pt  (repeat for each encoder pair)')
    pl.add_argument('--encoder-io', action='append', default=[],
                    help='name:in_ch:out_ch  (default 1:1 for lung CT; set 4:3 '
                         'for BraTS multi-region)')
    pl.add_argument('--probe-root', required=True,
                    help='Path to a dataset that supplies probe images')
    pl.add_argument('--probe-layout', default='brats_flair',
                    choices=['brats_flair', 'msd', 'qin', 'lgg'])
    pl.add_argument('--max-probes', type=int, default=20)
    pl.add_argument('--device', default='cuda')
    pl.add_argument('--out', required=True)

    # If no subcommand given, default to legacy `data` behavior using top-level
    # `--dataset`/`--max-cases`/`--out` (back-compat with the earlier CLI).
    p.add_argument('--dataset', action='append', help=argparse.SUPPRESS)
    p.add_argument('--max-cases', type=int, default=50, help=argparse.SUPPRESS)
    p.add_argument('--out', help=argparse.SUPPRESS)

    args = p.parse_args()
    if args.cmd is None and args.dataset:
        args.cmd = 'data'  # back-compat

    if args.cmd == 'data':
        specs = [parse_dataset_arg(d) for d in args.dataset]
        names, D_img, D_msk, pca = affinity_matrix(specs, max_cases=args.max_cases)
        affinity = D_img + D_msk
        result = {
            'datasets': names,
            'n_pca_components': N_PCA,
            'n_sliced_projections': N_PROJECTIONS,
            'pca_explained_variance_ratio': pca.explained_variance_ratio_.tolist(),
            'D_image_sliced_wasserstein': D_img.tolist(),
            'D_mask_one_minus_ssim': D_msk.tolist(),
            'D_total_affinity': affinity.tolist(),
        }
        os.makedirs(os.path.dirname(args.out) or '.', exist_ok=True)
        with open(args.out, 'w') as f:
            json.dump(result, f, indent=2)
        print('\n=== Pairwise affinity (higher = more distant) ===')
        print(f"{'':12}", *[f'{n:>10}' for n in names])
        print('D_image (sliced Wasserstein on PCA-16 features):')
        for i, n in enumerate(names):
            print(f'{n:12}', *[f'{D_img[i,j]:>10.3f}' for j in range(len(names))])
        print('D_mask (1 - SSIM on mean masks):')
        for i, n in enumerate(names):
            print(f'{n:12}', *[f'{D_msk[i,j]:>10.3f}' for j in range(len(names))])
        print('D_total = D_image + D_mask:')
        for i, n in enumerate(names):
            print(f'{n:12}', *[f'{affinity[i,j]:>10.3f}' for j in range(len(names))])
        print(f'\n[saved] {args.out}')
        return

    if args.cmd == 'latent':
        encs = dict(parse_encoder_arg(s) for s in args.encoder)
        io = {}
        for s in args.encoder_io:
            n, ic, oc = s.split(':')
            io[n] = (int(ic), int(oc))
        for n in encs:
            io.setdefault(n, (1, 1))  # default to lung-CT shape
        # Collect probes from the chosen root + layout.
        spec = DatasetSpec(name='probe', root=args.probe_root, layout=args.probe_layout)
        cases = list_cases(spec)
        if not cases:
            raise FileNotFoundError(f'no probe cases under {args.probe_root} '
                                    f'with layout={args.probe_layout}')
        probe_paths = [c['image'] for c in cases[:args.max_probes]]
        print(f'[latent] {len(probe_paths)} probes from {args.probe_root} '
              f'(layout={args.probe_layout})')

        scores = latent_self_similarity(
            encoder_paths=encs, encoder_io=io,
            probe_paths=probe_paths, probe_layout=args.probe_layout,
            device=args.device,
        )
        os.makedirs(os.path.dirname(args.out) or '.', exist_ok=True)
        with open(args.out, 'w') as f:
            json.dump({'encoders': encs, 'encoder_io': {k: list(v) for k, v in io.items()},
                       'probes': probe_paths, 'probe_layout': args.probe_layout,
                       'n_pca': LATENT_PCA, 'scores': scores}, f, indent=2)
        print('\n=== Latent self-similarity (higher gap/ratio = more shared representation) ===')
        for pair, s in scores.items():
            print(f'{pair:30}  gap={s["mean_gap"]:+.3f}  '
                  f'ratio={s["mean_ratio"]:+.2f}  '
                  f'(diag cos={s["mean_diag_cos"]:+.3f}, '
                  f'offdiag cos={s["mean_offdiag_cos"]:+.3f}, '
                  f'ratio_valid={s["n_probes_ratio_valid"]}/{s["n_probes"]})')
        print(f'\n[saved] {args.out}')
        return

    p.print_help()
    print(f'\n[saved] {args.out}')


if __name__ == '__main__':
    main()
