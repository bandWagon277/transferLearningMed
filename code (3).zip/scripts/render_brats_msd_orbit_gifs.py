"""3D rotation GIFs with depth-alpha volume rendering (not MIP).

Improvements over v1:

  * **True volume rendering**: front-to-back alpha compositing along the camera
    axis. The viewer can see *through* outside tissue, tumor-adjacent tissue
    is brighter, and depth gives a real 3-D cue.
  * **Tumor-focused emphasis**: voxels inside the GT tumor mask get red tint
    + high alpha; voxels within a soft Euclidean shell around the tumor get
    extra brightness; faraway tissue is dimmed to translucency.
  * **Slower, multi-axis sweep**: 120 frames at 80 ms/frame (~10 s loop).
    Continuous yaw (0->360) with simultaneous pitch oscillation (+-35 deg, one
    cycle) and a slow roll component, so the volume rotates across all three
    axes within one loop -- not just a turntable.

Reads:
  data/.../Task500_BraTS2021/imagesTr/<case>_0000.nii.gz + labelsTr/<case>.nii.gz
  data/.../Task006_Lung/imagesTr/<case>_0000.nii.gz + labelsTr/<case>.nii.gz

Writes (.gif + 6-frame static strip per case):
  deliverable/slides/figures/orbits/v2/<case>_volume.gif
  deliverable/slides/figures/orbits/v2/<case>_volume_strip.png

CPU-only. Designed to be submitted via code/sbatch_orbit_gifs_v2_0629.slurm.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import SimpleITK as sitk
import imageio.v2 as imageio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.ndimage import distance_transform_edt

REPO    = Path("/nfs/turbo/jiankanggroup/gengyh/transferMRI")
RAW     = REPO / "data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data"
OUT_DIR = REPO / "deliverable/slides/figures/orbits/v2"
OUT_DIR.mkdir(parents=True, exist_ok=True)


# ---------- volume preparation ----------

def prep_ct(path: Path, lo_hu: float = -800, hi_hu: float = 150) -> sitk.Image:
    """Lung-window CT, dim the air to zero so the outside doesn't bloom.

    Returns float32 in [0, 1].
    """
    img = sitk.ReadImage(str(path))
    arr = sitk.GetArrayFromImage(img).astype(np.float32)
    arr = np.clip(arr, lo_hu, hi_hu)
    arr = (arr - lo_hu) / (hi_hu - lo_hu)
    # Knock the brightness of generic soft tissue down so the lung+tumor pop.
    # A gamma >1 darkens midtones.
    arr = np.power(arr, 1.4)
    out = sitk.GetImageFromArray(arr)
    out.CopyInformation(img)
    return sitk.Cast(out, sitk.sitkFloat32)


def prep_mri(path: Path) -> sitk.Image:
    img = sitk.ReadImage(str(path))
    arr = sitk.GetArrayFromImage(img).astype(np.float32)
    # Robust min-max scale to 99th percentile of brain voxels.
    p99 = np.percentile(arr[arr > 0], 99) if (arr > 0).any() else arr.max()
    arr = np.clip(arr / (p99 + 1e-6), 0, 1)
    out = sitk.GetImageFromArray(arr)
    out.CopyInformation(img)
    return sitk.Cast(out, sitk.sitkFloat32)


def prep_mask(path: Path) -> sitk.Image:
    m = sitk.ReadImage(str(path))
    arr = (sitk.GetArrayFromImage(m) > 0).astype(np.uint8)
    out = sitk.GetImageFromArray(arr)
    out.CopyInformation(m)
    return sitk.Cast(out, sitk.sitkUInt8)


def precompute_emphasis(mask_np: np.ndarray, shell_mm: float = 25,
                         spacing=(1.0, 1.0, 1.0)) -> np.ndarray:
    """Soft proximity-to-tumor field in [0, 1].

    1.0 inside the mask, falling off to 0 at `shell_mm` away (Euclidean).
    """
    if mask_np.sum() == 0:
        return np.zeros_like(mask_np, dtype=np.float32)
    edt = distance_transform_edt(mask_np == 0, sampling=spacing)
    field = np.clip(1.0 - edt / shell_mm, 0.0, 1.0).astype(np.float32)
    return field


# ---------- multi-axis camera ----------

def camera_angles(n_frames: int = 120):
    """Yaw goes 0->360 once; pitch oscillates +-35 deg once; roll +-25 deg.

    Yields (rx, ry, rz) in radians per frame -- all three axes used per loop.
    """
    for k in range(n_frames):
        frac = k / n_frames
        yaw   = 2 * np.pi * frac
        pitch = np.deg2rad(35.0) * np.sin(2 * np.pi * frac)
        roll  = np.deg2rad(25.0) * np.sin(np.pi * frac)
        yield pitch, roll, yaw  # SetRotation(rx, ry, rz)


# ---------- volume render ----------

def composite_frame(rotated_intensity: np.ndarray,
                     rotated_mask: np.ndarray,
                     rotated_emphasis: np.ndarray,
                     bg: tuple = (245, 245, 248)) -> np.ndarray:
    """Front-to-back alpha compositing along axis 0 (Z, camera depth).

    Returns an HxWx3 uint8 image.
    """
    Z, H, W = rotated_intensity.shape
    I = rotated_intensity
    M = rotated_mask > 0
    E = rotated_emphasis  # 0..1, peaked near tumor

    # Per-voxel alpha. Outside-of-organ stays mostly transparent (low I).
    # Inside tumor mask: high alpha. Within emphasis shell: medium alpha.
    a_tissue = np.clip(I - 0.18, 0, 1) * 0.06   # generic tissue baseline
    a_emph   = np.clip(E, 0, 1) * 0.18           # tumor-region boost
    a_mask   = M.astype(np.float32) * 0.72       # the tumor itself dominates
    alpha    = np.clip(a_tissue + a_emph + a_mask, 0, 0.95)

    # Per-voxel color: gray ramp from intensity, plus red tint inside / near mask.
    # Brighten emphasis voxels via gamma <1.
    I_emph_bright = np.power(np.clip(I + 0.25 * E, 0, 1), 0.85)
    base_gray = I_emph_bright * 255.0
    R = base_gray.copy()
    G = base_gray.copy()
    B = base_gray.copy()
    tint = np.clip(E + M.astype(np.float32), 0, 1)
    R = R * (1 - 0.55 * tint) + 235.0 * (0.55 * tint)
    G = G * (1 - 0.55 * tint) + 35.0  * (0.55 * tint)
    B = B * (1 - 0.55 * tint) + 35.0  * (0.55 * tint)

    color = np.stack([R, G, B], axis=-1)  # (Z, H, W, 3)

    # Front-to-back composite. T = product of (1 - alpha) so far.
    accum = np.zeros((H, W, 3), dtype=np.float32)
    T = np.ones((H, W), dtype=np.float32)
    for z in range(Z):
        a = alpha[z]
        Tw = T * a
        accum += Tw[..., None] * color[z]
        T = T * (1 - a)
        if T.max() < 0.01:
            break
    bg_arr = np.full((H, W, 3), bg, dtype=np.float32)
    img = accum + T[..., None] * bg_arr
    return np.clip(img, 0, 255).astype(np.uint8)


def render_volume_gif(img: sitk.Image, mask: sitk.Image, emphasis: sitk.Image,
                      gif_path: Path, strip_path: Path,
                      n_frames: int = 120, duration: float = 0.08,
                      title: str = ""):
    """Render the full GIF + a 6-frame static strip for the PDF."""
    center = img.TransformContinuousIndexToPhysicalPoint(np.array(img.GetSize()) / 2.0)
    frames = []
    for k, (rx, ry, rz) in enumerate(camera_angles(n_frames)):
        t = sitk.Euler3DTransform()
        t.SetCenter(center)
        t.SetRotation(rx, ry, rz)
        rot_i = sitk.Resample(img,      img,      t, sitk.sitkLinear,         0.0,  img.GetPixelID())
        rot_e = sitk.Resample(emphasis, emphasis, t, sitk.sitkLinear,         0.0, emphasis.GetPixelID())
        rot_m = sitk.Resample(mask,     mask,     t, sitk.sitkNearestNeighbor, 0,  mask.GetPixelID())
        I = sitk.GetArrayFromImage(rot_i).astype(np.float32)
        E = sitk.GetArrayFromImage(rot_e).astype(np.float32)
        M = sitk.GetArrayFromImage(rot_m).astype(np.uint8)
        frame = composite_frame(I, M, E)
        frames.append(frame)
        if k % 20 == 0:
            print(f"  frame {k+1}/{n_frames}")

    imageio.mimsave(str(gif_path), frames, duration=duration)
    print(f"wrote {gif_path}  ({n_frames} frames, {duration*1000:.0f}ms each, "
          f"loop ~{n_frames*duration:.1f}s)")

    # Static 6-frame strip for the PDF
    idx = np.linspace(0, n_frames - 1, 6).astype(int)
    fig, axes = plt.subplots(1, 6, figsize=(14, 2.7))
    for ax, i in zip(axes, idx):
        ax.imshow(frames[i])
        ax.set_title(f"frame {i + 1}/{n_frames}", fontsize=9)
        ax.axis("off")
    fig.suptitle(title, fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.savefig(strip_path, dpi=130, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {strip_path}")


# ---------- entry points ----------

def run_brats():
    case = "BraTS2021_00078"
    img_path  = RAW / "Task500_BraTS2021/imagesTr" / f"{case}_0000.nii.gz"
    mask_path = RAW / "Task500_BraTS2021/labelsTr" / f"{case}.nii.gz"
    img  = prep_mri(img_path)
    mask = prep_mask(mask_path)
    spacing = img.GetSpacing()[::-1]  # numpy is (Z, Y, X)
    emph_np = precompute_emphasis(sitk.GetArrayFromImage(mask),
                                   shell_mm=25, spacing=spacing)
    emph = sitk.GetImageFromArray(emph_np)
    emph.CopyInformation(mask)
    emph = sitk.Cast(emph, sitk.sitkFloat32)

    render_volume_gif(img, mask, emph,
                      gif_path=OUT_DIR / f"{case}_volume.gif",
                      strip_path=REPO / "deliverable/slides/figures/q6_brats_orbit_v2_strip.png",
                      n_frames=120, duration=0.08,
                      title=f"BraTS-21 brain tumor volume rendering -- {case}  "
                            f"(tumor red, peri-tumor brightened, outside translucent)")


def run_msd():
    case = "lung_046"
    img_path  = RAW / "Task006_Lung/imagesTr" / f"{case}_0000.nii.gz"
    mask_path = RAW / "Task006_Lung/labelsTr" / f"{case}.nii.gz"
    img  = prep_ct(img_path, lo_hu=-800, hi_hu=150)
    mask = prep_mask(mask_path)
    spacing = img.GetSpacing()[::-1]
    emph_np = precompute_emphasis(sitk.GetArrayFromImage(mask),
                                   shell_mm=25, spacing=spacing)
    emph = sitk.GetImageFromArray(emph_np)
    emph.CopyInformation(mask)
    emph = sitk.Cast(emph, sitk.sitkFloat32)

    render_volume_gif(img, mask, emph,
                      gif_path=OUT_DIR / f"{case}_volume.gif",
                      strip_path=REPO / "deliverable/slides/figures/q6_msd_orbit_v2_strip.png",
                      n_frames=120, duration=0.08,
                      title=f"MSD-Lung CT volume rendering -- {case}  "
                            f"(tumor red, peri-tumor brightened, outside-lung dimmed)")


if __name__ == "__main__":
    print(">>> BraTS-21 volume render")
    run_brats()
    print(">>> MSD-Lung volume render")
    run_msd()
    print("done.")
