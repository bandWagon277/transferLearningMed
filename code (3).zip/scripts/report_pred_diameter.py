"""Join predicted-mask diameters with GT diameters per (target, init) pair.

For every (tag, task) tuple in RUNS:
  - read fold-0 val cases from splits_final.pkl
  - for each val case:
      * load GT mask (data/nnUNet/.../labelsTr/<case>.nii.gz)
      * load predicted mask (scratch/inference_0624/<tag>/<case>.nii.gz)
      * compute Dice
      * compute volume_cm3 and longest 3D + axial RECIST diameter on each
        via tumor_diameter.case_metrics_from_nifti (largest connected
        component only, which matches the meetplan request to report the
        largest-tumor diameter when prediction is multifocal)
  - write per-case CSV deliverable/measurements/pred_diameter_0624/<tag>.csv
  - aggregate into summary.csv

Run from the repo root:
    python code/report_pred_diameter_0624.py
"""
import csv, os, pickle, sys
import nibabel as nib
import numpy as np

REPO = "/nfs/turbo/jiankanggroup/gengyh/transferMRI"
sys.path.insert(0, f"{REPO}/deliverable/code/scripts")
from tumor_diameter import case_metrics_from_nifti  # noqa: E402

RUNS = [
    ("brats21_scratch", "Task500_BraTS2021"),
    ("brats21_from_msd", "Task500_BraTS2021"),
    ("brats21_from_brats24", "Task500_BraTS2021"),
    ("brats21_from_pool", "Task500_BraTS2021"),
    ("brats24_scratch", "Task502_BraTS2024Post"),
    ("brats24_from_brats21", "Task502_BraTS2024Post"),
    ("brats24_from_pool", "Task502_BraTS2024Post"),
    ("msd_scratch", "Task006_Lung"),
    ("msd_from_brats21", "Task006_Lung"),
    ("msd_from_pool", "Task006_Lung"),
    ("msd_deep_from_brats21", "Task006_Lung"),
    ("rider_scratch", "Task514_RIDER"),
    ("rider_from_brats21", "Task514_RIDER"),
    ("qin10_scratch", "Task512_QIN_Tumor10"),
    ("qin10_from_brats21", "Task512_QIN_Tumor10"),
]

OUT = f"{REPO}/deliverable/measurements/pred_diameter_0624"
os.makedirs(OUT, exist_ok=True)


def dice(a, b):
    a = (a > 0); b = (b > 0); s = int(a.sum()) + int(b.sum())
    return 1.0 if s == 0 else float(2 * int((a & b).sum()) / s)


def pred_name(cid):
    # inference.py mangles '_0000' from the input filename.  Apply the same
    # transformation to find the prediction file.
    return f"{cid}_0000.nii.gz".replace("_0000", "")


def val_cases(task):
    p = f"{REPO}/data/nnUNet/nnUNet_preprocessed/{task}/splits_final.pkl"
    with open(p, "rb") as f:
        splits = pickle.load(f)
    return list(splits[0]["val"])


summary = []
for tag, task in RUNS:
    rows = []
    labels = f"{REPO}/data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data/{task}/labelsTr"
    preds = f"{REPO}/scratch/inference_0624/{tag}"
    if not os.path.isdir(preds):
        print(f"skip {tag}: no predictions directory")
        continue
    cases = val_cases(task)
    for cid in cases:
        gt_path = f"{labels}/{cid}.nii.gz"
        pr_path = f"{preds}/{pred_name(cid)}"
        if not os.path.exists(pr_path) or not os.path.exists(gt_path):
            continue
        gt = (nib.load(gt_path).get_fdata() > 0).astype(np.uint8)
        pr = (nib.load(pr_path).get_fdata() > 0).astype(np.uint8)
        if gt.shape != pr.shape:
            print(f"shape mismatch {cid}: gt={gt.shape} pred={pr.shape}, skip")
            continue
        gm = case_metrics_from_nifti(gt_path)
        pm = case_metrics_from_nifti(pr_path)
        rows.append({
            "tag": tag, "task": task, "case": cid,
            "dice": dice(pr, gt),
            "gt_volume_cm3": gm.volume_cm3,
            "pred_volume_cm3": pm.volume_cm3,
            "gt_diameter_3d_mm": gm.diameter_3d_mm,
            "pred_diameter_3d_mm": pm.diameter_3d_mm,
            "abs_err_3d_mm": abs(pm.diameter_3d_mm - gm.diameter_3d_mm),
            "gt_diameter_axial_mm": gm.diameter_axial_mm,
            "pred_diameter_axial_mm": pm.diameter_axial_mm,
            "abs_err_axial_mm": abs(pm.diameter_axial_mm - gm.diameter_axial_mm),
        })
    if rows:
        with open(f"{OUT}/{tag}.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        summary.append({
            "tag": tag, "task": task, "n": len(rows),
            "mean_dice": float(np.mean([r["dice"] for r in rows])),
            "mean_abs_err_3d_mm": float(np.mean([r["abs_err_3d_mm"] for r in rows])),
            "mean_abs_err_axial_mm": float(np.mean([r["abs_err_axial_mm"] for r in rows])),
        })
        print(f"{tag:30s}  n={len(rows):4d}  meanDice={summary[-1]['mean_dice']:.3f}  "
              f"meanAbsErr3D={summary[-1]['mean_abs_err_3d_mm']:.2f}mm")
    else:
        print(f"skip {tag}: no overlapping cases")

if summary:
    with open(f"{OUT}/summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        w.writeheader()
        w.writerows(summary)
print(f"\nwrote per-tag CSVs + summary.csv to {OUT}")
