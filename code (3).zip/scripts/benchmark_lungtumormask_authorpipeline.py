"""LungTumorMask inference in the AUTHOR'S INTENDED pipeline.

Reproduces `lungtumormask/dataprocessing.py` + `mask.py` with the modern
`lungmask` v0.2 API (the LungTumorMask repo pins lungmask to an older
git commit; we shim the few missing symbols).

Steps per case (matches author's published preprocessing 1:1):
  1. Run lungmask.LMInferer on the CT -> labels (1 = right lung, 2 = left lung).
  2. For each lung label separately:
       a. Crop the CT to that lung's tight bounding box.
       b. Clip HU to [-1024, +1000].
       c. NormalizeIntensityd (PER-CASE z-score; not nnU-Net's global stats).
       d. Spacingd to 1 x 1 x 1.5 mm.
       e. DivisiblePadd to /16.
  3. Forward through the UNet (`dc_student.pth` model1.* weights).
  4. Per-lung post: remove pad -> Resize back to bbox -> threshold 0.5 ->
     stitch back into original volume.
  5. Merge left+right with max.
  6. (Optional) zero out predictions outside the lung mask.

Outputs:
  deliverable/measurements/lungtumormask_v2_authorpipeline_0630/<task>.csv
  + summary.csv
"""
from __future__ import annotations
import argparse, csv, json, pickle, time
from pathlib import Path
import numpy as np
import nibabel as nib
import torch
from monai.networks.nets import UNet
from scipy.ndimage import label as cc_label

# --- lungmask (modern API) -------------------------------------------------
from lungmask import LMInferer  # exposes apply(sitk_image) -> np.ndarray
import SimpleITK as sitk

# --- LungTumorMask vendored transforms (matches dataprocessing.py exactly) -
from monai.transforms import (Compose, LoadImaged, ThresholdIntensityd,
                               EnsureChannelFirstd, NormalizeIntensityd,
                               SpatialCropd, DivisiblePadd, Spacingd, ToTensord)

REPO = Path("/nfs/turbo/jiankanggroup/gengyh/transferMRI")
RAW  = REPO / "data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data"
CKPT = REPO / "code/pretrained/lungtumormask/dc_student.pth"
OUT  = REPO / "deliverable/measurements/lungtumormask_v2_authorpipeline_0630"
OUT.mkdir(parents=True, exist_ok=True)


# --------------- model load (identical to v1) -----------------------------

def load_model(device: torch.device) -> torch.nn.Module:
    m = UNet(spatial_dims=3, in_channels=1, out_channels=1,
             channels=(64, 128, 256, 512, 1024),
             strides=(2, 2, 2, 2), num_res_units=0)
    sd = torch.load(CKPT, map_location="cpu", weights_only=False)
    sd = sd.get("state_dict", sd) if isinstance(sd, dict) else sd
    renamed = {k.replace("model1.", "model.", 1): v
               for k, v in sd.items() if k.startswith("model1.")}
    missing, unexpected = m.load_state_dict(renamed, strict=True)
    print(f"[model] loaded {len(renamed)} tensors, missing={missing}, unexpected={unexpected}")
    return m.to(device).eval()


# --------------- author-pipeline preprocessing (vendored) -----------------

_inferer = None
def _get_inferer():
    global _inferer
    if _inferer is None:
        _inferer = LMInferer(modelname="R231")
    return _inferer


def lung_mask(image_path: Path) -> np.ndarray:
    """Return uint8 lung labels (0=bg, 1=right, 2=left), aligned with the CT array."""
    sitk_img = sitk.ReadImage(str(image_path))
    labels = _get_inferer().apply(sitk_img)  # shape (Z, Y, X)
    # The LungTumorMask code expected mask in (X, Y, Z) order (`np.swapaxes(0, 2)`).
    # We follow the same convention here so calculate_extremes/SpatialCropd work as-is.
    return np.swapaxes(labels, 0, 2).astype(np.uint8)


def calculate_extremes(image, annotation_value):
    """Bounding box of voxels where image == annotation_value.

    Copied 1:1 from lungtumormask/dataprocessing.py.
    """
    holder = np.copy(image)
    x_min = float('inf'); x_max = 0
    y_min = float('inf'); y_max = 0
    z_min = -1;           z_max = 0
    holder[holder != annotation_value] = 0
    holder = np.swapaxes(holder, 0, 2)
    for i, layer in enumerate(holder):
        if np.amax(layer) < 1: continue
        if z_min == -1: z_min = i
        z_max = i
        y = np.any(layer, axis=1); x = np.any(layer, axis=0)
        y_minl, y_maxl = np.argmax(y) + 1, layer.shape[0] - np.argmax(np.flipud(y))
        x_minl, x_maxl = np.argmax(x) + 1, layer.shape[1] - np.argmax(np.flipud(x))
        if y_minl < y_min: y_min = y_minl
        if x_minl < x_min: x_min = x_minl
        if y_maxl > y_max: y_max = y_maxl
        if x_maxl > x_max: x_max = x_maxl
    if z_min == -1:
        return None
    return ((int(x_min), int(x_max)), (int(y_min), int(y_max)),
            (int(z_min), int(z_max)))


def process_lung_scan(image_path: Path, extremes):
    """One-lung preprocessing -- identical to lungtumormask/dataprocessing.py."""
    scan_dict = {"image": str(image_path)}
    transformer = Compose([
        LoadImaged(keys=["image"]),
        EnsureChannelFirstd(keys=["image"], channel_dim="no_channel"),
        ThresholdIntensityd(keys=["image"], above=False, threshold=1000, cval=1000),
        ThresholdIntensityd(keys=["image"], above=True,  threshold=-1024, cval=-1024),
        NormalizeIntensityd(keys=["image"]),
        SpatialCropd(keys=["image"],
                     roi_start=(extremes[0][0], extremes[1][0], extremes[2][0]),
                     roi_end  =(extremes[0][1], extremes[1][1], extremes[2][1])),
        Spacingd(keys=["image"], pixdim=(1.0, 1.0, 1.5)),
        DivisiblePadd(keys=["image"], k=16, mode="constant"),
        ToTensord(keys=["image"]),
    ])
    return transformer(scan_dict)["image"]


def remove_pad(mask, original):
    """Trim the 'divisible-by-16' padding using the unpadded shape."""
    def edges(a):
        nonzero = np.nonzero(np.any(np.any(a, axis=1), axis=1))[0]
        return (int(nonzero[0]), int(nonzero[-1] + 1)) if len(nonzero) else (0, a.shape[0])
    a_mn, a_mx = edges(original)
    b_mn, b_mx = edges(original.swapaxes(0, 1))
    c_mn, c_mx = edges(original.swapaxes(0, 2))
    return mask[a_mn:a_mx, b_mn:b_mx, c_mn:c_mx]


def voxel_resize(arr, bbox):
    from monai.transforms import Resize
    target = (bbox[0][1] - bbox[0][0], bbox[1][1] - bbox[1][0], bbox[2][1] - bbox[2][0])
    return Resize(target, mode="trilinear")(np.expand_dims(arr, 0))[0]


def stitch(full_shape, cropped, bbox):
    out = np.zeros(full_shape, dtype="float32")
    out[bbox[0][0]:bbox[0][1], bbox[1][0]:bbox[1][1], bbox[2][0]:bbox[2][1]] = cropped
    return out


# --------------- main loop ------------------------------------------------

def dice(p, g):
    p, g = p > 0, g > 0
    s = p.sum() + g.sum()
    return float(2 * np.logical_and(p, g).sum() / s) if s else 0.0


def longest_diameter_3d(mask, spacing):
    if mask.sum() == 0: return 0.0
    lab, n = cc_label(mask)
    if n == 0: return 0.0
    sizes = np.bincount(lab.ravel()); sizes[0] = 0
    coords = np.argwhere(lab == int(np.argmax(sizes)))
    if coords.shape[0] < 2: return 0.0
    try:
        from scipy.spatial import ConvexHull
        if coords.shape[0] >= 4:
            ch = ConvexHull(coords); coords = coords[ch.vertices]
    except Exception:
        if coords.shape[0] > 4096:
            idx = np.linspace(0, coords.shape[0] - 1, 4096).astype(int)
            coords = coords[idx]
    pts = coords.astype(np.float32) * np.array(spacing, dtype=np.float32)[::-1]
    return float(np.sqrt(((pts[:, None] - pts[None, :]) ** 2).sum(-1).max()))


def predict_one(image_path: Path, model: torch.nn.Module, device: torch.device,
                threshold: float = 0.5, lung_filter: bool = True):
    nii = nib.load(str(image_path))
    ct_arr_xyz = np.asarray(nii.dataobj)  # original orientation (X, Y, Z)
    full_shape = ct_arr_xyz.shape
    lm = lung_mask(image_path)  # (X, Y, Z)
    if lm.shape != full_shape:
        # Some CTs have spacing flips; safest is to resample lung mask onto ct shape
        from scipy.ndimage import zoom
        z = [n / o for n, o in zip(full_shape, lm.shape)]
        lm = zoom(lm, z, order=0).astype(np.uint8)

    rt_bbox = calculate_extremes(lm, 1)
    lf_bbox = calculate_extremes(lm, 2)
    if rt_bbox is None and lf_bbox is None:
        return np.zeros(full_shape, dtype=np.uint8), nii.header.get_zooms()[:3]

    pred_full = np.zeros(full_shape, dtype=np.float32)
    for bbox in [b for b in (rt_bbox, lf_bbox) if b is not None]:
        x_lung = process_lung_scan(image_path, bbox)        # (1, D, H, W) float32 tensor
        with torch.no_grad():
            logits = model(x_lung.unsqueeze(0).to(device))   # (1, 1, D, H, W)
            prob   = torch.sigmoid(logits).squeeze(0).squeeze(0).cpu().numpy()
        # unpad to the resampled (post-Spacing) shape
        pre_pad_arr = x_lung.squeeze(0).cpu().numpy()
        prob = remove_pad(prob, pre_pad_arr)
        # back-resample to bbox shape
        prob = voxel_resize(prob, bbox)
        # threshold + stitch into full volume coordinates
        binp = (prob >= threshold).astype(np.float32)
        pred_full = np.maximum(pred_full, stitch(full_shape, binp, bbox))

    pred = (pred_full > 0).astype(np.uint8)
    if lung_filter:
        pred[lm == 0] = 0
    return pred, nii.header.get_zooms()[:3]


def benchmark_task(task: str, val_cases: list[str], model, device):
    task_dir = RAW / task
    rows, t0 = [], time.time()
    for i, case in enumerate(val_cases):
        ct = task_dir / "imagesTr" / f"{case}_0000.nii.gz"
        gt = task_dir / "labelsTr" / f"{case}.nii.gz"
        if not ct.exists() or not gt.exists():
            print(f"  [skip] {case} missing"); continue
        pred, spacing = predict_one(ct, model, device)
        g = (np.asarray(nib.load(str(gt)).dataobj) > 0).astype(np.uint8)
        d = dice(pred, g)
        gt_diam = longest_diameter_3d(g, spacing)
        pr_diam = longest_diameter_3d(pred, spacing)
        vol_gt = float(g.sum() * np.prod(spacing) / 1000.0)
        vol_pr = float(pred.sum() * np.prod(spacing) / 1000.0)
        rows.append(dict(case=case, dice=d,
                          gt_volume_cm3=vol_gt, pred_volume_cm3=vol_pr,
                          gt_diameter_3d_mm=gt_diam, pred_diameter_3d_mm=pr_diam,
                          abs_err_3d_mm=abs(gt_diam - pr_diam),
                          spacing_mm=",".join(f"{s:.4f}" for s in spacing)))
        print(f"  [{i+1:2d}/{len(val_cases)}] {case:25s} dice={d:.3f}  "
              f"gt_diam={gt_diam:6.1f}  pred_diam={pr_diam:6.1f}")
    out_csv = OUT / f"{task}.csv"
    if rows:
        with open(out_csv, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
        print(f"wrote {out_csv}  n={len(rows)}  elapsed={time.time()-t0:.0f}s")
    return rows


def get_val_cases(task: str, fold: int = 0):
    s = pickle.load(open(REPO / "data/nnUNet/nnUNet_preprocessed" / task / "splits_final.pkl", "rb"))
    return list(s[fold]["val"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="+",
                    default=["Task006_Lung", "Task514_RIDER", "Task512_QIN_Tumor10"])
    args = ap.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device = {device}")
    model = load_model(device)
    LEAKY = {"Task006_Lung"}
    summary = []
    for task in args.tasks:
        if not (RAW / task).exists():
            print(f"[skip] {task} missing"); continue
        val = get_val_cases(task)
        print(f"\n=== {task}  n={len(val)}  leaky={task in LEAKY}  ===")
        rows = benchmark_task(task, val, model, device)
        if not rows: continue
        summary.append(dict(
            task=task, n=len(rows), leaky=task in LEAKY,
            mean_dice=float(np.mean([r["dice"] for r in rows])),
            median_dice=float(np.median([r["dice"] for r in rows])),
            mean_abs_err_diam=float(np.mean([r["abs_err_3d_mm"] for r in rows])),
            median_abs_err_diam=float(np.median([r["abs_err_3d_mm"] for r in rows])),
        ))
    with open(OUT / "summary.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(summary[0].keys()) if summary else [])
        w.writeheader(); w.writerows(summary)
    print("\nSUMMARY:")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
