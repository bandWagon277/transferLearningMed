"""Pretrain the oktaykurt-style 3D U-Net on MSD Task06 Lung.

Phase D of the cross-organ × cross-modality plan: produces the S_lung
checkpoint. Originally planned for qin-lungct-seg (TCIA), but TCIA is
unreachable from this cluster — substituted MSD Task06 Lung (S3 mirror,
NIfTI, 64 labeled cases of lung tumor segmentation). See
/home/gengyh/.claude/plans/init-dreamy-petal.md.

Architecture:
  MONAI UNet, channels=(64, 128, 256, 512, 1024), strides=(2, 2, 2, 2),
  num_res_units=0 — matches LungTumorMask / oktaykurt 5-level layout, so
  the resulting checkpoint slots into `--arch unet` in train.py directly.

Loss: DiceCELoss(sigmoid=True), binary.
Input: 1-channel CT, HU window [-1000, 300] → [0, 1] (oktaykurt recipe).
Output: 1-channel binary tumor mask.

Run:
  sbatch code/submit_train.slurm  # repurposed; pass script path or
  # alternatively:
  ~/miniconda3/envs/medicaldiffusion/bin/python code/pretrain_oktaykurt.py \\
      --root data/MSD_Task06_Lung/Task06_Lung \\
      --epochs 100 --batch-size 2 --no-amp \\
      --out code/pretrained/oktaykurt_retrain/msd_lung
"""
from __future__ import annotations
import argparse, glob, json, os, random, time

import torch
from monai import transforms as T
from monai.data import CacheDataset, DataLoader, decollate_batch, list_data_collate
from monai.inferers import sliding_window_inference
from monai.losses import DiceCELoss
from monai.metrics import DiceMetric
from monai.transforms import Activations, AsDiscrete

from models import build_model
from monai.networks.nets import UNet as MonaiUNet


def list_msd_cases(root: str) -> list[dict]:
    """MSD Task06 layout: imagesTr/lung_NNN.nii.gz + labelsTr/lung_NNN.nii.gz."""
    cases = []
    for img in sorted(glob.glob(os.path.join(root, 'imagesTr', '*.nii.gz'))):
        # MSD hides macOS .DS_Store as `._lung_001.nii.gz` — skip those.
        name = os.path.basename(img)
        if name.startswith('._'):
            continue
        lbl = os.path.join(root, 'labelsTr', name)
        if os.path.exists(lbl):
            cases.append({'image': img, 'label': lbl, 'id': name[:-7]})
    return cases


def list_qin_lung_ct_cases(root: str) -> list[dict]:
    """qin_lung_ct converted layout: <case_id>/image.nii.gz + label.nii.gz."""
    cases = []
    for case_dir in sorted(glob.glob(os.path.join(root, '*'))):
        if not os.path.isdir(case_dir):
            continue
        img = os.path.join(case_dir, 'image.nii.gz')
        lbl = os.path.join(case_dir, 'label.nii.gz')
        if os.path.exists(img) and os.path.exists(lbl):
            cases.append({'image': img, 'label': lbl,
                          'id': os.path.basename(case_dir)})
    return cases


def msd_train_transforms(roi: tuple[int, int, int] = (128, 128, 128),
                         pos_neg_ratio: tuple[float, float] = (4.0, 1.0),
                         samples_per_image: int = 4,
                         rotation_deg: float = 30.0) -> T.Compose:
    """v2 transforms. Key changes over v1 (which overfit at val Dice 0.07):

    1. **RandCropByPosNegLabeld** instead of RandSpatialCropd — samples
       patches in a 4:1 positive:negative ratio against the label mask.
       v1 used uniform random crops, so on MSD Lung's ~500x500x400 volumes
       most patches contained zero tumor voxels and the model trivially
       learned "predict background everywhere."
    2. **96³ ROI** instead of 128³ — smaller patches fit more tumor-centered
       samples per image and increase batch diversity.
    3. **`num_samples=4`** per image — each volume yields 4 crops per epoch,
       4× the gradient updates without re-loading I/O.
    4. **Rotation + intensity augmentation** added.
    """
    return T.Compose([
        T.LoadImaged(keys=['image', 'label']),
        T.EnsureChannelFirstd(keys=['image', 'label']),
        T.EnsureTyped(keys=['image', 'label']),
        T.Orientationd(keys=['image', 'label'], axcodes='RAS'),
        T.Spacingd(keys=['image', 'label'], pixdim=(1.0, 1.0, 1.0),
                   mode=('bilinear', 'nearest')),
        T.ScaleIntensityRanged(keys='image', a_min=-1000.0, a_max=300.0,
                               b_min=0.0, b_max=1.0, clip=True),
        T.CropForegroundd(keys=['image', 'label'], source_key='image',
                          allow_smaller=True),
        T.RandCropByPosNegLabeld(
            keys=['image', 'label'], label_key='label',
            spatial_size=roi, pos=pos_neg_ratio[0], neg=pos_neg_ratio[1],
            num_samples=samples_per_image, image_key='image',
            image_threshold=0,
        ),
        T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=0),
        T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=1),
        T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=2),
        T.RandRotate90d(keys=['image', 'label'], prob=0.5, max_k=3),
        # Arbitrary-angle 3D rotation on all three axes (±rotation_deg).
        # Adds rotational diversity beyond the discrete 90° multiples of
        # RandRotate90d. Per meetplan0522 item 1.
        T.RandRotated(
            keys=['image', 'label'],
            range_x=rotation_deg * 3.14159 / 180.0,
            range_y=rotation_deg * 3.14159 / 180.0,
            range_z=rotation_deg * 3.14159 / 180.0,
            mode=('bilinear', 'nearest'),
            padding_mode='zeros',
            prob=0.5,
        ),
        T.RandShiftIntensityd(keys='image', offsets=0.1, prob=0.5),
        T.RandScaleIntensityd(keys='image', factors=0.1, prob=0.5),
        T.RandGaussianNoised(keys='image', prob=0.2, mean=0.0, std=0.01),
    ])


def msd_val_transforms() -> T.Compose:
    return T.Compose([
        T.LoadImaged(keys=['image', 'label']),
        T.EnsureChannelFirstd(keys=['image', 'label']),
        T.EnsureTyped(keys=['image', 'label']),
        T.Orientationd(keys=['image', 'label'], axcodes='RAS'),
        T.Spacingd(keys=['image', 'label'], pixdim=(1.0, 1.0, 1.0),
                   mode=('bilinear', 'nearest')),
        T.ScaleIntensityRanged(keys='image', a_min=-1000.0, a_max=300.0,
                               b_min=0.0, b_max=1.0, clip=True),
    ])


def split_cases(cases, val_frac=0.2, seed=42):
    rng = random.Random(seed)
    shuffled = list(cases)
    rng.shuffle(shuffled)
    n_val = max(1, int(round(len(shuffled) * val_frac)))
    return shuffled[n_val:], shuffled[:n_val]


def split_kfold(cases, fold: int, n_folds: int, seed: int = 42):
    """Deterministic K-fold split. `fold` in [0, n_folds-1].

    Same shuffle seed across folds means fold k uses fold-k as val,
    everything else as train. With n_folds=5, this gives 20% val per
    fold, equivalent to the legacy val_frac=0.2 split when fold=0.
    """
    rng = random.Random(seed)
    shuffled = list(cases)
    rng.shuffle(shuffled)
    n = len(shuffled)
    fold_size = n // n_folds
    val_start = fold * fold_size
    val_end = (fold + 1) * fold_size if fold < n_folds - 1 else n
    val = shuffled[val_start:val_end]
    train = shuffled[:val_start] + shuffled[val_end:]
    return train, val


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--root', default='/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/MSD_Task06_Lung/Task06_Lung')
    p.add_argument('--extra-root', default=None,
                   help='Optional qin_lung_ct-format root (<case_id>/image.nii.gz + '
                        'label.nii.gz). When set, cases from this root are unioned '
                        'with --root before the 80/20 split. Use for Phase D-v3 '
                        '(combined MSD + qin_lung_ct, ~109 cases).')
    p.add_argument('--skip-msd', action='store_true',
                   help='Skip MSD cases under --root, train only on --extra-root '
                        '(qin_lung_ct-format). For QIN-only ablation.')
    p.add_argument('--out',  required=True,
                   help='Run output directory. Final weights at <out>/best.pt')
    p.add_argument('--epochs', type=int, default=100)
    p.add_argument('--batch-size', type=int, default=2)
    p.add_argument('--num-workers', type=int, default=4)
    p.add_argument('--cache-rate', type=float, default=0.0)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--weight-decay', type=float, default=1e-5)
    p.add_argument('--val-every', type=int, default=5)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--amp', action='store_true', default=True)
    p.add_argument('--no-amp', dest='amp', action='store_false')
    p.add_argument('--channels', default=None,
                   help='Comma-separated 5 channel ladder for the UNet, e.g. '
                        '"32,64,128,256,512" for a vanilla narrow UNet. '
                        'When unset, uses the LungTumorMask wide ladder '
                        '(64,128,256,512,1024). Used to compare vanilla '
                        '~10M-param UNet against the wide ~31.6M baseline.')
    p.add_argument('--rotation-deg', type=float, default=30.0,
                   help='Maximum rotation angle (degrees) for RandRotated on '
                        'each of the 3 axes. Default 30°. Set 0 to disable '
                        'arbitrary-angle rotation (90° rotations still apply).')
    p.add_argument('--early-stop-patience', type=int, default=0,
                   help='Stop if val_dice has not improved for this many '
                        'validation rounds (each round is --val-every epochs). '
                        '0 disables early stopping. Recommended: 4 (= 20 '
                        'epochs without improvement at val-every=5).')
    p.add_argument('--pretrained', default=None,
                   help='Path to a checkpoint (best.pt) to load as initial '
                        'weights before training. Architecture must match. '
                        'Used for cross-domain transfer experiments.')
    p.add_argument('--freeze-depth', type=int, default=0, choices=[0, 1, 2],
                   help='Freeze depth for Matsoukas analysis: 0=full fine-tune, '
                        '1=freeze encoder, 2=freeze encoder+bottleneck.')
    p.add_argument('--ckpt-every', type=int, default=20,
                   help='Save a periodic checkpoint every N epochs.')
    p.add_argument('--keep-checkpoints', action='store_true',
                   help='Skip the post-training cleanup that deletes '
                        '`checkpoint_epoch_*.pt`. Use for CKA-trajectory '
                        'runs where the intermediate weights are needed.')
    p.add_argument('--resume', default=None,
                   help='Path to last.pt or checkpoint_epoch_NNN.pt to '
                        'resume training from.')
    p.add_argument('--fold', type=int, default=0,
                   help='K-fold index (0 .. n_folds-1). Default 0 reproduces '
                        'the legacy 80/20 split.')
    p.add_argument('--n-folds', type=int, default=5,
                   help='Number of K-fold splits. Default 5.')
    p.add_argument('--roi', default='128,128,128',
                   help='Comma-separated training patch size (3 ints). '
                        'Default 128,128,128. Validation sliding window uses '
                        'the same ROI.')
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, 'config.json'), 'w') as f:
        json.dump(vars(args), f, indent=2)

    torch.manual_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'[device] {device} ({torch.cuda.get_device_name(0) if device.type=="cuda" else "cpu"})')

    if args.skip_msd:
        cases = []
        n_msd = 0
    else:
        cases = list_msd_cases(args.root)
        if not cases:
            raise FileNotFoundError(f'no MSD cases under {args.root}')
        n_msd = len(cases)
    n_extra = 0
    if args.extra_root:
        extra = list_qin_lung_ct_cases(args.extra_root)
        if not extra:
            raise FileNotFoundError(f'no qin_lung_ct cases under {args.extra_root}')
        cases = cases + extra
        n_extra = len(extra)
    if not cases:
        raise FileNotFoundError('no cases — pass --root and/or --extra-root.')
    train, val = split_kfold(cases, fold=args.fold, n_folds=args.n_folds,
                             seed=args.seed)
    print(f'[data] fold={args.fold}/{args.n_folds}  n_train={len(train)} '
          f'n_val={len(val)} of n_total={len(cases)} '
          f'(msd={n_msd} extra={n_extra})')

    roi = tuple(int(x) for x in args.roi.split(','))
    if len(roi) != 3:
        raise ValueError(f'--roi must give 3 ints, got {roi}')
    train_ds = CacheDataset(train,
                            transform=msd_train_transforms(
                                roi=roi, rotation_deg=args.rotation_deg),
                            cache_rate=args.cache_rate, num_workers=args.num_workers)
    val_ds   = CacheDataset(val,   transform=msd_val_transforms(),
                            cache_rate=args.cache_rate, num_workers=args.num_workers)
    # list_data_collate flattens the list of 4 sub-samples returned by
    # RandCropByPosNegLabeld into a single batch dimension.
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.num_workers, pin_memory=True,
                              collate_fn=list_data_collate)
    val_loader   = DataLoader(val_ds,   batch_size=1, shuffle=False,
                              num_workers=args.num_workers, pin_memory=True)

    # 1-channel CT in, 1-channel tumor mask out. random init.
    if args.channels:
        ch = tuple(int(x) for x in args.channels.split(','))
        if len(ch) != 5:
            raise ValueError(f'--channels must give 5 ints, got {ch}')
        model = MonaiUNet(spatial_dims=3, in_channels=1, out_channels=1,
                          channels=ch, strides=(2, 2, 2, 2),
                          num_res_units=0).to(device)
        ladder = f'channels={ch}'
    else:
        model = build_model(arch='unet', in_channels=1, out_channels=1,
                            init='random', freeze='none').to(device)
        ladder = 'channels=LungTumorMask-wide (64,128,256,512,1024)'
    if args.pretrained:
        ckpt = torch.load(args.pretrained, map_location=device, weights_only=True)
        sd = ckpt['state_dict'] if 'state_dict' in ckpt else ckpt
        model.load_state_dict(sd)
        src_dice = ckpt.get('val_dice', '?')
        src_epoch = ckpt.get('epoch', '?')
        init_tag = f'pretrained from {args.pretrained} (dice={src_dice}, ep={src_epoch})'
    else:
        init_tag = 'random init'

    ENCODER_PREFIXES = [
        'model.0.',
        'model.1.submodule.0.',
        'model.1.submodule.1.submodule.0.',
        'model.1.submodule.1.submodule.1.submodule.0.',
    ]
    BOTTLENECK_PREFIX = 'model.1.submodule.1.submodule.1.submodule.1.submodule.'
    if args.freeze_depth >= 1:
        freeze_prefixes = list(ENCODER_PREFIXES)
        if args.freeze_depth >= 2:
            freeze_prefixes.append(BOTTLENECK_PREFIX)
        for name, param in model.named_parameters():
            if any(name.startswith(p) for p in freeze_prefixes):
                param.requires_grad = False
        n_frozen = sum(1 for p in model.parameters() if not p.requires_grad)
        n_total_p = sum(1 for p in model.parameters())
        depth_label = {1: 'encoder', 2: 'encoder+bottleneck'}[args.freeze_depth]
        init_tag += f'; {depth_label} frozen ({n_frozen}/{n_total_p} param tensors)'

    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    n_trainable = sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6
    print(f'[model] unet {n_params:.1f}M params ({n_trainable:.1f}M trainable); {init_tag}; {ladder}')

    loss_fn = DiceCELoss(sigmoid=True, lambda_dice=1.0, lambda_ce=1.0)
    optim = torch.optim.AdamW(model.parameters(), lr=args.lr,
                              weight_decay=args.weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=args.epochs)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp and device.type == 'cuda')

    post_pred = Activations(sigmoid=True)
    post_thr  = AsDiscrete(threshold=0.5)
    dice_metric = DiceMetric(include_background=False, reduction='mean')

    best_dice = -1.0
    stale_rounds = 0
    start_epoch = 0
    log_path = os.path.join(args.out, 'metrics.jsonl')
    ckpt_path = os.path.join(args.out, 'best.pt')

    if args.resume:
        rck = torch.load(args.resume, map_location=device, weights_only=True)
        model.load_state_dict(rck['state_dict'])
        if 'optimizer' in rck:
            optim.load_state_dict(rck['optimizer'])
        if 'scheduler' in rck:
            sched.load_state_dict(rck['scheduler'])
        if 'scaler' in rck and scaler is not None:
            scaler.load_state_dict(rck['scaler'])
        start_epoch = rck.get('epoch', 0) + 1
        best_dice = rck.get('best_dice', rck.get('val_dice', -1.0))
        print(f'[resume] from {args.resume}, epoch={start_epoch}, best_dice={best_dice:.4f}')

    for epoch in range(start_epoch, args.epochs):
        model.train()
        epoch_loss = 0.0
        t0 = time.time()
        for batch in train_loader:
            x = batch['image'].to(device, non_blocking=True)
            y = batch['label'].to(device, non_blocking=True).float()
            optim.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=args.amp and device.type == 'cuda'):
                logits = model(x)
                loss = loss_fn(logits, y)
            if not torch.isfinite(loss):
                raise RuntimeError(f'non-finite loss at epoch={epoch}; '
                                   f'try --no-amp if you saw an Inf in logits.')
            scaler.scale(loss).backward()
            scaler.step(optim)
            scaler.update()
            epoch_loss += loss.item()
        sched.step()
        epoch_loss /= max(1, len(train_loader))
        rec = {'epoch': epoch, 'train_loss': epoch_loss,
               'epoch_time_s': round(time.time() - t0, 1)}

        save_payload = {
            'state_dict': model.state_dict(), 'epoch': epoch,
            'train_loss': epoch_loss, 'best_dice': best_dice,
            'optimizer': optim.state_dict(),
            'scheduler': sched.state_dict(),
            'scaler': scaler.state_dict() if scaler else None,
        }
        torch.save(save_payload, os.path.join(args.out, 'last.pt'))

        if args.ckpt_every > 0 and (epoch + 1) % args.ckpt_every == 0:
            torch.save(save_payload,
                       os.path.join(args.out, f'checkpoint_epoch_{epoch+1:03d}.pt'))

        if (epoch + 1) % args.val_every == 0 or epoch == args.epochs - 1:
            model.eval()
            dice_metric.reset()
            with torch.no_grad():
                for vbatch in val_loader:
                    vx = vbatch['image'].to(device, non_blocking=True)
                    vy = vbatch['label'].to(device, non_blocking=True).float()
                    with torch.cuda.amp.autocast(enabled=args.amp and device.type == 'cuda'):
                        vy_logits = sliding_window_inference(
                            vx, roi_size=roi, sw_batch_size=1,
                            predictor=model, overlap=0.5)
                    vy_prob = [post_pred(p) for p in decollate_batch(vy_logits)]
                    vy_bin  = [post_thr(p)  for p in vy_prob]
                    dice_metric(y_pred=vy_bin, y=decollate_batch(vy))
            mean_dice = dice_metric.aggregate().item()
            rec['val_dice'] = mean_dice
            if mean_dice > best_dice:
                best_dice = mean_dice
                stale_rounds = 0
                torch.save({'state_dict': model.state_dict(),
                            'epoch': epoch, 'val_dice': mean_dice}, ckpt_path)
                rec['saved_best'] = True
            else:
                stale_rounds += 1
                rec['stale_rounds'] = stale_rounds
            if device.type == 'cuda':
                torch.cuda.empty_cache()

        with open(log_path, 'a') as f:
            f.write(json.dumps(rec) + '\n')
        print(json.dumps(rec))

        if args.early_stop_patience > 0 and stale_rounds >= args.early_stop_patience:
            print(f'[early-stop] no val_dice improvement for '
                  f'{stale_rounds} validation rounds (patience='
                  f'{args.early_stop_patience}); stopping at epoch {epoch}.')
            break

    if not args.keep_checkpoints:
        import glob as _glob
        for f in _glob.glob(os.path.join(args.out, 'checkpoint_epoch_*.pt')):
            os.remove(f)
        print(f'[cleanup] removed periodic checkpoints')
    else:
        print(f'[cleanup] --keep-checkpoints set; periodic checkpoints retained')
    print(f'[done] best val Dice = {best_dice:.4f}; checkpoint at {ckpt_path}')


if __name__ == '__main__':
    main()
