"""Model factory for the transfer-learning study.

Supports three architectures (selected via `--arch`):

  - 'segresnet'  : MONAI SegResNet (~5 M params, fast)
  - 'swinunetr'  : MONAI SwinUNETR (~62 M params; loads the official CT-SSL
                   pretrained encoder via SwinUNETR.load_from())
  - 'unet'       : MONAI UNet with channels (64,128,256,512,1024), the
                   architecture LungTumorMask was trained with — used for
                   `--init lungtumormask` transfer from lung-tumor CT.

Initialization sources (selected via `--init`):

  - 'random'         : default init
  - 'ct_ssl'         : load CT self-supervised weights into SwinUNETR encoder
                       (file: code/pretrained/model_swinvit.pt)
  - 'lung_genesis'   : Models Genesis 3D U-Net weights (file:
                       code/pretrained/Genesis_Chest_CT.pt) — only meaningful
                       when arch=='unet3d' (not yet implemented; see TODO)
  - 'lungtumormask'  : Fredriksen et al. 2022 lung-tumor segmentation weights
                       (file: code/pretrained/lungtumormask/dc_student.pth).
                       Requires arch=='unet'. Loads the teacher branch
                       (`model1.*`); the auxiliary `model2.*` decoder is
                       discarded. Input conv (1→4 channels for MRI) and
                       output conv (1→3 channels for TC/WT/ET) are reinitialized.
  - 'brain'          : reserved for a brain-MRI source we have not yet
                       populated (BrainSegFounder gdown is fragile; leave for v2)

Freeze schemes apply per-architecture; see `apply_freeze`.
"""
from __future__ import annotations
import os
from typing import Literal, Optional

import torch
from monai.networks.nets import SegResNet, SwinUNETR, UNet

Arch       = Literal['segresnet', 'swinunetr', 'unet']
InitSource = Literal['random', 'ct_ssl', 'lung_genesis', 'lungtumormask', 'brain']
FreezeMode = Literal['none', 'encoder', 'encoder_bottleneck', 'all_but_head']

# Channel ladder used by LungTumorMask's UNet_double. Hard-coded so that
# arch='unet' is compatible with the dc_student.pth state-dict by construction.
LUNGTUMORMASK_CHANNELS = (64, 128, 256, 512, 1024)
LUNGTUMORMASK_STRIDES  = (2, 2, 2, 2)


def build_model(arch: Arch = 'segresnet',
                in_channels: int = 4,
                out_channels: int = 3,
                init: InitSource = 'random',
                pretrained_ckpt: Optional[str] = None,
                freeze: FreezeMode = 'none',
                feature_size: int = 48) -> torch.nn.Module:
    if arch == 'segresnet':
        model = SegResNet(
            spatial_dims=3, init_filters=32,
            in_channels=in_channels, out_channels=out_channels,
            blocks_down=(1, 2, 2, 4), blocks_up=(1, 1, 1),
            dropout_prob=0.2,
        )
    elif arch == 'swinunetr':
        model = SwinUNETR(
            img_size=(128, 128, 128),
            in_channels=in_channels, out_channels=out_channels,
            feature_size=feature_size,
            use_checkpoint=False,
        )
    elif arch == 'unet':
        model = UNet(
            spatial_dims=3,
            in_channels=in_channels, out_channels=out_channels,
            channels=LUNGTUMORMASK_CHANNELS,
            strides=LUNGTUMORMASK_STRIDES,
            num_res_units=0,
        )
    else:
        raise ValueError(f'unknown arch {arch}')

    if init != 'random':
        path = pretrained_ckpt or _default_ckpt_for(init)
        if path is None or not os.path.exists(path):
            raise FileNotFoundError(
                f'init={init!r} but pretrained_ckpt does not exist: {path!r}. '
                f'See code/pretrained/README.md.')
        if arch == 'swinunetr' and init == 'ct_ssl':
            # MONAI's official path for the SwinViT SSL weights
            sd = torch.load(path, map_location='cpu', weights_only=False)
            model.load_from(weights=sd)
            print(f'[init={init}] SwinUNETR.load_from loaded {path}')
        elif arch == 'unet' and init == 'lungtumormask':
            _load_lungtumormask(model, path)
        else:
            sd = torch.load(path, map_location='cpu', weights_only=False)
            sd = sd.get('state_dict', sd) if isinstance(sd, dict) else sd
            missing, unexpected = model.load_state_dict(sd, strict=False)
            print(f'[init={init}] loaded {path}; missing={len(missing)} unexpected={len(unexpected)}')
            if missing or unexpected:
                print(f'  first missing: {missing[:5]}')
                print(f'  first unexpected: {unexpected[:5]}')

    apply_freeze(model, arch, freeze)
    return model


def _default_ckpt_for(init: InitSource) -> Optional[str]:
    base = '/nfs/turbo/jiankanggroup/gengyh/transferMRI/code/pretrained'
    return {
        'ct_ssl':        f'{base}/model_swinvit.pt',
        'lung_genesis':  f'{base}/Genesis_Chest_CT.pt',
        'lungtumormask': f'{base}/lungtumormask/dc_student.pth',
        'brain':         f'{base}/brain.pt',
    }.get(init)


def _load_lungtumormask(model: torch.nn.Module, path: str) -> None:
    """Load LungTumorMask `dc_student.pth` into a MONAI `UNet`.

    The source state-dict has two parallel decoder branches (`model1.*` and
    `model2.*`) from a teacher-student training scheme. The target MONAI
    `UNet` has a single branch named `model.*` with identical sub-structure,
    so we rename `model1.X` → `model.X` and drop `model2.*` entirely.

    The first conv (`model.0.conv.*`) is reinitialized because the source is
    1-channel CT and the target is 4-channel MRI; the final conv
    (`model.2.conv.*`) is reinitialized because the source predicts 1
    sigmoid tumor channel and the target predicts 3 (TC/WT/ET).
    """
    sd_src = torch.load(path, map_location='cpu', weights_only=False)
    sd_src = sd_src.get('state_dict', sd_src) if isinstance(sd_src, dict) else sd_src

    renamed: dict = {}
    skipped_input  = []
    skipped_output = []
    skipped_aux    = []
    for k, v in sd_src.items():
        if k.startswith('model2.'):
            skipped_aux.append(k)
            continue
        if not k.startswith('model1.'):
            continue
        new_k = 'model.' + k[len('model1.'):]
        if new_k.startswith('model.0.conv.'):
            skipped_input.append(k)
            continue
        if new_k.startswith('model.2.conv.'):
            skipped_output.append(k)
            continue
        renamed[new_k] = v

    missing, unexpected = model.load_state_dict(renamed, strict=False)
    # The reinitialized in/out conv keys will show up as "missing" — that's
    # expected and not a bug.
    n_loaded = len(renamed)
    print(f'[init=lungtumormask] loaded {n_loaded} tensors from {path}')
    print(f'  reinit input conv (1ch CT -> 4ch MRI):  {len(skipped_input)} tensors')
    print(f'  reinit output conv (1ch -> 3ch TC/WT/ET): {len(skipped_output)} tensors')
    print(f'  discarded auxiliary decoder model2.*:    {len(skipped_aux)} tensors')
    if unexpected:
        raise RuntimeError(f'unexpected keys after rename: {unexpected[:5]}')
    # Anything in `missing` that is NOT one of the deliberately-skipped layers
    # is a real architecture mismatch and should be flagged.
    real_missing = [k for k in missing
                    if not k.startswith('model.0.conv.')
                    and not k.startswith('model.2.conv.')]
    if real_missing:
        raise RuntimeError(f'unexpectedly-missing keys: {real_missing[:5]}')


def apply_freeze(model: torch.nn.Module, arch: Arch, mode: FreezeMode) -> None:
    if mode == 'none':
        return
    for p in model.parameters():
        p.requires_grad_(True)

    named = list(model.named_parameters())
    if mode == 'all_but_head':
        head_prefixes = {'segresnet': ('conv_final',),
                         'swinunetr': ('out',),
                         'unet':      ('model.2.',)}[arch]
        for n, p in named:
            if not n.startswith(head_prefixes):
                p.requires_grad_(False)
    elif mode == 'encoder':
        if arch == 'segresnet':
            enc_prefixes = ('convInit', 'down_layers')
        elif arch == 'swinunetr':
            enc_prefixes = ('swinViT',)
        else:  # unet — encoder = first conv `model.0.*` plus every nested
               # `submodule.0.*` (the down branch at each recursion level).
            enc_prefixes = ('model.0.',)
        for n, p in named:
            if n.startswith(enc_prefixes) or _is_unet_down_path(arch, n):
                p.requires_grad_(False)
    elif mode == 'encoder_bottleneck':
        if arch == 'segresnet':
            prefixes = ('convInit', 'down_layers', 'up_samples.0', 'up_layers.0')
        elif arch == 'swinunetr':
            prefixes = ('swinViT', 'encoder1', 'encoder2', 'encoder3', 'encoder4')
        else:  # unet — encoder + the deepest bottleneck conv
            prefixes = ('model.0.',
                        'model.1.submodule.1.submodule.1.submodule.1.submodule.')
        for n, p in named:
            if n.startswith(prefixes) or (arch == 'unet' and _is_unet_down_path(arch, n)):
                p.requires_grad_(False)
    else:
        raise ValueError(f'unknown freeze mode {mode}')

    n_train = sum(p.numel() for p in model.parameters() if p.requires_grad)
    n_total = sum(p.numel() for p in model.parameters())
    print(f'[freeze={mode}] trainable {n_train}/{n_total} = {n_train/n_total:.1%}')


def _is_unet_down_path(arch: str, param_name: str) -> bool:
    """Return True if the named param belongs to the *down* (encoder) branch
    of a MONAI UNet. The MONAI UNet recursion at every level produces three
    children: `.submodule.0.*` (down), `.submodule.1.*` (deeper subtree),
    `.submodule.2.*` (up). So any path whose every `submodule.<i>` index is
    either `0` or `1` is part of the encoder/bottleneck chain, while a `2`
    anywhere in the path marks an up-conv at that level (decoder).
    """
    if arch != 'unet':
        return False
    parts = param_name.split('.')
    for i, p in enumerate(parts):
        if p == 'submodule' and i + 1 < len(parts):
            if parts[i + 1] == '2':
                return False
    # Encoder if the first `model.X` index is 0 (top-level down conv) or the
    # path contains `submodule.0.` (a down conv at some depth). Otherwise the
    # caller's other prefix matches will handle it.
    return ('.submodule.0.' in param_name) or param_name.startswith('model.0.')


if __name__ == '__main__':
    # smoke build only (no forward — that runs slowly on CPU)
    for arch in ('segresnet', 'swinunetr', 'unet'):
        m = build_model(arch=arch, init='random')
        n = sum(p.numel() for p in m.parameters()) / 1e6
        print(f'{arch}: {n:.1f}M params')
    m = build_model(arch='swinunetr', init='ct_ssl')
    print('swinunetr+ct_ssl init OK')
    m = build_model(arch='unet', init='lungtumormask')
    print('unet+lungtumormask init OK')
