"""Same `dc_student.pth` weights, but using nnU-Net Task006_Lung's
preprocessing instead of the LungTumorMask author pipeline.

This is the fair side-by-side: feed the *same* model the kind of inputs an
nnU-Net trainer would have generated, so the only thing that differs is the
preprocessing. Concretely:

  - Resample CT to 1.245 x 0.785 x 0.785 mm (nnU-Net Task006_Lung stage-1 spacing).
  - Clip HU to the global [0.5%, 99.5%] percentile range learned by
    nnU-Net (from plans.pkl).
  - Z-score with the global (mean, sd) learned by nnU-Net across the
    training-set foreground voxels (NOT per-case).
  - Sliding-window inference with roi (80, 192, 160), 0.5 overlap, Gaussian
    weights -- nnU-Net's standard inferer.
  - Resample the predicted mask back to original geometry.

The model still wants 1 input channel; we pass the normalized whole-volume
CT (no lung crop). Author-pipeline-vs-nnU-Net is therefore an apples-to-apples
test of the two preprocessing recipes.

Output: deliverable/measurements/lungtumormask_v2_nnunet_0630/<task>.csv
"""
from __future__ import annotations
import argparse, csv, json, pickle, time
from pathlib import Path
import numpy as np
import nibabel as nib
import SimpleITK as sitk
import torch
from monai.networks.nets import UNet
from monai.inferers import SlidingWindowInferer
from scipy.ndimage import label as cc_label

REPO = Path("/nfs/turbo/jiankanggroup/gengyh/transferMRI")
RAW  = REPO / "data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data"
CKPT = REPO / "code/pretrained/lungtumormask/dc_student.pth"
OUT  = REPO / "deliverable/measurements/lungtumormask_v2_nnunet_0630"
OUT.mkdir(parents=True, exist_ok=True)

# nnU-Net Task006_Lung plans (from inspection of nnUNetPlansv2.1_plans_3D.pkl)
NNUNET_PLAN = {
    "spacing_xyz": (0.78515625, 0.78515625, 1.24497998),  # (X, Y, Z) in mm
    "patch_size":  (160, 192, 80),                         # MONAI order: (X, Y, Z)
    "global_mean": -158.57991,
    "global_sd":   324.69516,
    "clip_lo":     -1024.0,
    "clip_hi":      292.275,     # from dataset_properties percentile_99_5 spread; conservative high cap
}


def load_model(device: torch.device) -> torch.nn.Module:
    m = UNet(spatial_dims=3, in_channels=1, out_channels=1,
             channels=(64, 128, 256, 512, 1024),
             strides=(2, 2, 2, 2), num_res_units=0)
    sd = torch.load(CKPT, map_location="cpu", weights_only=False)
    sd = sd.get("state_dict", sd) if isinstance(sd, dict) else sd
    renamed = {k.replace("model1.", "model.", 1): v
               for k, v in sd.items() if k.startswith("model1.")}
    m.load_state_dict(renamed, strict=True)
    print(f"[model] loaded {len(renamed)} tensors from {CKPT.name}")
    return m.to(device).eval()


def resample_to_spacing(arr_xyz: np.ndarray, src_spacing_xyz, dst_spacing_xyz,
                        is_label: bool = False) -> np.ndarray:
    """Linear (or NN if label) resample via SimpleITK."""
    img = sitk.GetImageFromArray(np.swapaxes(arr_xyz, 0, 2))  # (Z, Y, X)
    img.SetSpacing(src_spacing_xyz)
    src_size = img.GetSize()
    dst_size = [int(round(src_size[i] * src_spacing_xyz[i] / dst_spacing_xyz[i]))
                for i in range(3)]
    interp = sitk.sitkNearestNeighbor if is_label else sitk.sitkLinear
    out = sitk.Resample(img, dst_size, sitk.Transform(), interp,
                         img.GetOrigin(), dst_spacing_xyz, img.GetDirection(),
                         0, img.GetPixelID())
    arr = sitk.GetArrayFromImage(out)
    return np.swapaxes(arr, 0, 2)


def predict_one(image_path: Path, model: torch.nn.Module, device: torch.device):
    nii = nib.load(str(image_path))
    ct = np.asarray(nii.dataobj).astype(np.float32)
    src_spacing = tuple(float(s) for s in nii.header.get_zooms()[:3])  # (X, Y, Z)

    # 1) Resample to nnU-Net spacing
    ct_r = resample_to_spacing(ct, src_spacing, NNUNET_PLAN["spacing_xyz"])
    # 2) nnU-Net "CT" normalization: clip + z-score with global stats
    ct_r = np.clip(ct_r, NNUNET_PLAN["clip_lo"], NNUNET_PLAN["clip_hi"])
    ct_r = (ct_r - NNUNET_PLAN["global_mean"]) / NNUNET_PLAN["global_sd"]
    # 3) Sliding-window inference
    x = torch.from_numpy(ct_r).unsqueeze(0).unsqueeze(0).to(device)
    inferer = SlidingWindowInferer(roi_size=NNUNET_PLAN["patch_size"],
                                    sw_batch_size=1, overlap=0.5,
                                    mode="gaussian", padding_mode="replicate")
    with torch.no_grad():
        logits = inferer(x, model)
    prob = torch.sigmoid(logits)[0, 0].cpu().numpy().astype(np.float32)
    # 4) Threshold and resample back to original spacing
    binp = (prob > 0.5).astype(np.uint8)
    pred = resample_to_spacing(binp.astype(np.float32),
                                NNUNET_PLAN["spacing_xyz"], src_spacing,
                                is_label=False)
    pred = (pred > 0.5).astype(np.uint8)
    # In case of slight shape mismatch from rounding, pad/crop to ct shape.
    out = np.zeros_like(ct, dtype=np.uint8)
    sh = [min(pred.shape[i], ct.shape[i]) for i in range(3)]
    out[:sh[0], :sh[1], :sh[2]] = pred[:sh[0], :sh[1], :sh[2]]
    return out, src_spacing


def dice(p, g):
    p, g = p > 0, g > 0
    s = p.sum() + g.sum()
    return float(2 * np.logical_and(p, g).sum() / s) if s else 0.0


def longest_diameter_3d(mask, spacing):
    if mask.sum() == 0: return 0.0
    lab, n = cc_label(mask)
    if n == 0: return 0.0
    sizes = np.bincount(lab.ravel()); sizes[0] = 0
    coords = np.argwhere(lab == int(np.argmax(sizes)))
    if coords.shape[0] < 2: return 0.0
    try:
        from scipy.spatial import ConvexHull
        if coords.shape[0] >= 4:
            ch = ConvexHull(coords); coords = coords[ch.vertices]
    except Exception:
        if coords.shape[0] > 4096:
            idx = np.linspace(0, coords.shape[0] - 1, 4096).astype(int)
            coords = coords[idx]
    pts = coords.astype(np.float32) * np.array(spacing, dtype=np.float32)[::-1]
    return float(np.sqrt(((pts[:, None] - pts[None, :]) ** 2).sum(-1).max()))


def benchmark_task(task: str, val_cases, model, device):
    task_dir = RAW / task
    rows, t0 = [], time.time()
    for i, case in enumerate(val_cases):
        ct = task_dir / "imagesTr" / f"{case}_0000.nii.gz"
        gt = task_dir / "labelsTr" / f"{case}.nii.gz"
        if not (ct.exists() and gt.exists()): continue
        pred, spacing = predict_one(ct, model, device)
        g = (np.asarray(nib.load(str(gt)).dataobj) > 0).astype(np.uint8)
        d = dice(pred, g)
        rows.append(dict(case=case, dice=d,
                          gt_volume_cm3=float(g.sum()*np.prod(spacing)/1000.0),
                          pred_volume_cm3=float(pred.sum()*np.prod(spacing)/1000.0),
                          gt_diameter_3d_mm=longest_diameter_3d(g, spacing),
                          pred_diameter_3d_mm=longest_diameter_3d(pred, spacing)))
        rows[-1]["abs_err_3d_mm"] = abs(rows[-1]["gt_diameter_3d_mm"]
                                         - rows[-1]["pred_diameter_3d_mm"])
        rows[-1]["spacing_mm"] = ",".join(f"{s:.4f}" for s in spacing)
        print(f"  [{i+1:2d}/{len(val_cases)}] {case:25s} dice={d:.3f}")
    if rows:
        out_csv = OUT / f"{task}.csv"
        with open(out_csv, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
        print(f"wrote {out_csv}  n={len(rows)}  elapsed={time.time()-t0:.0f}s")
    return rows


def get_val_cases(task: str, fold: int = 0):
    s = pickle.load(open(REPO / "data/nnUNet/nnUNet_preprocessed" / task / "splits_final.pkl", "rb"))
    return list(s[fold]["val"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="+",
                    default=["Task006_Lung", "Task514_RIDER", "Task512_QIN_Tumor10"])
    args = ap.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = load_model(device)
    LEAKY = {"Task006_Lung"}
    summary = []
    for task in args.tasks:
        if not (RAW / task).exists(): continue
        val = get_val_cases(task)
        print(f"\n=== {task}  n={len(val)}  leaky={task in LEAKY}  ===")
        rows = benchmark_task(task, val, model, device)
        if not rows: continue
        summary.append(dict(
            task=task, n=len(rows), leaky=task in LEAKY,
            mean_dice=float(np.mean([r["dice"] for r in rows])),
            median_dice=float(np.median([r["dice"] for r in rows])),
            mean_abs_err_diam=float(np.mean([r["abs_err_3d_mm"] for r in rows])),
            median_abs_err_diam=float(np.median([r["abs_err_3d_mm"] for r in rows])),
        ))
    with open(OUT / "summary.csv", "w", newline="") as fh:
        if summary:
            w = csv.DictWriter(fh, fieldnames=list(summary[0].keys()))
            w.writeheader(); w.writerows(summary)
    print("\nSUMMARY:")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
