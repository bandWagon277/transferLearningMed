"""Append sample-size-sweep folds to splits_final.pkl for the target tasks.

For each (task, ladder size) pair, subsample N cases from fold-0 train and keep
fold-0 val held out.  The result is written back to splits_final.pkl at a fresh
fold index >= 5.  A manifest mapping (task, size) -> fold_index is written next
to splits_final.pkl as sweep_manifest_0624.json.

Once this runs, submit per-config training with --fold <index>.  The trainer's
nnU-Net data loader will pick up the (train, val) pair from the new fold entry
verbatim.

The sampling is reproducible: numpy.random.default_rng(seed=task hash).
"""
from __future__ import annotations
import json
import os
import pickle
from pathlib import Path

import numpy as np


REPO = Path("/nfs/turbo/jiankanggroup/gengyh/transferMRI")
PREP = REPO / "data/nnUNet/nnUNet_preprocessed"

LADDERS = {
    "Task500_BraTS2021": [50, 100, 250, 500],
    "Task006_Lung": [8, 16, 32],
}


def main():
    manifest = {}
    for task, sizes in LADDERS.items():
        splits_path = PREP / task / "splits_final.pkl"
        with splits_path.open("rb") as f:
            splits = pickle.load(f)
        # Trim back to the original 5 entries if a prior sweep left junk
        splits = list(splits[:5])
        fold0 = splits[0]
        train0 = list(fold0["train"])
        val0 = list(fold0["val"])
        rng = np.random.default_rng(abs(hash(task)) % (2**32))
        # The sweep keeps val0 fixed and samples increasing-size subsets of
        # train0 with deterministic seeds.  Each ladder size is its own fold
        # index appended after fold 4.
        next_idx = 5
        for size in sizes:
            n = min(size, len(train0))
            sub = list(rng.choice(train0, size=n, replace=False))
            splits.append({"train": sub, "val": val0})
            manifest.setdefault(task, {})[str(size)] = {
                "fold_index": next_idx,
                "n_train": n,
                "n_val": len(val0),
            }
            next_idx += 1
        with splits_path.open("wb") as f:
            pickle.dump(splits, f)
        print(f"{task}: wrote {next_idx - 5} extra folds (indices 5..{next_idx-1})")
    manifest_path = PREP / "sweep_manifest_0624.json"
    with manifest_path.open("w") as f:
        json.dump(manifest, f, indent=2)
    print(f"\nmanifest -> {manifest_path}")


if __name__ == "__main__":
    main()
