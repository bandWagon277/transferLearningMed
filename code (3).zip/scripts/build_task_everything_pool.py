"""Build Task650_EverythingPool: a single-channel nnU-Net task that pools all
five tumor-segmentation tasks we have prepared.

Option (b) from the discussion: single-channel "any grayscale". Each case
keeps its native modality as a single image channel; we mark the modality as
"noNorm" in dataset.json so nnU-Net per-case z-scores it. The network sees one
homogeneous channel across both CT and MRI cases.

Sources (read-only; we symlink rather than copy):

  Task006_Lung           63 cases  CT,        binary tumor
  Task500_BraTS2021     523 cases  MRI FLAIR, binary tumor (already FLAIR-only)
  Task502_BraTS2024Post 523 cases  MRI FLAIR, binary tumor
  Task512_QIN_Tumor10    10 cases  CT,        binary tumor
  Task514_RIDER          32 cases  CT,        binary tumor

  approx total: ~1150 cases

Output:

  data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data/Task650_EverythingPool/
    imagesTr/<sourcetag>_<origcase>_0000.nii.gz   -- symlink
    labelsTr/<sourcetag>_<origcase>.nii.gz        -- symlink
    dataset.json
    source_provenance.csv                          -- which case came from where

The "sourcetag" prefix makes it trivial after-the-fact to compute per-source
Dice from the pooled training run.
"""
from __future__ import annotations
import json, os, csv
from pathlib import Path

REPO = Path("/nfs/turbo/jiankanggroup/gengyh/transferMRI")
RAW  = REPO / "data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data"

SRC_TASKS = [
    # (source-tag, task-dir-name)
    ("BR21",  "Task500_BraTS2021"),
    ("BR24",  "Task502_BraTS2024Post"),
    ("MSDL",  "Task006_Lung"),
    ("QIN10", "Task512_QIN_Tumor10"),
    ("RIDER", "Task514_RIDER"),
]

DEST = RAW / "Task650_EverythingPool"
(DEST / "imagesTr").mkdir(parents=True, exist_ok=True)
(DEST / "labelsTr").mkdir(parents=True, exist_ok=True)

provenance = []
n_per_src = {}
for tag, task in SRC_TASKS:
    src_img_dir = RAW / task / "imagesTr"
    src_lab_dir = RAW / task / "labelsTr"
    if not src_img_dir.exists():
        print(f"[skip] {src_img_dir} missing"); continue
    images = sorted(p for p in src_img_dir.glob("*_0000.nii.gz"))
    n = 0
    for img_path in images:
        case_id = img_path.name[:-len("_0000.nii.gz")]
        lab_path = src_lab_dir / f"{case_id}.nii.gz"
        if not lab_path.exists():
            continue
        new_id = f"{tag}_{case_id}"
        dst_img = DEST / "imagesTr" / f"{new_id}_0000.nii.gz"
        dst_lab = DEST / "labelsTr" / f"{new_id}.nii.gz"
        if not dst_img.exists():
            os.symlink(str(img_path), str(dst_img))
        if not dst_lab.exists():
            os.symlink(str(lab_path), str(dst_lab))
        provenance.append(dict(new_id=new_id, source_tag=tag, source_task=task,
                                orig_case=case_id))
        n += 1
    n_per_src[tag] = n
    print(f"  pooled {n:4d} cases from {tag} ({task})")

print("\nper-source counts:", n_per_src, "  total:", sum(n_per_src.values()))

with open(DEST / "source_provenance.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=["new_id", "source_tag", "source_task", "orig_case"])
    w.writeheader(); w.writerows(provenance)
print(f"wrote {DEST / 'source_provenance.csv'}")

training = [
    # nnU-Net v1: dataset.json training entries use the BARE case id
    # (no _0000 channel suffix). The framework auto-appends _0000.nii.gz
    # when it looks up the image file.
    {"image": f"./imagesTr/{r['new_id']}.nii.gz",
     "label": f"./labelsTr/{r['new_id']}.nii.gz"}
    for r in provenance
]

dataset_json = {
    "name": "EverythingPool",
    "description": "Single-channel grayscale pool of BraTS21+BraTS24+MSD-Lung+"
                   "QIN10+RIDER. Mixed CT + MRI; nnU-Net normalizes per-case "
                   "via 'noNorm' (z-score).",
    "reference": "internal",
    "licence": "internal",
    "tensorImageSize": "3D",
    "modality": {"0": "noNorm"},
    "labels": {"0": "background", "1": "tumor"},
    "numTraining": len(training),
    "numTest": 0,
    "training": training,
    "test": [],
    "file_ending": ".nii.gz",
}
with open(DEST / "dataset.json", "w") as fh:
    json.dump(dataset_json, fh, indent=1)
print(f"wrote {DEST / 'dataset.json'}  ({len(training)} training cases)")
print(f"\nNow run: nnUNet_plan_and_preprocess -t 650")
