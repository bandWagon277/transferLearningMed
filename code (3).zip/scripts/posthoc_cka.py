"""Post-hoc plotting + analysis on metric_audit_0611.json + cka_epoch_trajectory_0611.json.

Implements the four remaining meetplan0611 items:
  1. Dot+line plot per direction (layer on x, CKA on y) with K=10
     multi-seed noise floor as a shaded band; freeze0/1/2 overlay
     lines. (meetplan items 1, 2)
  2. Helpful/harmful bucketing: full-fine-tune cells grouped by sign
     of Delta-Dice, layer-wise comparison. (meetplan item 6)
  3. Layer derivative d(CKA)/d(layer) per cell. (meetplan items 7, 8)
  4. Source-encoder generality: mean retention across targets per
     source. (meetplan item 9)
  5. Epoch-trajectory CKA-vs-epoch plot. (meetplan item 4)
"""
from __future__ import annotations
import json
import os

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
AUDIT = json.load(open(os.path.join(REPO, 'runs/metric_audit_0611.json')))
TRAJ_PATH_EP0 = os.path.join(REPO, 'runs/cka_epoch_trajectory_with_ep0_0611.json')
TRAJ_PATH     = os.path.join(REPO, 'runs/cka_epoch_trajectory_0611.json')
TRAJ = json.load(open(TRAJ_PATH_EP0 if os.path.exists(TRAJ_PATH_EP0) else TRAJ_PATH))

OUT = os.path.join(REPO, 'runs/figures/0611')
os.makedirs(OUT, exist_ok=True)

LAYERS = ['L0_stem', 'L1_down', 'L2_down', 'L3_down',
          'L4_bottleneck', 'D2_up_inner', 'D1_up_outer']
FREEZE_KEYS = ['full', 'freeze1', 'freeze2']
FREEZE_LABEL = {'full': r'full ($f{=}0$)',
                'freeze1': r'enc.\ frozen ($f{=}1$)',
                'freeze2': r'enc.+bot.\ frozen ($f{=}2$)'}
FREEZE_COLOR = {'full': 'tab:blue',
                'freeze1': 'tab:orange',
                'freeze2': 'tab:green'}


def plot_dot_line_per_direction():
    """One subplot per direction. X-axis = layer (L0->D1). Y-axis = CKA.
    Multi-seed noise floor as shaded mean +/- std band. Overlay
    freeze0/1/2 dot+line plots."""
    directions = list(AUDIT['results'].keys())
    fig, axes = plt.subplots(1, len(directions), figsize=(5 * len(directions), 4.5), sharey=True)
    if len(directions) == 1:
        axes = [axes]
    for ax, direction in zip(axes, directions):
        blk = AUDIT['results'][direction]
        x = np.arange(len(LAYERS))
        noise_mean = np.array([blk['noise_floor_multi_seed'][L]['mean'] for L in LAYERS])
        noise_std  = np.array([blk['noise_floor_multi_seed'][L]['std']  for L in LAYERS])
        # Noise band
        ax.fill_between(x, noise_mean - noise_std, noise_mean + noise_std,
                        color='gray', alpha=0.3,
                        label=f'noise mean$\\pm$std (K={AUDIT["k_rand_seeds"]})')
        ax.plot(x, noise_mean, color='gray', lw=1.2, ls='--')
        # Cells
        for fk in FREEZE_KEYS:
            cell = blk['cells'][fk]
            cka  = np.array([cell[L]['cka'] for L in LAYERS])
            lo   = np.array([cell[L]['cka_ci_lo'] for L in LAYERS])
            hi   = np.array([cell[L]['cka_ci_hi'] for L in LAYERS])
            dd = cell.get('_delta_dice')
            lbl = f'{FREEZE_LABEL[fk]}, $\\Delta$Dice={dd:+.3f}' if dd is not None else FREEZE_LABEL[fk]
            ax.errorbar(x, cka, yerr=[cka - lo, hi - cka], fmt='o-',
                        color=FREEZE_COLOR[fk], capsize=3, lw=1.6,
                        markersize=5, label=lbl)
        ax.set_xticks(x)
        ax.set_xticklabels([L.replace('_', '\n') for L in LAYERS], fontsize=8)
        ax.set_title(direction.replace('_', ' '))
        ax.set_ylabel('linear CKA  (target probes)')
        ax.set_ylim(0, 1.05)
        ax.axhline(1.0, color='k', lw=0.4, ls=':')
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=7, loc='lower left')
    fig.suptitle('Before-vs-after fine-tune CKA  --  K=10 multi-seed noise floor, N=40 probes, 95% bootstrap CI',
                 fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    out_path = os.path.join(OUT, 'cka_dot_line_per_direction.png')
    fig.savefig(out_path, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'[saved] {out_path}')


def helpful_harmful_bucket():
    """Group ALL cells (full+freeze1+freeze2) by sign of Delta-Dice and
    report layer-wise mean CKA per bucket. Threshold: |dDice| > 0.01."""
    helpful, neutral, harmful = [], [], []
    for direction, blk in AUDIT['results'].items():
        for fk, cell in blk['cells'].items():
            dd = cell.get('_delta_dice', 0.0) or 0.0
            cka = np.array([cell[L]['cka'] for L in LAYERS])
            noise = np.array([blk['noise_floor_multi_seed'][L]['mean'] for L in LAYERS])
            rec = {'tag': f'{direction}/{fk}', 'dd': float(dd), 'cka': cka,
                   'noise': noise, 'lift': cka - noise}
            if dd > 0.01:
                helpful.append(rec)
            elif dd < -0.01:
                harmful.append(rec)
            else:
                neutral.append(rec)
    print(f'\n=== helpful (dDice > +0.01) [{len(helpful)} cells] ===')
    for r in helpful: print(f'  {r["tag"]:35} dDice={r["dd"]:+.3f}')
    print(f'=== neutral (|dDice| <= 0.01) [{len(neutral)} cells] ===')
    for r in neutral: print(f'  {r["tag"]:35} dDice={r["dd"]:+.3f}')
    print(f'=== harmful (dDice < -0.01) [{len(harmful)} cells] ===')
    for r in harmful: print(f'  {r["tag"]:35} dDice={r["dd"]:+.3f}')

    def _avg(group, field):
        if not group: return np.full(len(LAYERS), np.nan)
        return np.mean(np.stack([r[field] for r in group], axis=0), axis=0)

    print(f'\n{"layer":18} {"helpfulCKA":>12} {"neutralCKA":>12} {"harmfulCKA":>12} {"hpLift":>10} {"ntLift":>10} {"hmLift":>10}')
    h_cka, n_cka, m_cka = _avg(helpful, 'cka'), _avg(neutral, 'cka'), _avg(harmful, 'cka')
    h_lf, n_lf, m_lf = _avg(helpful, 'lift'), _avg(neutral, 'lift'), _avg(harmful, 'lift')
    for i, L in enumerate(LAYERS):
        print(f'{L:18} {h_cka[i]:>12.3f} {n_cka[i]:>12.3f} {m_cka[i]:>12.3f} '
              f'{h_lf[i]:>+10.3f} {n_lf[i]:>+10.3f} {m_lf[i]:>+10.3f}')

    fig, ax = plt.subplots(figsize=(7, 4.5))
    x = np.arange(len(LAYERS))
    if helpful:
        ax.plot(x, h_cka, 'o-', color='tab:green', label=f'helpful ({len(helpful)} cells)')
    if neutral:
        ax.plot(x, n_cka, 'o-', color='tab:gray',  label=f'neutral ({len(neutral)} cells)')
    if harmful:
        ax.plot(x, m_cka, 'o-', color='tab:red',   label=f'harmful ({len(harmful)} cells)')
    # average noise floor across directions
    avg_noise = np.mean(np.stack([
        np.array([AUDIT['results'][d]['noise_floor_multi_seed'][L]['mean'] for L in LAYERS])
        for d in AUDIT['results']
    ], axis=0), axis=0)
    ax.plot(x, avg_noise, '--', color='gray', label='avg noise floor (K=10, 4 sources)')
    ax.set_xticks(x); ax.set_xticklabels([L.replace('_', '\n') for L in LAYERS], fontsize=8)
    ax.set_ylabel('mean CKA across cells in bucket')
    ax.set_ylim(0, 1.05)
    ax.set_title('Helpful vs harmful full-fine-tune cells: layer-CKA signature')
    ax.grid(True, alpha=0.3); ax.legend(fontsize=8)
    fig.tight_layout()
    out_path = os.path.join(OUT, 'cka_helpful_vs_harmful.png')
    fig.savefig(out_path, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'[saved] {out_path}')


def layer_derivative_table():
    """For each direction, compute d(CKA)/d(layer_index) -- i.e., the
    step-to-step change per layer transition. Surface large drops as
    "where fine-tune rewrote the encoder."""
    print('\n=== d(CKA)/d(layer) at full fine-tune per direction ===')
    print(f'{"direction":20} {"trans":12} {"CKA(L_i)":>10} -> {"CKA(L_i+1)":>11}  {"dCKA":>8}')
    for direction, blk in AUDIT['results'].items():
        full = blk['cells']['full']
        for a, b in zip(LAYERS[:-1], LAYERS[1:]):
            ca, cb = full[a]['cka'], full[b]['cka']
            d = cb - ca
            tag = ''
            if d < -0.10:  tag = '<-- drop'
            if d > +0.05:  tag = '<-- rise'
            print(f'{direction:20} {a[:3]+">"+b[:3]:12} {ca:>10.3f} -> {cb:>11.3f}  {d:>+8.3f}  {tag}')


def source_generality_table():
    """Per source S, average L4 CKA(f_S, f_{S->T}) across all targets T.
    Lower mean = source gets rewritten more on average = less general."""
    by_source = {}
    for direction in AUDIT['results']:
        src = direction.split('_to_')[0]
        full = AUDIT['results'][direction]['cells']['full']
        by_source.setdefault(src, []).append({
            'direction': direction,
            'L4_cka': full['L4_bottleneck']['cka'],
            'L4_noise': AUDIT['results'][direction]['noise_floor_multi_seed']['L4_bottleneck']['mean'],
        })
    print('\n=== source generality (L4 bottleneck retention across targets) ===')
    for src, rows in by_source.items():
        ckas   = np.array([r['L4_cka']   for r in rows])
        noises = np.array([r['L4_noise'] for r in rows])
        lifts  = ckas - noises
        print(f'  source={src:10}  n_targets={len(rows)}  '
              f'L4_CKA_mean={ckas.mean():.3f}  lift_above_noise={lifts.mean():+.3f}')
        for r in rows:
            print(f'      {r["direction"]:20} L4={r["L4_cka"]:.3f}  noise={r["L4_noise"]:.3f}  '
                  f'lift={r["L4_cka"] - r["L4_noise"]:+.3f}')


def plot_epoch_trajectory():
    fig, axes = plt.subplots(1, len(TRAJ['runs']), figsize=(6 * len(TRAJ['runs']), 4.5), sharey=True)
    if len(TRAJ['runs']) == 1:
        axes = [axes]
    for ax, (tag, epochs) in zip(axes, TRAJ['runs'].items()):
        # Sort by epoch (None -> place at end as 'best')
        epochs_sorted = sorted(epochs, key=lambda e: (e['epoch'] is None, e['epoch'] or 0))
        x_vals = [e['epoch'] if e['epoch'] is not None else max(
            (ep['epoch'] or 0) for ep in epochs_sorted) + 20 for e in epochs_sorted]
        for L in LAYERS:
            ys = [e['cka_per_layer'][L] for e in epochs_sorted]
            ax.plot(x_vals, ys, 'o-', lw=1.4, label=L, markersize=4)
        ax.set_title(tag)
        ax.set_xlabel('epoch (rightmost = best.pt)')
        ax.set_ylabel('CKA vs $f_S$')
        ax.set_ylim(0, 1.05)
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=7, ncol=2, loc='lower right')
    fig.suptitle('CKA( $f_S$ = MSD-Lung scratch, $f_{S\\to T,e}$ ) along fine-tune trajectory', fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    out_path = os.path.join(OUT, 'cka_epoch_trajectory.png')
    fig.savefig(out_path, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'[saved] {out_path}')


def main():
    plot_dot_line_per_direction()
    helpful_harmful_bucket()
    layer_derivative_table()
    source_generality_table()
    plot_epoch_trajectory()


if __name__ == '__main__':
    main()
