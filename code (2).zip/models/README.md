# Architecture source

Vendored copies of the two architectures used in the project. These files
are kept here so the deliverable contains the actual model implementations,
not just import statements.

## monai_unet_source.py

The MONAI 3D U-Net implementation, copied verbatim from
monai.networks.nets.unet (the version installed in the project's conda
environment as of 2026-06). The five-stage architecture with channels
(32, 64, 128, 256, 512), strides (2, 2, 2, 2), and num_res_units 0 that
the project uses is constructed by the UNet class in this file, wrapped
by MonaiUNet3D in ../model.py.

The relevant invariants for the project's CKA hooks are:

- The encoder/decoder is built recursively via _create_block; the
  outer block is nn.Sequential(down, SkipConnection(submodule), up).
- SkipConnection (from monai.networks.layers.simplelayers) stores its
  nested block as .submodule, not as an indexable child. This is why
  FeatureLadder._locate_ladder in ../extract.py uses
  m[1].submodule[N] rather than positional indexing.

Upstream: https://github.com/Project-MONAI/MONAI, file
monai/networks/nets/unet.py. License: Apache 2.0.

## transunet3d_model.py

Generic_TransUNet_max_ppbp, the encoder-only 3D TransUNet variant the
project uses, from the cloned Chen 2023 codebase. The CNN encoder is a
Generic_UNet-style ladder; the bottleneck is a 12-layer Vision
Transformer; the decoder is a CNN U-Net decoder with deep supervision.
Multi-scale deformable attention injects encoder features at relative
indices [-4, -3, -2] into the ViT layers.

The forward path returns a list of segmentation maps, one per decoder
stage (deep supervision). The Generic_TransUNet_max_ppbp constructor
is invoked from
../code/external/3D-TransUNet/nn_transunet/trainer/nnUNetTrainerV2_DDP.py
when self.model == 'Generic_TransUNet_max_ppbp'.

Upstream: https://github.com/Beckschen/TransUNet (3D branch),
file nn_transunet/networks/transunet3d_model.py.

## vit_modeling.py

The ViT building blocks used by Generic_TransUNet_max_ppbp: Embeddings,
Block, Attention, Mlp, LayerScale, Encoder, Transformer. The Attention
class stores its softmax(QK^T / sqrt(d_k)) output as the second item of
the returned tuple when self.vis is True; the project's
--extract_attention_out path (patched into the upstream train.py) sets
vis=True on every Attention module to capture those maps. The deep ViT
layers in our trained models have cross-probe variance of order 1e-19
at this output, reflecting the attention-collapse documented in
results.md for date 2026-06-17.

Upstream: same as transunet3d_model.py.

## nnunet_generic_unet.py

Generic_UNet from the cloned nnU-Net codebase (renamed here from the
upstream file nnunet_model.py to make its provenance clearer). This is
the plain CNN U-Net used in the recipe-vs-architecture comparison at
results.md date 2026-06-18, where it was trained under the same nnU-Net
trainer as Generic_TransUNet_max_ppbp and reached the same val Dice on
MSD Task06 Lung (0.839 vs 0.838).

The project added a dispatch branch for this class to
../code/external/3D-TransUNet/nn_transunet/trainer/nnUNetTrainerV2_DDP.py,
since the upstream trainer only knew how to instantiate the TransUNet
variant.

Upstream: same as transunet3d_model.py. The original file is
nn_transunet/networks/nnunet_model.py.
