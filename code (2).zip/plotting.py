"""Plot helpers for the trajectory and pair-comparison results.

Kept deliberately small. The figures in deliverable/figures/ were produced by
calling these from the experiment scripts.
"""
from __future__ import annotations

import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def trajectory_grid(json_path, out_path, layers, title=None):
    """One panel per layer; one line per trajectory in the JSON.

    Reads the dippattern-style JSON shape produced by the experiment harness:
    top-level 'runs' is a dict keyed by trajectory tag; each value contains
    an 'epochs' list of {'epoch': int, 'cka_per_layer': {layer -> cka}}.
    """
    data = json.load(open(json_path))
    runs = data.get('runs', data)
    fig, axes = plt.subplots(2, 4, figsize=(16, 8), sharex=True, sharey=True)
    axes = axes.flatten()
    colors = ['#4C78A8', '#F58518', '#54A24B', '#E45756', '#B279A2']
    for ax, L in zip(axes, layers):
        for (tag, info), color in zip(runs.items(), colors):
            recs = [e for e in info.get('epochs', [])
                    if e.get('epoch') is not None and e['epoch'] >= 0]
            recs.sort(key=lambda r: r['epoch'])
            xs = [r['epoch'] for r in recs]
            ys = [r['cka_per_layer'].get(L, float('nan')) for r in recs]
            ax.plot(xs, ys, marker='o', label=tag, color=color)
        ax.set_title(L)
        ax.set_ylim(-0.05, 1.05)
        ax.grid(alpha=0.3)
    for ax in axes[-4:]:
        ax.set_xlabel('epoch')
    for ax in axes[::4]:
        ax.set_ylabel('CKA')
    axes[0].legend(loc='lower right', fontsize='small')
    if title:
        fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130, bbox_inches='tight')


def simulation_sweep(json_path, out_path, deepest_only: bool = True):
    """For each input kind, plot deepest-layer CKA versus depth, one line per norm."""
    data = json.load(open(json_path))
    cfg = data['config']
    res = data['results']
    fig, axes = plt.subplots(2, len(cfg['input_kinds']),
                             figsize=(5 * len(cfg['input_kinds']), 8),
                             sharex=True, sharey='row')
    colors = ['#4C78A8', '#F58518', '#54A24B', '#E45756']
    for col, kind in enumerate(cfg['input_kinds']):
        for norm, color in zip(cfg['norms'], colors):
            xs, ys_cka, ys_R = [], [], []
            for depth in cfg['depths']:
                tag = f'n={max(cfg["n_probes"])}|kind={kind}|norm={norm}|depth={depth}'
                if tag not in res:
                    continue
                key = f'layer_{depth-1}' if deepest_only else 'layer_0'
                rec = res[tag][key]
                xs.append(depth)
                ys_cka.append(rec['cka_mean'])
                ys_R.append(rec['R_mean'])
            axes[0][col].plot(xs, ys_cka, marker='o', label=norm, color=color)
            axes[1][col].plot(xs, ys_R, marker='o', label=norm, color=color)
        axes[0][col].set_title(f'input = {kind}')
        axes[1][col].set_xlabel('depth')
        axes[0][col].set_ylim(-0.05, 1.05)
        axes[1][col].set_ylim(-0.5, 1.05)
        axes[0][col].grid(alpha=0.3)
        axes[1][col].grid(alpha=0.3)
    axes[0][0].set_ylabel('raw CKA')
    axes[1][0].set_ylabel('null-corrected R')
    axes[0][0].legend(loc='lower left', fontsize='small')
    fig.tight_layout()
    fig.savefig(out_path, dpi=130, bbox_inches='tight')
