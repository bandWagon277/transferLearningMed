"""Fine-grid per-epoch CKA trajectory for the 4 directional runs that
retained intermediate checkpoints via `--keep-checkpoints` (jobs
51866443-51866446, resubmitted on 2026-06-16).

For each available `checkpoint_epoch_<E>.pt` in the four fine-grid runs:
  - MSD->BraTS full FT      (ckpt against F_S_MSD on BraTS probes)
  - MSD->BraTS freeze-1     (ckpt against F_S_MSD on BraTS probes)
  - BraTS->MSD full FT      (ckpt against F_S_BRATS on MSD probes)
  - BraTS->MSD freeze-1     (ckpt against F_S_BRATS on MSD probes)

Output:
  runs/cka_finegrid_trajectory_0616.json
  runs/figures/0616/cka_finegrid_trajectory.png   (matplotlib, 2x2 grid)

Run AFTER all four jobs complete and `last.pt` exists for each.
"""
from __future__ import annotations
import glob
import json
import os
import re
import sys

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

import numpy as np  # noqa: E402

from affinity import (  # noqa: E402
    DatasetSpec, list_cases, linear_cka, _extract_layer_ladder_features,
)

REPO = os.path.dirname(THIS)
N_PROBES = 40
SEED = 42

# Source checkpoints (fixed reference encoders for CKA's f_S argument).
F_S_MSD = os.path.join(
    REPO, 'code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt')
F_S_BRATS = os.path.join(
    REPO, 'code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt')

TRAJ_RUNS = {
    # name : (transfer-run dir, source ckpt, probe layout, probe root)
    'MSD->BraTS/full':    (
        'code/pretrained/brats_flair_pretrain/brats_from_msd_finegrid',
        F_S_MSD, 'brats_flair', 'data/BraTS2021_Training'),
    'MSD->BraTS/freeze1': (
        'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze1_finegrid',
        F_S_MSD, 'brats_flair', 'data/BraTS2021_Training'),
    'BraTS->MSD/full':    (
        'code/pretrained/oktaykurt_retrain/msd_from_brats_finegrid',
        F_S_BRATS, 'msd', 'data/MSD_Task06_Lung/Task06_Lung'),
    'BraTS->MSD/freeze1': (
        'code/pretrained/oktaykurt_retrain/msd_from_brats_freeze1_finegrid',
        F_S_BRATS, 'msd', 'data/MSD_Task06_Lung/Task06_Lung'),
}


def _gather_probes(layout: str, root: str, n: int) -> list[str]:
    spec = DatasetSpec(name='probe', root=root, layout=layout)
    cases = list_cases(spec)
    rng = np.random.default_rng(SEED)
    idx = rng.permutation(len(cases))[:n]
    return [cases[i]['image'] for i in sorted(idx.tolist())]


def _epoch_from_name(name: str) -> int | None:
    m = re.match(r'checkpoint_epoch_0*(\d+)\.pt', name)
    if m:
        return int(m.group(1))
    if name == 'best.pt':
        return None  # "best" is a separate marker
    if name == 'last.pt':
        return -1    # treat as final-epoch marker
    return None


def main():
    out_json = os.path.join(REPO, 'runs/cka_finegrid_trajectory_0616.json')
    fig_dir = os.path.join(REPO, 'runs/figures/0616')
    fig_path = os.path.join(fig_dir, 'cka_finegrid_trajectory.png')
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    # Precompute per-probe-set source features. F_S_MSD vs BraTS probes is one
    # extraction; F_S_BRATS vs MSD probes is the other.
    probe_cache: dict[str, list[str]] = {}
    src_feats_cache: dict[tuple, dict] = {}

    def _src_feats(src_ckpt, layout, root):
        key = (src_ckpt, layout, root)
        if key not in src_feats_cache:
            probes = _gather_probes(layout, os.path.join(REPO, root), N_PROBES)
            probe_cache[layout] = probes
            print(f'[probes] {len(probes)} {layout}')
            feats = _extract_layer_ladder_features(
                ckpt_path=src_ckpt, probe_paths=probes,
                in_channels=1, out_channels=1, layout=layout,
            )
            src_feats_cache[key] = feats
        return src_feats_cache[key], probe_cache[layout]

    results = {}
    for tag, (rel, src_ckpt, layout, root) in TRAJ_RUNS.items():
        run_dir = os.path.join(REPO, rel)
        if not os.path.isdir(run_dir):
            print(f'[skip] {tag}: dir missing {run_dir}')
            continue
        feats_s, probes = _src_feats(src_ckpt, layout, root)

        ckpts = sorted(glob.glob(os.path.join(run_dir, 'checkpoint_epoch_*.pt')))
        for extra in ('best.pt', 'last.pt'):
            p = os.path.join(run_dir, extra)
            if os.path.isfile(p):
                ckpts.append(p)
        if not ckpts:
            print(f'[skip] {tag}: no checkpoints under {run_dir}')
            continue

        epoch_recs = []
        for ck in ckpts:
            name = os.path.basename(ck)
            ep = _epoch_from_name(name)
            print(f'[{tag}] {name} (ep={ep})')
            feats_t = _extract_layer_ladder_features(
                ckpt_path=ck, probe_paths=probes,
                in_channels=1, out_channels=1, layout=layout,
            )
            per_layer = {L: float(linear_cka(feats_s[L], feats_t[L]))
                         for L in feats_s}
            epoch_recs.append({
                'ckpt_name': name, 'epoch': ep,
                'cka_per_layer': per_layer,
            })
        results[tag] = {
            'run_dir': rel,
            'src_ckpt': src_ckpt,
            'probe_layout': layout,
            'epochs': epoch_recs,
        }

    out = {
        'n_probes': N_PROBES, 'seed': SEED,
        'src_msd': F_S_MSD, 'src_brats': F_S_BRATS,
        'runs': results,
    }
    with open(out_json, 'w') as f:
        json.dump(out, f, indent=2)
    print(f'[saved] {out_json}')

    # Plot a 2x2 grid: rows = direction, cols = freeze depth.
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print('[plot] matplotlib not available; JSON saved')
        return

    layout = [
        ('MSD->BraTS/full',    (0, 0)),
        ('MSD->BraTS/freeze1', (0, 1)),
        ('BraTS->MSD/full',    (1, 0)),
        ('BraTS->MSD/freeze1', (1, 1)),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), sharey=True)
    for tag, (r, c) in layout:
        ax = axes[r][c]
        if tag not in results:
            ax.set_title(f'{tag} (missing)')
            continue
        recs = [e for e in results[tag]['epochs']
                if e['epoch'] is not None and e['epoch'] >= 0]
        recs.sort(key=lambda e: e['epoch'])
        if not recs:
            ax.set_title(f'{tag} (no per-epoch ckpts yet)')
            continue
        layers = list(recs[0]['cka_per_layer'].keys())
        for L in layers:
            xs = [e['epoch'] for e in recs]
            ys = [e['cka_per_layer'][L] for e in recs]
            ax.plot(xs, ys, marker='o', label=L)
        ax.set_xlabel('epoch')
        ax.set_ylabel('CKA(f_S, f_S->T,e)')
        ax.set_title(tag)
        ax.set_ylim(0, 1.0)
        ax.grid(alpha=0.3)
    axes[0][1].legend(bbox_to_anchor=(1.04, 1), loc='upper left',
                      borderaxespad=0, fontsize='small')
    fig.suptitle('Fine-grid CKA trajectory '
                 '(epochs 0/5/10/15/20/25, seed=42)')
    fig.tight_layout()
    fig.savefig(fig_path, dpi=150, bbox_inches='tight')
    print(f'[saved] {fig_path}')


if __name__ == '__main__':
    main()
