"""Random-init pairwise CKA baseline (task 2 of 06-15).

Architecture+inductive-bias baseline: instantiate K=5 random-init 3D U-Nets
at different seeds, compute pairwise CKA across all C(5,2)=10 pairs per
layer of the standard 7-point ladder (L0..L4 + D2 + D1).

Interpretation: linear CKA in [0, 1] by construction. If two architecturally
identical random nets land near ~0.5 on a given layer, that is the share of
representational structure that comes from tokenization + InstanceNorm +
PReLU + skip-connection geometry alone -- not from learning. Any CKA below
that level for a transferred model means the fine-tune moved the
representation further from the source than two architecture-matched random
nets are from each other (NOT "anti-correlated" -- linear CKA cannot be
negative).

Outputs:
  runs/random_pair_cka_0615.json -- per (probe_set, layer, pair) CKA + summary.
"""
from __future__ import annotations

import itertools
import json
import os
import sys

import numpy as np

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

from affinity import (  # noqa: E402
    DatasetSpec, list_cases, linear_cka, _extract_layer_ladder_features,
)

REPO = os.path.dirname(THIS)
K_SEEDS = 5
N_PROBES = 40

PROBE_SETS = [
    ('brats_flair', 'data/BraTS2021_Training'),
    ('msd',         'data/MSD_Task06_Lung/Task06_Lung'),
]


def _gather_probes(layout: str, root: str, n: int) -> list[str]:
    spec = DatasetSpec(name='probe', root=root, layout=layout)
    cases = list_cases(spec)
    rng = np.random.default_rng(42)
    idx = rng.permutation(len(cases))[:n]
    return [cases[i]['image'] for i in sorted(idx.tolist())]


def _pairwise_cka_random(probe_paths: list[str], layout: str, k: int) -> dict:
    """Extract features from k random-init UNets and compute pairwise CKA."""
    feats_per_seed = []
    for seed in range(k):
        print(f'[seed {seed}] extracting features (layout={layout})')
        feats = _extract_layer_ladder_features(
            ckpt_path=None, probe_paths=probe_paths,
            in_channels=1, out_channels=1, layout=layout,
            random_init_seed=seed,
        )
        feats_per_seed.append(feats)

    layers = list(feats_per_seed[0].keys())
    pairs = list(itertools.combinations(range(k), 2))
    per_pair = {}
    for (i, j) in pairs:
        tag = f'seed{i}_vs_seed{j}'
        per_pair[tag] = {
            L: float(linear_cka(feats_per_seed[i][L], feats_per_seed[j][L]))
            for L in layers
        }

    summary = {}
    for L in layers:
        vals = np.array([per_pair[t][L] for t in per_pair])
        summary[L] = {
            'mean': float(vals.mean()),
            'std':  float(vals.std(ddof=1)),
            'min':  float(vals.min()),
            'max':  float(vals.max()),
            'n_pairs': len(vals),
        }
    return {'per_pair': per_pair, 'summary': summary, 'layers': layers}


def main():
    out_path = os.path.join(REPO, 'runs/random_pair_cka_0615.json')
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    results = {}
    for layout, root in PROBE_SETS:
        print(f'\n=== probe={layout} ({root}) ===')
        probes = _gather_probes(layout, os.path.join(REPO, root), N_PROBES)
        results[layout] = _pairwise_cka_random(probes, layout, K_SEEDS)

    with open(out_path, 'w') as f:
        json.dump({
            'k_seeds': K_SEEDS,
            'n_probes': N_PROBES,
            'probe_sets': [p[0] for p in PROBE_SETS],
            'results': results,
        }, f, indent=2)
    print(f'\n[saved] {out_path}')

    print('\n=== Pairwise random-init CKA (mean +- std across 10 pairs) ===')
    layers = results[PROBE_SETS[0][0]]['layers']
    print(f'{"layer":18} | ' + ' | '.join(f'{p[0]:>20}' for p in PROBE_SETS))
    for L in layers:
        cells = []
        for layout, _ in PROBE_SETS:
            s = results[layout]['summary'][L]
            cells.append(f'{s["mean"]:.3f} +- {s["std"]:.3f}')
        print(f'{L:18} | ' + ' | '.join(f'{c:>20}' for c in cells))


if __name__ == '__main__':
    main()
