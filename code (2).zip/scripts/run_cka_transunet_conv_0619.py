"""TransUNet conv-layer CKA across 3 ckpts (Codex 0619 Q3-A).

Three .npz files (one per ckpt) are written by train.py --extract_conv_out:

  source.npz   — BraTS21 pretrain (TransUNet conv encoder + decoder features)
  scratch.npz  — MSD scratch
  transfer.npz — BraTS21 -> MSD transfer

We compute raw + null-corrected CKA per layer across the 3 pairs, on MSD val
probes. Output:
  runs/cka_transunet_conv_0619.json
  runs/figures/0619/cka_transunet_conv.png   (2x ladder per pair)

Companion to the ViT attention-CKA from 06-17 (which collapsed at layer 2+ due
to uniform attention). The CNN encoder/decoder are the meaningful TransUNet
representational scaffold; their CKA should look qualitatively like the
MONAI U-Net trajectory.
"""
from __future__ import annotations
import json
import os
import sys

import numpy as np

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)
from affinity import null_corrected_cka_with_ci

REPO = os.path.dirname(THIS)
ATTN_DIR = os.path.join(REPO, 'scratch')
OUT_JSON = os.path.join(REPO, 'runs/cka_transunet_conv_0619.json')
OUT_PNG  = os.path.join(REPO, 'runs/figures/0619/cka_transunet_conv.png')

CKPTS = {
    'source':   os.path.join(ATTN_DIR, 'transunet_conv_source.npz'),
    'scratch':  os.path.join(ATTN_DIR, 'transunet_conv_scratch.npz'),
    'transfer': os.path.join(ATTN_DIR, 'transunet_conv_transfer.npz'),
}

PAIRS = [
    ('source vs scratch',  'source',  'scratch'),
    ('source vs transfer', 'source',  'transfer'),
    ('scratch vs transfer','scratch', 'transfer'),
]


def main():
    os.makedirs(os.path.dirname(OUT_JSON), exist_ok=True)
    os.makedirs(os.path.dirname(OUT_PNG), exist_ok=True)

    arrs = {}
    for tag, path in CKPTS.items():
        if not os.path.isfile(path):
            print(f'  ERROR: missing {tag} npz at {path}', file=sys.stderr)
            return 2
        z = np.load(path)
        # Extracted shapes are (n_iter, batch, channels). Flatten the leading
        # two axes into a single "probe" axis so CKA sees (N, channels).
        arrs[tag] = {}
        for k in z.files:
            a = z[k]
            if a.ndim == 3:
                a = a.reshape(-1, a.shape[-1])
            arrs[tag][k] = a
        first_layer = next(iter(arrs[tag].values()))
        print(f'[{tag}] {len(arrs[tag])} layers, first-layer shape={first_layer.shape}')

    layers = sorted(arrs['source'].keys())
    results = {pair_name: {} for pair_name, _, _ in PAIRS}
    for L in layers:
        for pair_name, a, b in PAIRS:
            stats = null_corrected_cka_with_ci(
                arrs[a][L], arrs[b][L],
                n_boot=200, n_perm=200, seed=42)
            results[pair_name][L] = stats

    print('\n[Raw + null-corrected CKA per layer per pair]')
    print(f'{"layer":>10} | ' +
          ' | '.join(f'{p:>32}' for p, _, _ in PAIRS))
    for L in layers:
        cells = []
        for p, _, _ in PAIRS:
            r = results[p][L]
            cells.append(f'cka={r["cka"]:.3f} R={r["cka_null_corrected"]:.3f}')
        print(f'{L:>10} | ' + ' | '.join(f'{c:>32}' for c in cells))

    with open(OUT_JSON, 'w') as f:
        json.dump({'pairs': results, 'layers': layers, 'inputs': CKPTS},
                  f, indent=2)
    print(f'[saved] {OUT_JSON}')

    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        return 0

    fig, axes = plt.subplots(1, 2, figsize=(13, 5), sharey=True)
    xs = list(range(len(layers)))
    for pair_name, _, _ in PAIRS:
        ys_raw = [results[pair_name][L]['cka'] for L in layers]
        ys_R   = [results[pair_name][L]['cka_null_corrected'] for L in layers]
        axes[0].plot(xs, ys_raw, marker='o', label=pair_name)
        axes[1].plot(xs, ys_R, marker='o', label=pair_name)
    for ax, title in zip(axes, ['Raw CKA', 'Null-corrected R = (CKA - median_null) / (1 - median_null)']):
        ax.set_xticks(xs)
        ax.set_xticklabels(layers, rotation=45, ha='right')
        ax.set_xlabel('TransUNet conv layer')
        ax.set_title(title)
        ax.grid(alpha=0.3)
    axes[0].set_ylim(-0.05, 1.05)
    axes[1].set_ylim(-0.5, 1.05)
    axes[0].set_ylabel('CKA on MSD probes')
    axes[0].legend(loc='lower left', fontsize='small')
    fig.suptitle('TransUNet conv-layer CKA — 3 ckpts on MSD probes (Codex 0619 Q3-A)')
    fig.tight_layout()
    fig.savefig(OUT_PNG, dpi=130, bbox_inches='tight')
    print(f'[saved] {OUT_PNG}')


if __name__ == '__main__':
    sys.exit(main())
