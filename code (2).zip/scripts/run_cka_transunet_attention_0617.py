"""CKA on TransUNet ViT-attention maps (meetplan0616 item 3 follow-up).

Three .npz files (one per ckpt) are written by train.py --extract_attention_out
under scratch/transunet_attn_*.npz:

  source.npz   — BraTS21 pretrain (loaded into MSD architecture via partial-load)
  scratch.npz  — MSD scratch
  transfer.npz — BraTS21 -> MSD transfer

Each contains layer_00..layer_11 of shape (n_probes, n_heads, seq, seq) — the
softmax(QK^T / sqrt(d_k)) attention maps. We compute linear CKA between every
pair, per layer, on the flattened (n_probes, n_heads*seq*seq) matrices.

Output:
  runs/cka_transunet_attention_0617.json     — per-layer CKA per pair
  runs/figures/0617/cka_transunet_attention.png  — line plot per pair

The probes are nnU-Net val_gen patches; train.py is deterministic per
seed+task+fold, so the same probe ordering is used across all 3 extractions.
"""
from __future__ import annotations
import json
import os
import sys

import numpy as np

REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
ATTN_DIR = os.path.join(REPO, 'scratch')
OUT_JSON = os.path.join(REPO, 'runs/cka_transunet_attention_0617.json')
OUT_PNG  = os.path.join(REPO, 'runs/figures/0617/cka_transunet_attention.png')

CKPTS = {
    'source':   os.path.join(ATTN_DIR, 'transunet_attn_source.npz'),
    'scratch':  os.path.join(ATTN_DIR, 'transunet_attn_scratch.npz'),
    'transfer': os.path.join(ATTN_DIR, 'transunet_attn_transfer.npz'),
}

PAIRS = [
    ('source vs scratch',  'source',  'scratch'),
    ('source vs transfer', 'source',  'transfer'),
    ('scratch vs transfer','scratch', 'transfer'),
]


def linear_cka_gram(X: np.ndarray, Y: np.ndarray) -> float:
    """Linear CKA on (n_probes, feature_dim) matrices via the Gram form."""
    n = X.shape[0]
    H = np.eye(n) - np.ones((n, n)) / n
    Kx = X @ X.T
    Ky = Y @ Y.T
    Kxc = H @ Kx @ H
    Kyc = H @ Ky @ H
    num = float((Kxc * Kyc).sum())
    den = float(np.sqrt((Kxc * Kxc).sum() * (Kyc * Kyc).sum()) + 1e-12)
    return num / den


def main():
    os.makedirs(os.path.dirname(OUT_JSON), exist_ok=True)
    os.makedirs(os.path.dirname(OUT_PNG), exist_ok=True)

    arrs = {}
    for tag, path in CKPTS.items():
        if not os.path.isfile(path):
            print(f'  ERROR: missing {tag} npz at {path}', file=sys.stderr)
            return 2
        z = np.load(path)
        arrs[tag] = {k: z[k] for k in z.files}
        first_layer = next(iter(arrs[tag].values()))
        print(f'[{tag}] {len(arrs[tag])} layers, layer-0 shape={first_layer.shape}')

    layers = sorted(arrs['source'].keys())
    results = {pair_name: {} for pair_name, _, _ in PAIRS}
    for L in layers:
        flat = {}
        for tag in arrs:
            a = arrs[tag][L]   # (n, heads, seq, seq)
            flat[tag] = a.reshape(a.shape[0], -1)  # (n, heads*seq*seq)
        for pair_name, a, b in PAIRS:
            results[pair_name][L] = linear_cka_gram(flat[a], flat[b])

    print('\n[CKA on attention maps per ViT layer]')
    print(f'{"layer":>10} | ' + ' | '.join(f'{p:>22}' for p,_,_ in PAIRS))
    for L in layers:
        row = ' | '.join(f'{results[p][L]:>22.4f}' for p,_,_ in PAIRS)
        print(f'{L:>10} | {row}')

    with open(OUT_JSON, 'w') as f:
        json.dump({'pairs': results, 'layers': layers,
                   'inputs': {k: v for k, v in CKPTS.items()}}, f, indent=2)
    print(f'[saved] {OUT_JSON}')

    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        return 0

    fig, ax = plt.subplots(figsize=(9, 5))
    xs = list(range(len(layers)))
    for pair_name, _, _ in PAIRS:
        ys = [results[pair_name][L] for L in layers]
        ax.plot(xs, ys, marker='o', label=pair_name)
    ax.set_xticks(xs)
    ax.set_xticklabels(layers, rotation=45, ha='right')
    ax.set_xlabel('ViT layer')
    ax.set_ylabel('CKA on softmax attention maps')
    ax.set_ylim(0, 1.05)
    ax.set_title('TransUNet ViT attention-map CKA across ckpts (meetplan0616 item 3)')
    ax.grid(alpha=0.3)
    ax.legend(loc='lower left')
    fig.tight_layout()
    fig.savefig(OUT_PNG, dpi=150, bbox_inches='tight')
    print(f'[saved] {OUT_PNG}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
