"""Convert BraTS 2021 (FLAIR-only) into nnU-Net Task500_BraTS2021 layout.

Per the 2026-06-15 Codex consult: emit FLAIR as the sole input modality and
binarized WT (label>0) as the foreground class. Matches Task500 ID used by
the 3D-TransUNet encoder_only.yaml config.

Output:
  $nnUNet_raw_data_base/nnUNet_raw_data/Task500_BraTS2021/
    imagesTr/<case>_0000.nii.gz        # FLAIR only
    labelsTr/<case>.nii.gz             # binary WT
    dataset.json

Source layout:
  data/BraTS2021_Training/BraTS2021_<id>/BraTS2021_<id>_{flair,seg}.nii.gz
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed

import nibabel as nib
import numpy as np

REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
SRC = os.path.join(REPO, 'data/BraTS2021_Training')
DST_ROOT = os.path.join(REPO, 'data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data/Task500_BraTS2021')
TASK_NAME = 'Task500_BraTS2021'


def _process_case(case: str) -> tuple[str, bool, str]:
    src_dir = os.path.join(SRC, case)
    flair = os.path.join(src_dir, f'{case}_flair.nii.gz')
    seg   = os.path.join(src_dir, f'{case}_seg.nii.gz')
    if not (os.path.isfile(flair) and os.path.isfile(seg)):
        return (case, False, 'missing flair or seg')

    img_out = os.path.join(DST_ROOT, 'imagesTr', f'{case}_0000.nii.gz')
    lbl_out = os.path.join(DST_ROOT, 'labelsTr', f'{case}.nii.gz')
    if os.path.isfile(img_out) and os.path.isfile(lbl_out):
        return (case, True, 'cached')

    # FLAIR pass-through (nnU-Net does its own intensity normalization).
    flair_nii = nib.load(flair)
    nib.save(flair_nii, img_out)

    # Binarize segmentation: BraTS uses {0,1,2,4} subregions; WT = any non-zero.
    seg_nii = nib.load(seg)
    seg_data = np.asanyarray(seg_nii.dataobj)
    bin_data = (seg_data > 0).astype(np.uint8)
    bin_nii = nib.Nifti1Image(bin_data, seg_nii.affine, seg_nii.header)
    bin_nii.set_data_dtype(np.uint8)
    nib.save(bin_nii, lbl_out)
    return (case, True, 'wrote')


def main():
    os.makedirs(os.path.join(DST_ROOT, 'imagesTr'), exist_ok=True)
    os.makedirs(os.path.join(DST_ROOT, 'labelsTr'), exist_ok=True)

    cases = sorted([d for d in os.listdir(SRC)
                    if d.startswith('BraTS2021_')
                    and os.path.isdir(os.path.join(SRC, d))])
    print(f'[convert] {len(cases)} BraTS21 cases -> {DST_ROOT}')

    n_ok, n_skip, n_err = 0, 0, 0
    with ProcessPoolExecutor(max_workers=4) as ex:
        futs = {ex.submit(_process_case, c): c for c in cases}
        for f in as_completed(futs):
            case, ok, msg = f.result()
            if ok and msg == 'cached':
                n_skip += 1
            elif ok:
                n_ok += 1
            else:
                n_err += 1
                print(f'  ERROR {case}: {msg}')
            if (n_ok + n_skip + n_err) % 100 == 0:
                print(f'  progress {n_ok + n_skip + n_err}/{len(cases)}'
                      f' (ok={n_ok} cache={n_skip} err={n_err})')

    print(f'[convert] done: {n_ok} new, {n_skip} cached, {n_err} errors')

    dataset_json = {
        'name': TASK_NAME,
        'description': 'BraTS 2021 FLAIR-only binary whole-tumor segmentation '
                       '(post-2026-06-15 Codex consult: single modality, '
                       'binary mask).',
        'reference': 'BraTS 2021 challenge (Baid et al. 2021, arXiv:2107.02314)',
        'licence': 'CC-BY-NC',
        'release': '1.0 (2026-06-15)',
        'tensorImageSize': '4D',
        'modality': {'0': 'FLAIR'},
        'labels': {'0': 'background', '1': 'tumor'},
        'numTraining': n_ok + n_skip,
        'numTest': 0,
        'training': [
            {'image': f'./imagesTr/{c}.nii.gz', 'label': f'./labelsTr/{c}.nii.gz'}
            for c in cases
            if os.path.isfile(os.path.join(DST_ROOT, 'imagesTr', f'{c}_0000.nii.gz'))
        ],
        'test': [],
    }
    with open(os.path.join(DST_ROOT, 'dataset.json'), 'w') as f:
        json.dump(dataset_json, f, indent=2)
    print(f'[convert] dataset.json written ({len(dataset_json["training"])} train entries)')


if __name__ == '__main__':
    sys.exit(main())
