# Scripts that produced the saved results, plus raw -> NIfTI staging

## Raw data -> NIfTI, per dataset

Every dataset used in this project has a documented conversion path from its
raw form (as distributed by the source archive) into the nnU-Net task layout
that the training scripts consume.

| Dataset (nnU-Net task) | Raw form | Converter here | What it does |
|---|---|---|---|
| BraTS 2021 (Task500)     | already NIfTI, 4 modalities per case | `convert_brats_to_nnunet_task500.py` | Pick FLAIR channel only; binarize `label > 0` -> whole tumor; drop the other three MRI sequences; write nnU-Net layout. |
| BraTS 2024 (Task502)     | already NIfTI, 4 modalities per case | `convert_brats2024_to_nnunet_task502.py` | Same recipe as BraTS21, plus (a) filter out 38 UCSF patients with IDs < 2000 (overlap with BraTS21) and (b) keep one canonical post-treatment timepoint per patient. |
| MSD-Lung (Task006)       | already NIfTI (Medical Segmentation Decathlon) | `msd_lung_stage.py` | No content conversion. Just rename `<case>.nii.gz` -> `<case>_0000.nii.gz` on the image side and write `dataset.json`. Labels are already binary. |
| RIDER Lung CT (Task514)  | zipped DICOM series + DICOM-SEG masks | `dicom_to_nifti_rider.py` | Per patient: extract every CT zip, pick the largest CT series, decode the DICOM-SEG mask (`pydicom_seg.SegmentReader`), resample the mask onto the CT grid, save both as NIfTI, then populate Task514. |
| QIN Lung CT (Task512)    | DICOM series + separate segmentation NIfTIs | `dicom_to_nifti_qin.py` | Per case: DICOM series -> NIfTI (`SimpleITK.ImageSeriesReader`), pair with the tumor mask, binarize non-zero labels, drop non-tumor cases. |

For any other DICOM directory not covered above, the minimal generic
converter is:

  `dicom_series_to_nifti.py <dicom_dir> <out.nii.gz>`

which uses `SimpleITK.ImageSeriesReader` to concatenate DICOM slices into a
single volume. Both `dicom_to_nifti_rider.py` and `dicom_to_nifti_qin.py` wrap
this pattern with dataset-specific bookkeeping.

### Notes on DICOM-SEG (segmentation) files

A DICOM-SEG is *one* `.dcm` file that holds the entire mask, not a directory
of slices. The RIDER converter's `decode_seg()` function (lines ~89-131 of
`dicom_to_nifti_rider.py`) is the reference pattern:
`pydicom_seg.SegmentReader().read(pydicom.dcmread(seg_file))`, then
`sitk.Resample(mask, ref_ct_img, sitk.Transform(), sitk.sitkNearestNeighbor, 0)`
to align to the CT grid.

## Analysis / CKA / experiment drivers

Each file here reproduces a specific JSON in `deliverable/data/` or a specific
PNG in `deliverable/figures/`. Paths inside are absolute to the cluster
filesystem -- they were kept unchanged from the production runs so numeric
results can be regenerated exactly.

| Script | Result it produced |
|---|---|
| `compute_jon_method_pairs.py`         | `data/jon_method_all_pairs_0603.json` + `data/orthohash_all_pairs_0605.json` |
| `qin_filter_tumor.py`                 | `data/qin_lung_ct/filter_stats.json` (tumor-only QIN subset) |
| `qin_region_diagnostic.py`            | `runs/figures/qin_train_label_distribution.png` |
| `run_cka_brats_qin_0608.py`           | `data/cka_before_after_0608.json` |
| `run_cka_brats_msd_0608.py`           | `data/cka_before_after_msd_0608.json` + `data/dice_summary_msd_0608.json` |
| `run_cka_epoch_trajectory_0611.py`    | `data/cka_epoch_trajectory_0611.json` |
| `run_random_pair_cka_0615.py`         | `data/random_pair_cka_0615.json` |
| `run_cka_finegrid_trajectory_0616.py` | `data/cka_finegrid_trajectory_0616.json` + `figures/cka_finegrid_trajectory.png` |
| `run_cka_norm_probesize_0617.py`      | `data/cka_norm_probesize_0617.json` + `figures/cka_norm_probesize.png` |
| `run_cka_dippattern_compare_0617.py`  | `data/cka_dippattern_compare_0617.json` + `figures/cka_dippattern_compare.png` |
| `run_cka_transunet_attention_0617.py` | `data/cka_transunet_attention_0617.json` + `figures/cka_transunet_attention.png` |
| `run_cka_transunet_conv_0619.py`      | `data/cka_transunet_conv_0619.json` + `figures/cka_transunet_conv.png` |
| `sim_cka_gaussian_probes_0619.py`     | `data/sim_cka_gaussian_probes_0619.json` + `figures/sim_cka_gaussian_probes.png` |
| `tumor_diameter.py`                   | `deliverable/measurements/*_diameter.csv` |
| `render_dataset_samples.py`           | Per-dataset sample montages |
| `render_overlays_brats24_msd_nnunet.py` | Best/worst prediction overlays for the deck |

## What lives outside this folder

- Recipe-vs-architecture 2x2 (2026-06-18) and v1 architecture comparison
  (2026-05-13) are training runs -- see `../cases.py` named factories, or
  `../../code/pretrain_brats_flair.py` for the full production driver.
- 3D TransUNet runs are configured via YAML + sbatch wrappers under
  `../../code/external/3D-TransUNet`; see `../TRANSUNET.md`.
