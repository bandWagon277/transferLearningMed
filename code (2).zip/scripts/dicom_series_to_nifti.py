"""Minimal DICOM-series -> NIfTI converter.

Given a directory of DICOM slice files (one .dcm per axial slice, all belonging
to the same series), write a single NIfTI volume. This is the core pattern the
two dataset-specific builders (dicom_to_nifti_rider.py, dicom_to_nifti_qin.py)
each wrap with extra domain logic.

    python scripts/dicom_series_to_nifti.py <dicom_dir> <out.nii.gz>

Requires: SimpleITK, pydicom (both in the medicaldiffusion conda env).

For DICOM-SEG (segmentation) files -- which are a *single* .dcm that contains
the entire mask, not a directory of slices -- see dicom_to_nifti_rider.py's
decode_seg() function, which uses pydicom_seg.SegmentReader and then resamples
the mask onto the reference CT grid.
"""
from __future__ import annotations
import argparse, os, sys
import SimpleITK as sitk


def dicom_series_to_nifti(dicom_dir: str, out_path: str) -> str:
    """Read all DICOM slices in dicom_dir as one series, save as NIfTI."""
    reader = sitk.ImageSeriesReader()
    series_ids = reader.GetGDCMSeriesIDs(dicom_dir)
    if not series_ids:
        raise RuntimeError(f"no DICOM series found under {dicom_dir}")
    if len(series_ids) > 1:
        print(f"[warn] {len(series_ids)} series found; picking the longest",
              file=sys.stderr)
    # Pick the series with the most files (usually the axial CT/MR).
    best_files, best_id = [], None
    for sid in series_ids:
        files = reader.GetGDCMSeriesFileNames(dicom_dir, sid)
        if len(files) > len(best_files):
            best_files, best_id = files, sid
    reader.SetFileNames(best_files)
    img = reader.Execute()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    sitk.WriteImage(img, out_path)
    print(f"wrote {out_path}  shape={img.GetSize()}  "
          f"spacing={tuple(round(s, 3) for s in img.GetSpacing())}  "
          f"series={best_id}  n_slices={len(best_files)}")
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dicom_dir", help="directory of DICOM slices (one series)")
    ap.add_argument("out_path",  help="output .nii.gz path")
    args = ap.parse_args()
    dicom_series_to_nifti(args.dicom_dir, args.out_path)


if __name__ == "__main__":
    main()
