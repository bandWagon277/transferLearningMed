"""Before-vs-after fine-tune CKA on existing BraTS<->QIN transfer pairs.

Operationalizes meetplan0606 point 1: for each (source S, target T) cell,
measure CKA_T(f_S, f_{S->T}) on target probes. High CKA = feature reuse;
low CKA = encoder rewritten = "just-better init."

The six pairs we have on disk (configs verified 2026-06-08):

  Direction 1: S=BraTS, T=QIN  (probes = QIN val cases)
    f_S          = brats_flair_pretrain/brats_vanilla_v1/best.pt   (4ch,3ch)
    f_{S->T,full}    = oktaykurt_retrain/lung_vanilla_qinonly_from_brats_v1/best.pt
    f_{S->T,freeze1} = oktaykurt_retrain/lung_vanilla_qinonly_from_brats_freeze1/best.pt
    f_{S->T,freeze2} = oktaykurt_retrain/lung_vanilla_qinonly_from_brats_freeze2/best.pt

  Direction 2: S=QIN, T=BraTS  (probes = BraTS val cases)
    f_S          = oktaykurt_retrain/lung_vanilla_qinonly_v6_rot200/best.pt  (1ch,1ch)
    f_{S->T,full}    = brats_flair_pretrain/brats_vanilla_from_qin_v1/best.pt
    f_{S->T,freeze1} = brats_flair_pretrain/brats_vanilla_from_qin_freeze1/best.pt
    f_{S->T,freeze2} = brats_flair_pretrain/brats_vanilla_from_qin_freeze2/best.pt

Output: runs/cka_before_after_0608.json + a printed table.
"""
from __future__ import annotations
import json
import os
import sys

# Importing affinity needs the project's code dir on PYTHONPATH.
THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

import numpy as np  # noqa: E402

from affinity import (  # noqa: E402
    before_after_cka, DatasetSpec, list_cases,
    _extract_layer_ladder_features, linear_cka,
)

REPO = os.path.dirname(THIS)
N_PROBES = 40  # QIN max is 46; matching n between directions keeps the small-n
               # CKA-inflation factor comparable across rows of the table

F_S_BRATS = os.path.join(REPO, 'code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt')
F_S_QIN   = os.path.join(REPO, 'code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_v6_rot200/best.pt')

BR_TO_QIN = {
    'full':    'code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_from_brats_v1/best.pt',
    'freeze1': 'code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_from_brats_freeze1/best.pt',
    'freeze2': 'code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_from_brats_freeze2/best.pt',
}
QIN_TO_BR = {
    'full':    'code/pretrained/brats_flair_pretrain/brats_vanilla_from_qin_v1/best.pt',
    'freeze1': 'code/pretrained/brats_flair_pretrain/brats_vanilla_from_qin_freeze1/best.pt',
    'freeze2': 'code/pretrained/brats_flair_pretrain/brats_vanilla_from_qin_freeze2/best.pt',
}


def _gather_probes(layout: str, root: str, n: int) -> list[str]:
    spec = DatasetSpec(name='probe', root=root, layout=layout)
    cases = list_cases(spec)
    if len(cases) < 1:
        raise FileNotFoundError(f'no probes under {root} (layout={layout})')
    rng = np.random.default_rng(42)
    idx = rng.permutation(len(cases))[:n]
    return [cases[i]['image'] for i in sorted(idx.tolist())]


def main():
    out_path = os.path.join(REPO, 'runs/cka_before_after_0608.json')
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    qin_probes = _gather_probes('qin', os.path.join(REPO, 'data/qin_lung_ct'), N_PROBES)
    brats_probes = _gather_probes(
        'brats_flair', os.path.join(REPO, 'data/BraTS2021_Training'), N_PROBES,
    )
    print(f'[probes] {len(qin_probes)} QIN, {len(brats_probes)} BraTS')

    results = {'BraTS_to_QIN': {}, 'QIN_to_BraTS': {}}

    # All BraTS encoders in this study are FLAIR-only single-channel
    # (parent dir is brats_flair_pretrain/), and QIN is single-channel CT.
    # Both directions: (in=1, out=1) on every checkpoint.
    print('\n=== Direction 1: S=BraTS, T=QIN ===')
    # Random-init noise floor: CKA(f_S, f_rand) per layer on QIN probes.
    print('\n--- noise-floor: CKA(f_S, f_random_init) ---')
    feats_s_qin = _extract_layer_ladder_features(
        ckpt_path=F_S_BRATS, probe_paths=qin_probes,
        in_channels=1, out_channels=1, layout='qin',
    )
    feats_rand_qin = _extract_layer_ladder_features(
        ckpt_path=None, probe_paths=qin_probes,
        in_channels=1, out_channels=1, layout='qin',
    )
    results['BraTS_to_QIN']['noise_floor'] = {
        name: {'cka': linear_cka(feats_s_qin[name], feats_rand_qin[name]),
               'd_features': int(feats_s_qin[name].shape[1]),
               'n_probes': int(feats_s_qin[name].shape[0])}
        for name in feats_s_qin
    }
    for fk, ck in BR_TO_QIN.items():
        print(f'\n--- f_{{S->T,{fk}}} ---')
        results['BraTS_to_QIN'][fk] = before_after_cka(
            f_s_ckpt=F_S_BRATS, f_s_in=1, f_s_out=1,
            f_t_ckpt=os.path.join(REPO, ck), f_t_in=1, f_t_out=1,
            probe_paths=qin_probes, probe_layout='qin',
        )

    print('\n=== Direction 2: S=QIN, T=BraTS ===')
    print('\n--- noise-floor: CKA(f_S, f_random_init) ---')
    feats_s_br = _extract_layer_ladder_features(
        ckpt_path=F_S_QIN, probe_paths=brats_probes,
        in_channels=1, out_channels=1, layout='brats_flair',
    )
    feats_rand_br = _extract_layer_ladder_features(
        ckpt_path=None, probe_paths=brats_probes,
        in_channels=1, out_channels=1, layout='brats_flair',
    )
    results['QIN_to_BraTS']['noise_floor'] = {
        name: {'cka': linear_cka(feats_s_br[name], feats_rand_br[name]),
               'd_features': int(feats_s_br[name].shape[1]),
               'n_probes': int(feats_s_br[name].shape[0])}
        for name in feats_s_br
    }
    for fk, ck in QIN_TO_BR.items():
        print(f'\n--- f_{{S->T,{fk}}} ---')
        results['QIN_to_BraTS'][fk] = before_after_cka(
            f_s_ckpt=F_S_QIN, f_s_in=1, f_s_out=1,
            f_t_ckpt=os.path.join(REPO, ck), f_t_in=1, f_t_out=1,
            probe_paths=brats_probes, probe_layout='brats_flair',
        )

    with open(out_path, 'w') as f:
        json.dump({
            'n_probes': N_PROBES,
            'f_s_brats': F_S_BRATS, 'f_s_qin': F_S_QIN,
            'BraTS_to_QIN_pairs': BR_TO_QIN, 'QIN_to_BraTS_pairs': QIN_TO_BR,
            'qin_probes': qin_probes, 'brats_probes': brats_probes,
            'results': results,
        }, f, indent=2)
    print(f'\n[saved] {out_path}')

    layers = ['L0_stem', 'L1_down', 'L2_down', 'L3_down', 'L4_bottleneck']
    for direction in results:
        # Put noise_floor column first so it's visible as the floor.
        cols = ['noise_floor'] + [c for c in results[direction] if c != 'noise_floor']
        print(f'\n=== {direction}: linear CKA per layer (n={N_PROBES}) ===')
        print(f'{"layer":18}', *[f'{fk:>12}' for fk in cols])
        for L in layers:
            row = [results[direction][fk][L]['cka'] for fk in cols]
            print(f'{L:18}', *[f'{v:>12.3f}' for v in row])
        print('   (noise_floor = CKA(f_S, random_init); other cols = '
              'CKA(f_S, f_{S->T,*}). Higher = more representation preserved.)')


if __name__ == '__main__':
    main()
