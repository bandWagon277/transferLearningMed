"""Before-vs-after fine-tune CKA on BraTS<->MSD transfer pairs.

Same scheme as run_cka_brats_qin_0608.py but the target task is MSD Task06
Lung instead of QIN. Six pairs:

  Direction 1: S=BraTS, T=MSD  (probes = MSD val cases)
    f_S          = brats_flair_pretrain/brats_vanilla_v1/best.pt
    f_{S->T,full}    = oktaykurt_retrain/msd_from_brats_v1/best.pt
    f_{S->T,freeze1} = oktaykurt_retrain/msd_from_brats_freeze1/best.pt
    f_{S->T,freeze2} = oktaykurt_retrain/msd_from_brats_freeze2/best.pt

  Direction 2: S=MSD, T=BraTS  (probes = BraTS val cases)
    f_S          = oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt
    f_{S->T,full}    = brats_flair_pretrain/brats_from_msd_v1/best.pt
    f_{S->T,freeze1} = brats_flair_pretrain/brats_from_msd_freeze1/best.pt
    f_{S->T,freeze2} = brats_flair_pretrain/brats_from_msd_freeze2/best.pt

Output: runs/cka_before_after_msd_0608.json + a printed table.
"""
from __future__ import annotations
import json
import os
import sys

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

import numpy as np  # noqa: E402

from affinity import (  # noqa: E402
    before_after_cka, DatasetSpec, list_cases,
    _extract_layer_ladder_features, linear_cka,
)

REPO = os.path.dirname(THIS)
N_PROBES = 40  # match the QIN run for cross-experiment comparability

F_S_BRATS = os.path.join(REPO, 'code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt')
F_S_MSD   = os.path.join(REPO, 'code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt')

BR_TO_MSD = {
    'full':    'code/pretrained/oktaykurt_retrain/msd_from_brats_v1/best.pt',
    'freeze1': 'code/pretrained/oktaykurt_retrain/msd_from_brats_freeze1/best.pt',
    'freeze2': 'code/pretrained/oktaykurt_retrain/msd_from_brats_freeze2/best.pt',
}
MSD_TO_BR = {
    'full':    'code/pretrained/brats_flair_pretrain/brats_from_msd_v1/best.pt',
    'freeze1': 'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze1/best.pt',
    'freeze2': 'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze2/best.pt',
}


def _gather_probes(layout: str, root: str, n: int) -> list[str]:
    spec = DatasetSpec(name='probe', root=root, layout=layout)
    cases = list_cases(spec)
    if len(cases) < 1:
        raise FileNotFoundError(f'no probes under {root} (layout={layout})')
    rng = np.random.default_rng(42)
    idx = rng.permutation(len(cases))[:n]
    return [cases[i]['image'] for i in sorted(idx.tolist())]


def main():
    out_path = os.path.join(REPO, 'runs/cka_before_after_msd_0608.json')
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    msd_probes = _gather_probes(
        'msd', os.path.join(REPO, 'data/MSD_Task06_Lung/Task06_Lung'), N_PROBES,
    )
    brats_probes = _gather_probes(
        'brats_flair', os.path.join(REPO, 'data/BraTS2021_Training'), N_PROBES,
    )
    print(f'[probes] {len(msd_probes)} MSD, {len(brats_probes)} BraTS')

    results = {'BraTS_to_MSD': {}, 'MSD_to_BraTS': {}}

    print('\n=== Direction 1: S=BraTS, T=MSD ===')
    print('\n--- noise-floor: CKA(f_S, f_random_init) ---')
    feats_s_msd = _extract_layer_ladder_features(
        ckpt_path=F_S_BRATS, probe_paths=msd_probes,
        in_channels=1, out_channels=1, layout='msd',
    )
    feats_rand_msd = _extract_layer_ladder_features(
        ckpt_path=None, probe_paths=msd_probes,
        in_channels=1, out_channels=1, layout='msd',
    )
    results['BraTS_to_MSD']['noise_floor'] = {
        name: {'cka': linear_cka(feats_s_msd[name], feats_rand_msd[name]),
               'd_features': int(feats_s_msd[name].shape[1]),
               'n_probes': int(feats_s_msd[name].shape[0])}
        for name in feats_s_msd
    }
    for fk, ck in BR_TO_MSD.items():
        print(f'\n--- f_{{S->T,{fk}}} ---')
        results['BraTS_to_MSD'][fk] = before_after_cka(
            f_s_ckpt=F_S_BRATS, f_s_in=1, f_s_out=1,
            f_t_ckpt=os.path.join(REPO, ck), f_t_in=1, f_t_out=1,
            probe_paths=msd_probes, probe_layout='msd',
        )

    print('\n=== Direction 2: S=MSD, T=BraTS ===')
    print('\n--- noise-floor: CKA(f_S, f_random_init) ---')
    feats_s_br = _extract_layer_ladder_features(
        ckpt_path=F_S_MSD, probe_paths=brats_probes,
        in_channels=1, out_channels=1, layout='brats_flair',
    )
    feats_rand_br = _extract_layer_ladder_features(
        ckpt_path=None, probe_paths=brats_probes,
        in_channels=1, out_channels=1, layout='brats_flair',
    )
    results['MSD_to_BraTS']['noise_floor'] = {
        name: {'cka': linear_cka(feats_s_br[name], feats_rand_br[name]),
               'd_features': int(feats_s_br[name].shape[1]),
               'n_probes': int(feats_s_br[name].shape[0])}
        for name in feats_s_br
    }
    for fk, ck in MSD_TO_BR.items():
        print(f'\n--- f_{{S->T,{fk}}} ---')
        results['MSD_to_BraTS'][fk] = before_after_cka(
            f_s_ckpt=F_S_MSD, f_s_in=1, f_s_out=1,
            f_t_ckpt=os.path.join(REPO, ck), f_t_in=1, f_t_out=1,
            probe_paths=brats_probes, probe_layout='brats_flair',
        )

    with open(out_path, 'w') as f:
        json.dump({
            'n_probes': N_PROBES,
            'f_s_brats': F_S_BRATS, 'f_s_msd': F_S_MSD,
            'BraTS_to_MSD_pairs': BR_TO_MSD, 'MSD_to_BraTS_pairs': MSD_TO_BR,
            'msd_probes': msd_probes, 'brats_probes': brats_probes,
            'results': results,
        }, f, indent=2)
    print(f'\n[saved] {out_path}')

    layers = ['L0_stem', 'L1_down', 'L2_down', 'L3_down', 'L4_bottleneck']
    for direction in results:
        cols = ['noise_floor'] + [c for c in results[direction] if c != 'noise_floor']
        print(f'\n=== {direction}: linear CKA per layer (n={N_PROBES}) ===')
        print(f'{"layer":18}', *[f'{fk:>12}' for fk in cols])
        for L in layers:
            row = [results[direction][fk][L]['cka'] for fk in cols]
            print(f'{L:18}', *[f'{v:>12.3f}' for v in row])


if __name__ == '__main__':
    main()
