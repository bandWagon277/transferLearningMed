"""Stage MSD-Lung raw NIfTIs into the nnU-Net Task006_Lung layout.

The Medical Segmentation Decathlon distributes MSD Task06 Lung as NIfTI
already (no DICOM step). The only 'conversion' is filename tagging: an
nnU-Net task expects imagesTr/<case>_0000.nii.gz per channel, while the MSD
tarball ships imagesTr/<case>.nii.gz (single channel). We add the '_0000'
suffix on the image side; labels stay as <case>.nii.gz.

    python scripts/msd_lung_stage.py            # stage all 63 training cases
    python scripts/msd_lung_stage.py --dry-run  # print what would be done

Requires no extra packages; only os + shutil.
"""
from __future__ import annotations
import argparse, json, os, shutil, sys

REPO = "/nfs/turbo/jiankanggroup/gengyh/transferMRI"
SRC  = f"{REPO}/data/MSD_Task06_Lung/Task06_Lung"
DST  = f"{REPO}/data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data/Task006_Lung"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--use-symlink", action="store_true",
                    help="symlink instead of copy (saves disk, but breaks if src moves)")
    args = ap.parse_args()

    if not os.path.isdir(SRC):
        sys.exit(f"MSD raw dir not found: {SRC}. Download from "
                 "http://medicaldecathlon.com/  (Task06_Lung.tar).")

    os.makedirs(f"{DST}/imagesTr", exist_ok=True)
    os.makedirs(f"{DST}/labelsTr", exist_ok=True)

    entries = []
    for fname in sorted(os.listdir(f"{SRC}/imagesTr")):
        if not fname.endswith(".nii.gz"): continue
        cid = fname[:-7]  # drop .nii.gz
        src_img = f"{SRC}/imagesTr/{fname}"
        src_lab = f"{SRC}/labelsTr/{fname}"     # MSD uses same filename for label
        dst_img = f"{DST}/imagesTr/{cid}_0000.nii.gz"
        dst_lab = f"{DST}/labelsTr/{cid}.nii.gz"
        if not os.path.exists(src_lab):
            print(f"[skip] {cid}: no label"); continue

        if args.dry_run:
            print(f"  {src_img} -> {dst_img}")
            print(f"  {src_lab} -> {dst_lab}")
        else:
            for src, dst in [(src_img, dst_img), (src_lab, dst_lab)]:
                if os.path.exists(dst): continue
                if args.use_symlink:
                    os.symlink(src, dst)
                else:
                    shutil.copy2(src, dst)
        entries.append({"image": f"./imagesTr/{cid}_0000.nii.gz",
                        "label": f"./labelsTr/{cid}.nii.gz"})

    if not args.dry_run:
        ds_json = {
            "name": "Lung",
            "description": "MSD Task06 Lung (single-channel CT, binary tumor)",
            "reference": "http://medicaldecathlon.com/",
            "licence": "CC-BY-SA 4.0",
            "tensorImageSize": "3D",
            "modality": {"0": "CT"},
            "labels": {"0": "background", "1": "cancer"},
            "numTraining": len(entries),
            "numTest": 0,
            "training": entries,
            "test": [],
        }
        with open(f"{DST}/dataset.json", "w") as fh:
            json.dump(ds_json, fh, indent=1)
        print(f"staged {len(entries)} cases into {DST}")
    else:
        print(f"[dry-run] would stage {len(entries)} cases")


if __name__ == "__main__":
    main()
