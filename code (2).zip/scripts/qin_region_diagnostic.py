"""Item-4 of meetplan0605: QIN outlier diagnostic.

Two-part probe of WHY `qin->resnet50` is the only negative-gap pair in
`scratch/jon_method_all_pairs_0603.json`:

  Part A (static, no GPU)
    Audit `data/qin_lung_ct/filter_stats.json` — the smoking gun is that
    36 of 46 QIN training cases ship a *whole-lung* mask (millions of dark
    voxels, HU median ≈ −850), while only 10 ship a tumor mask (~10K voxels,
    HU median ≈ +30). The current QIN encoder
    (`code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_kfold/fold0/`)
    was trained on the full 46-case mix, so most of its gradient went to
    "predict the dark lung air-space," not "predict the bright tumor blob."
    That fully explains the negative cos-gap with brain-MR encoders, which
    all segment bright FLAIR lesions.

  Part B (GPU)
    For each encoder × probe pair, run the probe through the encoder under
    three intensity masks of the input:
        all     — whole image (matches `compute_jon_method_pairs.py`)
        bright  — only the top 30% percentile voxels (per-volume)
        dark    — only the bottom 30% percentile voxels
    Compute cosine-gap between encoder pairs on each masking condition.
    If QIN agrees with MSD/BraTS on "dark-only" inputs but disagrees on
    "bright-only" inputs, that confirms QIN learned a dark-region detector
    instead of a tumor detector. Output:
        scratch/qin_region_cos_gap_0605.json
        runs/figures/qin_region_cos_gap.png

Run order:
    # Part A only — instant
    python code/qin_region_diagnostic.py --audit-only

    # Part A + B — submit via SLURM
    sbatch code/sbatch_qin_region_diagnostic.slurm
"""
from __future__ import annotations
import argparse, json, os, sys, time
from collections import defaultdict

import numpy as np

sys.path.insert(0, 'code')


REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
FILTER_JSON = f'{REPO}/data/qin_lung_ct/filter_stats.json'
PROBE_JSON  = f'{REPO}/scratch/latent_sim_brats_qin_0531.json'
OUT_AUDIT   = f'{REPO}/scratch/qin_train_audit_0605.json'
OUT_REGION  = f'{REPO}/scratch/qin_region_cos_gap_0605.json'
FIG_LABEL   = f'{REPO}/runs/figures/qin_train_label_distribution.png'
FIG_REGION  = f'{REPO}/runs/figures/qin_region_cos_gap.png'


# ---------------------------------------------------------------------------
# Part A — static training-label audit
# ---------------------------------------------------------------------------

def audit_training_labels() -> dict:
    """Summarize what the QIN encoder actually saw during training."""
    with open(FILTER_JSON) as f:
        fs = json.load(f)
    rows = fs['cases']
    tumor = [r for r in rows if r['is_tumor']]
    whole = [r for r in rows if not r['is_tumor']]

    def stats(name, rs, key):
        vals = [r[key] for r in rs]
        if not vals:
            return {f'{key}_n': 0}
        return {
            f'{key}_n':      len(vals),
            f'{key}_min':    float(np.min(vals)),
            f'{key}_max':    float(np.max(vals)),
            f'{key}_median': float(np.median(vals)),
            f'{key}_mean':   float(np.mean(vals)),
        }

    audit = {
        'n_total':       len(rows),
        'n_tumor_label': len(tumor),
        'n_whole_lung_label': len(whole),
        'whole_lung_fraction': len(whole) / max(1, len(rows)),
        'tumor': {
            **stats('tumor', tumor, 'mask_vox'),
            **stats('tumor', tumor, 'mask_HU_median'),
            **stats('tumor', tumor, 'dark_in_mask_frac'),
        },
        'whole_lung': {
            **stats('whole_lung', whole, 'mask_vox'),
            **stats('whole_lung', whole, 'mask_HU_median'),
            **stats('whole_lung', whole, 'dark_in_mask_frac'),
        },
        'tumor_case_ids':       [r['patient_id'] for r in tumor],
        'whole_lung_case_ids':  [r['patient_id'] for r in whole],
    }
    os.makedirs(os.path.dirname(OUT_AUDIT), exist_ok=True)
    with open(OUT_AUDIT, 'w') as f:
        json.dump(audit, f, indent=2)
    print(f'[audit] saved -> {OUT_AUDIT}')
    return audit


def render_label_distribution_figure(audit: dict) -> None:
    """Two-panel figure: (left) mask-volume histogram by label type;
    (right) mask-median-HU histogram by label type."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    with open(FILTER_JSON) as f:
        fs = json.load(f)
    rows = fs['cases']
    t_vox = [r['mask_vox'] for r in rows if r['is_tumor']]
    w_vox = [r['mask_vox'] for r in rows if not r['is_tumor']]
    t_hu  = [r['mask_HU_median'] for r in rows if r['is_tumor']]
    w_hu  = [r['mask_HU_median'] for r in rows if not r['is_tumor']]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4))
    ax1.hist([np.log10(v) for v in t_vox], bins=12, alpha=0.6,
             label=f'tumor (n={len(t_vox)})', color='C3')
    ax1.hist([np.log10(v) for v in w_vox], bins=12, alpha=0.6,
             label=f'whole-lung (n={len(w_vox)})', color='C0')
    ax1.set_xlabel('log10(mask voxel count)')
    ax1.set_ylabel('cases')
    ax1.set_title('QIN training-label mask size')
    ax1.legend()
    ax2.hist(t_hu, bins=12, alpha=0.6,
             label=f'tumor (n={len(t_hu)})', color='C3')
    ax2.hist(w_hu, bins=12, alpha=0.6,
             label=f'whole-lung (n={len(w_hu)})', color='C0')
    ax2.axvline(0, color='k', linestyle='--', alpha=0.4, label='HU=0')
    ax2.set_xlabel('median HU inside the labeled mask')
    ax2.set_title('QIN training-label intensity')
    ax2.legend()
    plt.tight_layout()
    os.makedirs(os.path.dirname(FIG_LABEL), exist_ok=True)
    plt.savefig(FIG_LABEL, dpi=140)
    plt.close()
    print(f'[fig]   saved -> {FIG_LABEL}')


# ---------------------------------------------------------------------------
# Part B — region-conditional encoder feature comparison
# ---------------------------------------------------------------------------
#
# For each (encoder, probe) we compute three feature vectors:
#   all     — encoder(probe)
#   bright  — encoder(probe * mask_bright); voxels below 70th percentile zeroed
#   dark    — encoder(probe * mask_dark);   voxels above 30th percentile zeroed
# Then for each encoder PAIR and each masking condition we recompute Jon's
# cosine-gap. If QIN→MSD is HIGH on dark-only and LOW on bright-only, that's
# direct evidence the encoder responds to dark regions instead of bright.

def _build_masked_probes(probe_paths: list[str], roi=(128,128,128)):
    """For each probe NIfTI build three (1, 1, *roi) np.float32 arrays."""
    import nibabel as nib
    from affinity import _center_crop_pad

    out = {'all': [], 'bright': [], 'dark': []}
    for p in probe_paths:
        arr = nib.load(p).get_fdata().astype(np.float32)
        if arr.ndim == 4:
            arr = arr[..., 0]
        # FLAIR-style z-score (probes are BraTS FLAIR).
        m = arr > 0
        if m.any():
            arr = (arr - arr[m].mean()) / (arr[m].std() + 1e-6)
        # roi crop/pad
        arr = _center_crop_pad(arr, roi)
        v = arr[arr != 0]
        if v.size == 0:
            out['all'].append(arr)
            out['bright'].append(arr * 0)
            out['dark'].append(arr * 0)
            continue
        p70 = np.percentile(v, 70)
        p30 = np.percentile(v, 30)
        bright = arr.copy()
        bright[bright < p70] = 0
        dark = arr.copy()
        dark[dark > p30] = 0
        out['all'].append(arr)
        out['bright'].append(bright)
        out['dark'].append(dark)
    return out


def _encode_volume_array(model_state, arr: np.ndarray, in_channels: int,
                          out_channels: int, channels: tuple, device='cuda'):
    """Run a single pre-cropped (D, H, W) array through the encoder and return
    flat bottleneck features."""
    import torch
    from affinity import _build_vanilla_unet, _bottleneck_module
    captured = {}
    model = _build_vanilla_unet(in_channels, out_channels, channels)
    model.load_state_dict(model_state)
    model.eval().to(device)
    def hook(_m, _i, output):
        captured['z'] = output.detach()
    h = _bottleneck_module(model).register_forward_hook(hook)
    with torch.no_grad():
        x = torch.from_numpy(arr).float().unsqueeze(0).unsqueeze(0).to(device)
        if in_channels > 1:
            x = x.repeat(1, in_channels, 1, 1, 1)
        _ = model(x)
        feat = captured['z'].flatten().cpu().numpy()
    h.remove()
    return feat


def _encode_under_mask(ckpt: str, probe_arrays: list[np.ndarray],
                       in_channels: int, out_channels: int,
                       channels=(32, 64, 128, 256, 512), device='cuda'):
    """Cheap variant of affinity._extract_bottleneck_features that accepts
    pre-prepared volume arrays (already z-scored, ROI-cropped, masked)."""
    import torch
    sd = torch.load(ckpt, map_location='cpu', weights_only=False)
    sd = sd.get('state_dict', sd) if isinstance(sd, dict) else sd
    feats = []
    for arr in probe_arrays:
        feats.append(_encode_volume_array(sd, arr, in_channels, out_channels,
                                          channels, device=device))
    return np.stack(feats, axis=0)


def _jon_gap(Za, Zb):
    Za = Za / (np.linalg.norm(Za, axis=1, keepdims=True) + 1e-12)
    Zb = Zb / (np.linalg.norm(Zb, axis=1, keepdims=True) + 1e-12)
    if Za.shape[1] != Zb.shape[1]:
        d = max(Za.shape[1], Zb.shape[1])
        if Za.shape[1] < d: Za = np.pad(Za, ((0,0),(0,d-Za.shape[1])))
        if Zb.shape[1] < d: Zb = np.pad(Zb, ((0,0),(0,d-Zb.shape[1])))
    S = Za @ Zb.T
    diag = np.diag(S)
    off  = (S.sum(axis=1) - diag) / max(1, S.shape[1]-1)
    return {
        'mean_gap':       float((diag - off).mean()),
        'mean_diag_cos':  float(diag.mean()),
        'mean_offdiag_cos': float(off.mean()),
        'n_probes':       int(S.shape[0]),
    }


def region_cos_gap(device='cuda'):
    from sklearn.decomposition import PCA
    probes = json.load(open(PROBE_JSON))['probes']
    encoders = {
        'brats': f'{REPO}/code/pretrained/brats_flair_pretrain/brats_vanilla_kfold/fold0/best.pt',
        'qin':   f'{REPO}/code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_kfold/fold0/best.pt',
        'msd':   f'{REPO}/code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt',
    }
    masks = _build_masked_probes(probes, roi=(128,128,128))

    raw = {}  # raw[mask][encoder] = (N, D)
    for mname, arrs in masks.items():
        raw[mname] = {}
        for ename, ckpt in encoders.items():
            print(f'[encode] mask={mname} encoder={ename}', flush=True)
            t0 = time.time()
            raw[mname][ename] = _encode_under_mask(
                ckpt, arrs, in_channels=1, out_channels=1, device=device)
            print(f'  shape={raw[mname][ename].shape} dt={time.time()-t0:.1f}s',
                  flush=True)

    # PCA-11 per (mask, encoder); compute pairwise gap.
    n_pca = 11
    results = {}
    for mname in raw:
        pca = {}
        for ename, F in raw[mname].items():
            eff = min(n_pca, F.shape[0]-1, F.shape[1])
            pca[ename] = PCA(n_components=eff, random_state=42).fit_transform(F)
        pairs = {}
        for a in encoders:
            for b in encoders:
                if a == b: continue
                pairs[f'{a}->{b}'] = _jon_gap(pca[a], pca[b])
        results[mname] = pairs

    out = {'probes': probes, 'encoders': encoders, 'n_pca': n_pca,
           'masking': {'bright': 'voxels < 70th percentile zeroed (non-zero region only)',
                       'dark':   'voxels > 30th percentile zeroed (non-zero region only)',
                       'all':    'full z-scored volume after ROI crop/pad'},
           'results': results}
    with open(OUT_REGION, 'w') as f:
        json.dump(out, f, indent=2)
    print(f'[region] saved -> {OUT_REGION}')

    # Bar plot
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    pair_names = list(results['all'].keys())
    masks_order = ['all', 'bright', 'dark']
    width = 0.27
    xs = np.arange(len(pair_names))
    fig, ax = plt.subplots(figsize=(11, 4.5))
    colors = {'all': 'k', 'bright': '#d62728', 'dark': '#1f77b4'}
    for i, mname in enumerate(masks_order):
        gaps = [results[mname][p]['mean_gap'] for p in pair_names]
        ax.bar(xs + (i-1)*width, gaps, width,
               label=mname, color=colors[mname], alpha=0.85)
    ax.axhline(0, color='gray', lw=0.7)
    ax.set_xticks(xs)
    ax.set_xticklabels(pair_names, rotation=30, ha='right')
    ax.set_ylabel('mean cos-gap (diag − offdiag)')
    ax.set_title('Encoder cos-gap conditioned on input voxel-intensity region\n'
                 'BraTS FLAIR probes (n=12), PCA-11, bottleneck features')
    ax.legend(title='mask applied to input')
    plt.tight_layout()
    os.makedirs(os.path.dirname(FIG_REGION), exist_ok=True)
    plt.savefig(FIG_REGION, dpi=140)
    plt.close()
    print(f'[fig] saved -> {FIG_REGION}')


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--audit-only', action='store_true',
                   help='Skip Part B (GPU). Just rebuild static audit + figure.')
    p.add_argument('--device', default='cuda')
    args = p.parse_args()

    audit = audit_training_labels()
    render_label_distribution_figure(audit)

    print('\n=== QIN training-label audit ===')
    print(f'  total cases       : {audit["n_total"]}')
    print(f'  tumor labels      : {audit["n_tumor_label"]}')
    print(f'  whole-lung labels : {audit["n_whole_lung_label"]}'
          f' ({audit["whole_lung_fraction"]*100:.1f}% of training data)')
    print(f'  tumor mask vox    : median={audit["tumor"]["mask_vox_median"]:.0f} '
          f'(HU median ≈ {audit["tumor"]["mask_HU_median_median"]:+.0f})')
    print(f'  whole-lung vox    : median={audit["whole_lung"]["mask_vox_median"]:.0f} '
          f'(HU median ≈ {audit["whole_lung"]["mask_HU_median_median"]:+.0f})')

    if args.audit_only:
        print('\n[--audit-only] skipping GPU Part B.')
        return

    region_cos_gap(device=args.device)


if __name__ == '__main__':
    main()
