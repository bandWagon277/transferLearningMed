"""All-pairs cosine similarity for BraTS / QIN / MSD-Lung / ResNet50.

Probes: the 12 BraTS FLAIR volumes from latent_sim_brats_qin_0531.json,
held constant for fair comparison.

Encoders:
  brats     — code/pretrained/brats_flair_pretrain/brats_vanilla_kfold/fold0/best.pt
  qin       — code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_kfold/fold0/best.pt
  msd       — code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt
  resnet50  — torchvision IMAGENET1K_V2 (2D, slice-wise + depth-pool)

Per ordered pair (a -> b):
  - Per-encoder PCA-11 of bottleneck (or 2048-D ResNet50) features.
  - jon_metric: cos diag - mean offdiag, bounded [-2, +2] (Jon 2026-05-30).
  - orthohash_metric: softmax-CE over the cosine matrix S = (Za @ Zb.T)/T
    (Hoe NeurIPS 2021 §3.1–3.2). Returns L_OH = mean negative log-likelihood
    of matching the diagonal vs the row of N distractors, and
    accuracy_at_1 = fraction of probes where argmax_j S[i,j] == i.

Output: scratch/orthohash_all_pairs_0605.json (the earlier
scratch/jon_method_all_pairs_0603.json is preserved on disk for diff).
"""
from __future__ import annotations
import json, sys, time
import numpy as np
import torch
import torch.nn as nn
from sklearn.decomposition import PCA

sys.path.insert(0, 'code')
from affinity import _extract_bottleneck_features, jon_metric, orthohash_metric


def _resnet50_extract(probe_paths: list[str], device: str = 'cuda') -> np.ndarray:
    """2D ResNet50 (IMAGENET1K_V2), slice-wise features then depth-pool.

    Output: [N x 2048] one row per probe volume.
    """
    import torchvision.models as M
    import nibabel as nib
    from scipy.ndimage import zoom
    m = M.resnet50(weights=M.ResNet50_Weights.IMAGENET1K_V2)
    # strip the final FC layer; keep the conv trunk through avgpool.
    trunk = nn.Sequential(*list(m.children())[:-1])  # output [B, 2048, 1, 1]
    trunk.eval().to(device)

    # ImageNet normalization (ResNet50 IMAGENET1K_V2 expects this).
    mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1).to(device)
    std  = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1).to(device)

    feats = []
    with torch.no_grad():
        for p in probe_paths:
            arr = nib.load(p).get_fdata().astype(np.float32)
            if arr.ndim == 4:
                arr = arr[..., 0]
            # FLAIR z-score on non-zero (matches our brats_flair layout).
            mask = arr > 0
            if mask.any():
                arr = (arr - arr[mask].mean()) / (arr[mask].std() + 1e-6)
            # Min-max to [0, 1] for ResNet's RGB convention.
            lo, hi = arr.min(), arr.max()
            arr01 = (arr - lo) / (hi - lo + 1e-6)
            # Slice along last axis (axial). Resize each slice to 224x224.
            Z = arr01.shape[2]
            slices = []
            for k in range(Z):
                sl = arr01[:, :, k]
                # zoom to 224x224
                zy, zx = 224.0 / sl.shape[0], 224.0 / sl.shape[1]
                sl_r = zoom(sl, (zy, zx), order=1)
                slices.append(sl_r)
            stack = np.stack(slices, axis=0)               # (Z, 224, 224)
            x = torch.from_numpy(stack).float().unsqueeze(1).to(device)  # (Z, 1, 224, 224)
            x = x.repeat(1, 3, 1, 1)                       # replicate to 3-channel
            x = (x - mean) / std
            # Forward in batches to avoid OOM on tall stacks.
            chunks = []
            for s in range(0, x.size(0), 32):
                chunks.append(trunk(x[s:s+32]).squeeze(-1).squeeze(-1))   # (B, 2048)
            per_slice = torch.cat(chunks, dim=0).cpu().numpy()  # (Z, 2048)
            # Depth-pool: mean over slices.
            feats.append(per_slice.mean(axis=0))
    return np.stack(feats, axis=0)


def main():
    probes = json.load(open('scratch/latent_sim_brats_qin_0531.json'))['probes']
    medical_encoders = {
        'brats': 'code/pretrained/brats_flair_pretrain/brats_vanilla_kfold/fold0/best.pt',
        'qin':   'code/pretrained/oktaykurt_retrain/lung_vanilla_qinonly_kfold/fold0/best.pt',
        'msd':   'code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt',
    }

    # 1) Extract bottleneck features.
    raw = {}
    for name, ckpt in medical_encoders.items():
        t0 = time.time()
        print(f'[extract] {name}', flush=True)
        raw[name] = _extract_bottleneck_features(
            ckpt_path=ckpt, probe_paths=probes,
            in_channels=1, out_channels=1, channels=(32,64,128,256,512),
            device='cuda', layout='brats_flair')
        print(f'  shape={raw[name].shape}  dt={time.time()-t0:.1f}s', flush=True)
    t0 = time.time()
    print('[extract] resnet50 (2D, slice-wise + depth pool)', flush=True)
    raw['resnet50'] = _resnet50_extract(probes, device='cuda')
    print(f'  shape={raw["resnet50"].shape}  dt={time.time()-t0:.1f}s', flush=True)

    # 2) Per-encoder PCA to common target dim. Use 11 because rank ≤ N-1 = 11.
    n_pca = 11
    pca = {}
    for name, F in raw.items():
        eff = min(n_pca, F.shape[0]-1, F.shape[1])
        pca[name] = PCA(n_components=eff, random_state=42).fit_transform(F)

    # 3) All-pairs Jon-metric AND OrthoHash metric (side by side).
    names = list(raw.keys())
    out = {
        'encoders': dict(medical_encoders, **{'resnet50': 'torchvision IMAGENET1K_V2 (2D, depth-pool)'}),
        'probes': probes, 'n_probes': len(probes), 'n_pca': n_pca,
        'feature_dims_raw': {n: int(raw[n].shape[1]) for n in names},
        'metrics': {
            'jon':       'cos diag - mean offdiag; bounded [-2, +2]',
            'orthohash': 'softmax-CE retrieval loss; L_OH=mean -log P(diag), '
                         'lower is better; random=log(N), perfect→0',
        },
        'pairs': {},
    }
    print('\n=== Jon vs OrthoHash all-pairs (lower L_OH = stronger alignment) ===', flush=True)
    print(f'{"pair":<22}{"jon_gap":>9}{"diag":>8}{"L_OH":>8}{"acc@1":>8}{"log-odds":>10}')
    for a in names:
        for b in names:
            if a == b: continue
            jr = jon_metric(pca[a], pca[b])
            oh = orthohash_metric(pca[a], pca[b])
            out['pairs'][f'{a}->{b}'] = {'jon': jr, 'orthohash': oh}
            print(f'{a}->{b:<19}{jr["mean_gap"]:>9.3f}{jr["mean_diag_cos"]:>8.3f}'
                  f'{oh["L_OH"]:>8.3f}{oh["accuracy_at_1"]:>8.2f}'
                  f'{oh["log_odds_advantage"]:>10.3f}')

    with open('scratch/orthohash_all_pairs_0605.json', 'w') as f:
        json.dump(out, f, indent=2)
    print('\nsaved -> scratch/orthohash_all_pairs_0605.json')


if __name__ == '__main__':
    main()
