"""Convert qin_lung_ct DICOM (IDC download) to MONAI-ready NIfTI.

Output layout under `data/qin_lung_ct/<PatientID>/`:
  - image.nii.gz   — 3D CT volume (HU)
  - label.nii.gz   — 3D tumor mask aligned to image.nii.gz (uint8, 0/1)

DICOM SEG handling: pydicom-seg reads the DICOM SEG file and produces a
SimpleITK image already aligned to the referenced CT series geometry. We
then resample to CT grid if needed.

If a patient has multiple CT or SEG series we pick (a) the largest CT
series by slice count (skip Topograms) and (b) the SEG whose referenced
series matches the chosen CT. If no SEG references the chosen CT, that
patient is skipped and logged.

Run:
  ~/miniconda3/envs/medicaldiffusion/bin/python code/convert_qin_lung_ct.py
"""
from __future__ import annotations
import os, sys, glob
import numpy as np
import SimpleITK as sitk
import pydicom
import pydicom_seg

RAW_ROOT = '/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/qin_lung_ct_raw/qin_lung_ct'
OUT_ROOT = '/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/qin_lung_ct'


def list_ct_series(patient_dir: str) -> list[str]:
    """Return list of CT_<UID> subdirs inside the patient's study dir(s)."""
    return sorted(glob.glob(os.path.join(patient_dir, '*', 'CT_*')))


def list_seg_series(patient_dir: str) -> list[str]:
    return sorted(glob.glob(os.path.join(patient_dir, '*', 'SEG_*')))


def load_ct_volume(ct_dir: str) -> sitk.Image:
    reader = sitk.ImageSeriesReader()
    file_names = reader.GetGDCMSeriesFileNames(ct_dir)
    reader.SetFileNames(file_names)
    return reader.Execute()


def load_seg_for_ct(seg_dir: str, ct_series_uid: str) -> sitk.Image | None:
    """Load a DICOM-SEG that references `ct_series_uid`. Returns None if
    this SEG references a different series.
    """
    seg_files = sorted(glob.glob(os.path.join(seg_dir, '*.dcm')))
    if not seg_files:
        return None
    # DICOM SEG is a single multi-frame file; take the first match
    for sf in seg_files:
        ds = pydicom.dcmread(sf, stop_before_pixels=False)
        # Walk the ReferencedSeriesSequence to find what this SEG refers to
        refs = getattr(ds, 'ReferencedSeriesSequence', None)
        if refs is None:
            continue
        refd_uids = [r.SeriesInstanceUID for r in refs]
        if ct_series_uid in refd_uids:
            seg_reader = pydicom_seg.SegmentReader()
            result = seg_reader.read(ds)
            # `available_segments` is a set; sort for determinism.
            segs = sorted(result.available_segments)
            if not segs:
                continue
            # Union all segments into one binary tumor mask
            mask = None
            for segment_number in segs:
                m = result.segment_image(segment_number)
                arr = sitk.GetArrayFromImage(m)
                mask = arr if mask is None else np.maximum(mask, arr)
            # Build aligned SimpleITK image from the first segment's geometry
            first = result.segment_image(segs[0])
            out = sitk.GetImageFromArray((mask > 0).astype(np.uint8))
            out.CopyInformation(first)
            return out
    return None


def resample_to_reference(moving: sitk.Image, ref: sitk.Image,
                          is_label: bool = False) -> sitk.Image:
    interp = sitk.sitkNearestNeighbor if is_label else sitk.sitkLinear
    out = sitk.Resample(
        moving, ref,
        transform=sitk.Transform(),
        interpolator=interp,
        defaultPixelValue=0,
        outputPixelType=moving.GetPixelID(),
    )
    return out


def pick_ct_series(patient_dir: str) -> str | None:
    """Largest CT series by number of slices, skipping Topograms."""
    ct_series = list_ct_series(patient_dir)
    if not ct_series:
        return None
    best = None
    best_count = -1
    for s in ct_series:
        files = glob.glob(os.path.join(s, '*.dcm'))
        if len(files) < 30:
            # Skip Topograms / scouts which are tiny
            continue
        if len(files) > best_count:
            best = s
            best_count = len(files)
    return best


def ct_series_uid(ct_dir: str) -> str:
    """Read one DICOM from the CT series and return its SeriesInstanceUID."""
    f = glob.glob(os.path.join(ct_dir, '*.dcm'))[0]
    ds = pydicom.dcmread(f, stop_before_pixels=True)
    return ds.SeriesInstanceUID


def convert_patient(patient_id: str, patient_dir: str) -> dict:
    rec = {'patient_id': patient_id, 'status': '', 'note': ''}
    try:
        ct_dir = pick_ct_series(patient_dir)
        if ct_dir is None:
            rec['status'] = 'skip'
            rec['note'] = 'no CT series with >=30 slices'
            return rec
        ct_uid = ct_series_uid(ct_dir)
        ct_img = load_ct_volume(ct_dir)

        seg_dirs = list_seg_series(patient_dir)
        mask = None
        for sd in seg_dirs:
            m = load_seg_for_ct(sd, ct_uid)
            if m is not None:
                mask = m
                break
        if mask is None:
            rec['status'] = 'skip'
            rec['note'] = f'no SEG references CT {ct_uid[:24]}...'
            return rec
        # Resample mask to CT grid (often already there, but be safe).
        mask = resample_to_reference(mask, ct_img, is_label=True)

        out_dir = os.path.join(OUT_ROOT, patient_id)
        os.makedirs(out_dir, exist_ok=True)
        sitk.WriteImage(ct_img, os.path.join(out_dir, 'image.nii.gz'))
        sitk.WriteImage(mask,   os.path.join(out_dir, 'label.nii.gz'))
        ct_shape = ct_img.GetSize()
        rec['status'] = 'ok'
        rec['note']   = f'ct={ct_shape}'
        return rec
    except Exception as e:
        rec['status'] = 'error'
        rec['note']   = f'{type(e).__name__}: {str(e)[:120]}'
        return rec


def main():
    os.makedirs(OUT_ROOT, exist_ok=True)
    patients = sorted([d for d in os.listdir(RAW_ROOT)
                       if os.path.isdir(os.path.join(RAW_ROOT, d))])
    print(f'[info] {len(patients)} patients found in {RAW_ROOT}')

    n_ok = n_skip = n_err = 0
    rows = []
    for pid in patients:
        rec = convert_patient(pid, os.path.join(RAW_ROOT, pid))
        rows.append(rec)
        print(f'  {pid}: {rec["status"]} {rec["note"]}', flush=True)
        if rec['status'] == 'ok':
            n_ok += 1
        elif rec['status'] == 'skip':
            n_skip += 1
        else:
            n_err += 1

    print(f'\n[done] ok={n_ok} skip={n_skip} error={n_err} of {len(patients)}')

    # Manifest
    with open(os.path.join(OUT_ROOT, 'manifest.csv'), 'w') as f:
        f.write('patient_id,status,note\n')
        for r in rows:
            note = r['note'].replace(',', ';')
            f.write(f'{r["patient_id"]},{r["status"]},{note}\n')
    print(f'[manifest] {OUT_ROOT}/manifest.csv')


if __name__ == '__main__':
    main()
