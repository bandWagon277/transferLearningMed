"""Sweep CKA against probe count, for InstanceNorm vs BatchNorm × RI vs Scratch.

Tests the hypothesis that:
  - InstanceNorm 3D U-Net: RI-RI CKA ~= 1 (architectural floor, JL-style preservation
    of input pairwise structure under random conv + per-sample normalization).
  - BatchNorm 3D U-Net: RI-RI CKA decreases because BN's batch-statistics injection
    breaks the perfect-Gram-matrix-multiple structure between two random nets.

Four conditions:
  IN  RI-RI       — seed 0 vs seed 1, random-init, InstanceNorm
  IN  scratch-sc  — seed 0 vs seed 1, trained scratch, InstanceNorm  (existing ckpts)
  BN  RI-RI       — seed 0 vs seed 1, random-init, BatchNorm
  BN  scratch-sc  — seed 0 vs seed 1, trained scratch, BatchNorm     (needs ckpts)

For each probe size n in [40, 100, 200, 500, 1000], we compute CKA per layer on the
first n BraTS-FLAIR probes (deterministic random subset, fixed seed). Output:

  runs/cka_norm_probesize_0617.json
  runs/figures/0617/cka_norm_probesize.png

The figure is 7 panels (one per layer), each showing 4 curves vs probe size.
"""
from __future__ import annotations
import argparse
import glob
import json
import os
import sys

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

import numpy as np
import nibabel as nib
import torch

from affinity import (
    DatasetSpec, list_cases, _full_ladder_modules, _center_crop_pad,
)


REPO = os.path.dirname(THIS)
ROI = (128, 128, 128)
PROBE_SIZES = [40, 100, 200, 500, 1000]
LAYOUT = 'brats_flair'
PROBE_ROOT = os.path.join(REPO, 'data/BraTS2021_Training')

# Existing K=5 IN scratch ckpts (task #91); BN scratch ckpts written by
# new training jobs (this script tolerates missing files).
IN_SCRATCH = [
    os.path.join(REPO, f'code/pretrained/brats_flair_pretrain/brats_vanilla_seed{i}/best.pt')
    for i in (0, 1)
]
BN_SCRATCH = [
    os.path.join(REPO, f'code/pretrained/brats_flair_pretrain/brats_vanilla_bn_seed{i}/best.pt')
    for i in (0, 1)
]


def build_unet(norm: str):
    """Build the same 3D U-Net topology as the K-fold pretrain; switch norm."""
    from monai.networks.nets import UNet as MonaiUNet
    n = 'BATCH' if norm.lower() == 'bn' else 'INSTANCE'
    return MonaiUNet(spatial_dims=3, in_channels=1, out_channels=1,
                     channels=(32, 64, 128, 256, 512),
                     strides=(2, 2, 2, 2), num_res_units=0, norm=n)


def init_random(model, seed: int):
    """Kaiming-normal on conv weights; standard defaults on norm γ/β.

    Bug fix (2026-06-18): previously we zeroed all 1-D params, which set
    BatchNorm γ = 0 and made the model output identically zero (BN-out =
    0·(x−μ)/√σ² + 0). Fixed by initializing norm γ to 1, β to 0 (PyTorch
    defaults) and only zeroing actual biases. For InstanceNorm(affine=False)
    there are no learnable params so this is a no-op.
    """
    torch.manual_seed(int(seed))
    # First initialize conv weights.
    for p in model.parameters():
        if p.ndim > 1:
            torch.nn.init.kaiming_normal_(p)
    # Then walk modules to set norm γ/β + bias properly per-module-type.
    for m in model.modules():
        if isinstance(m, (torch.nn.BatchNorm3d, torch.nn.BatchNorm2d, torch.nn.BatchNorm1d,
                          torch.nn.InstanceNorm3d, torch.nn.InstanceNorm2d, torch.nn.InstanceNorm1d,
                          torch.nn.LayerNorm, torch.nn.GroupNorm)):
            if getattr(m, 'weight', None) is not None:
                torch.nn.init.ones_(m.weight)
            if getattr(m, 'bias', None) is not None:
                torch.nn.init.zeros_(m.bias)
        elif isinstance(m, (torch.nn.Conv3d, torch.nn.Conv2d, torch.nn.Conv1d,
                            torch.nn.Linear)):
            if getattr(m, 'bias', None) is not None:
                torch.nn.init.zeros_(m.bias)


def linear_cka_gram(X: np.ndarray, Y: np.ndarray) -> float:
    """Full-spatial Gram-form linear CKA (matches RistoAle97 reference)."""
    n = X.shape[0]
    H = np.eye(n) - np.ones((n, n)) / n
    Kx = X @ X.T
    Ky = Y @ Y.T
    Kxc = H @ Kx @ H
    Kyc = H @ Ky @ H
    num = float((Kxc * Kyc).sum())
    den = float(np.sqrt((Kxc * Kxc).sum() * (Kyc * Kyc).sum()) + 1e-12)
    return num / den


def gather_features(model, probe_paths, device, batch_print=False):
    """Per-layer GAP-pooled features, shape (n_probes, C).

    Full-spatial features blow up memory at n=1000 (L0 ~250 GB). The
    earlier sanity test (sanity_cka_gap_vs_spatial_0616.py) showed GAP and
    full-spatial give qualitatively the same RI-RI conclusion, so GAP is
    safe for the probe-count sweep.
    """
    layer_modules = _full_ladder_modules(model)
    gap_buf = {name: [] for name in layer_modules}
    captured = {}

    def make_hook(name):
        def _h(_m, _i, out): captured[name] = out.detach()
        return _h

    handles = [m.register_forward_hook(make_hook(n))
               for n, m in layer_modules.items()]
    model.eval().to(device)

    with torch.no_grad():
        for i, p in enumerate(probe_paths):
            arr = nib.load(p).get_fdata().astype(np.float32)
            if arr.ndim == 4:
                arr = arr[..., 0]
            mask = arr > 0
            if mask.any():
                arr = (arr - arr[mask].mean()) / (arr[mask].std() + 1e-6)
            arr = _center_crop_pad(arr, ROI)
            x = torch.from_numpy(arr).float().unsqueeze(0).unsqueeze(0).to(device)
            _ = model(x)
            for name in layer_modules:
                out = captured[name]  # (1, C, H, W, D)
                gap = out.mean(dim=tuple(range(2, out.ndim))).squeeze(0)
                gap_buf[name].append(gap.cpu().numpy().astype(np.float32))
            if batch_print and (i+1) % 200 == 0:
                print(f'    probe {i+1}/{len(probe_paths)}')
    for h in handles:
        h.remove()
    return {n: np.stack(arrs, axis=0) for n, arrs in gap_buf.items()}


def load_ckpt(model, ckpt_path):
    sd = torch.load(ckpt_path, map_location='cpu', weights_only=False)
    sd = sd.get('state_dict', sd) if isinstance(sd, dict) else sd
    model.load_state_dict(sd, strict=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--max-probes', type=int, default=1000,
                    help='Largest probe count to sweep. Default 1000.')
    ap.add_argument('--probe-sizes', default='40,100,200,500,1000',
                    help='Comma-separated probe sizes.')
    ap.add_argument('--seed', type=int, default=42)
    args = ap.parse_args()

    probe_sizes = [int(x) for x in args.probe_sizes.split(',')]
    max_n = max(probe_sizes)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f'[device] {device}')

    # Pick the largest set of BraTS-FLAIR probes once; sweep prefixes.
    spec = DatasetSpec(name='probe', root=PROBE_ROOT, layout=LAYOUT)
    cases = list_cases(spec)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(len(cases))[:max_n]
    probes_all = [cases[i]['image'] for i in sorted(idx.tolist())]
    print(f'[probes] enumerated {len(probes_all)} BraTS-FLAIR images '
          f'(max-n={max_n} from cohort of {len(cases)})')

    # Build feature caches for each of the 4 model variants.
    cache = {}  # (norm, init, seed) -> dict[layer] -> (max_n, feat_dim)
    for norm in ('IN', 'BN'):
        for init, seeds, ckpts in [
            ('RI', (0, 1), [None, None]),
            ('scratch', (0, 1), IN_SCRATCH if norm == 'IN' else BN_SCRATCH),
        ]:
            for seed, ckpt in zip(seeds, ckpts):
                tag = (norm, init, seed)
                if ckpt is not None and not os.path.isfile(ckpt):
                    print(f'  [skip] {tag}: no ckpt at {ckpt}')
                    continue
                print(f'[extract] norm={norm} init={init} seed={seed} ckpt={ckpt!s:<60}')
                m = build_unet(norm.lower())
                if ckpt is None:
                    init_random(m, seed)
                else:
                    load_ckpt(m, ckpt)
                cache[tag] = gather_features(m, probes_all, device,
                                             batch_print=(max_n >= 500))
                del m
                if device == 'cuda':
                    torch.cuda.empty_cache()

    # For each layer, compute CKA at each probe size for each of the 4 lines.
    LINES = [
        ('IN_RI_RI',          ('IN', 'RI', 0),      ('IN', 'RI', 1)),
        ('IN_scratch_scratch',('IN', 'scratch', 0), ('IN', 'scratch', 1)),
        ('BN_RI_RI',          ('BN', 'RI', 0),      ('BN', 'RI', 1)),
        ('BN_scratch_scratch',('BN', 'scratch', 0), ('BN', 'scratch', 1)),
    ]

    layers = list(next(iter(cache.values())).keys())
    results = {line: {L: {} for L in layers} for line, _, _ in LINES}

    for line, ka, kb in LINES:
        if ka not in cache or kb not in cache:
            print(f'[skip-line] {line}: missing feature cache')
            continue
        for L in layers:
            for n in probe_sizes:
                X = cache[ka][L][:n]
                Y = cache[kb][L][:n]
                results[line][L][n] = linear_cka_gram(X, Y)

    out_json = os.path.join(REPO, 'runs/cka_norm_probesize_0617.json')
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    with open(out_json, 'w') as f:
        json.dump({'probe_sizes': probe_sizes, 'layers': layers,
                   'lines': {ln: {L: results[ln][L] for L in layers}
                             for ln, _, _ in LINES}}, f, indent=2)
    print(f'[saved] {out_json}')

    # Plot 7 panels.
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print('[plot] matplotlib not available; JSON saved')
        return

    fig, axes = plt.subplots(2, 4, figsize=(16, 8), sharex=True, sharey=True)
    axes = axes.flatten()
    colors = {'IN_RI_RI': '#4C78A8', 'IN_scratch_scratch': '#54A24B',
              'BN_RI_RI': '#E45756', 'BN_scratch_scratch': '#B279A2'}
    for ax, L in zip(axes, layers):
        for line, _, _ in LINES:
            if not results[line][L]:
                continue
            xs = sorted(results[line][L].keys())
            ys = [results[line][L][x] for x in xs]
            ax.plot(xs, ys, marker='o', label=line, color=colors[line])
        ax.set_xscale('log')
        ax.set_title(L)
        ax.set_ylim(-0.05, 1.05)
        ax.grid(alpha=0.3)
    for ax in axes[-4:]:
        ax.set_xlabel('# probes (log)')
    for ax in axes[::4]:
        ax.set_ylabel('linear CKA')
    axes[0].legend(loc='lower right', fontsize='small')
    fig.suptitle('3D U-Net CKA vs probe count: IN/BN × RI/scratch')
    fig.tight_layout()
    fig_path = os.path.join(REPO, 'runs/figures/0617/cka_norm_probesize.png')
    os.makedirs(os.path.dirname(fig_path), exist_ok=True)
    fig.savefig(fig_path, dpi=130, bbox_inches='tight')
    print(f'[saved] {fig_path}')


if __name__ == '__main__':
    main()
