"""Dataset sample panels for the deliverable.

For each dataset used in this project (BraTS 2021 FLAIR-binary, BraTS 2024
GLI Post-Treatment clean cohort, MSD Task06 Lung, QIN Lung CT), render a
small montage showing the input volume and the ground-truth tumor mask at
the tumor centroid in three orthogonal planes.

The figures are written to deliverable/figures/visualizations/dataset_samples/.

No GPU is required; the script only loads NIfTIs.
"""
from __future__ import annotations

import os
import sys
import glob
import re
import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import nibabel as nib

REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
OUT = os.path.join(REPO, 'deliverable/figures/visualizations/dataset_samples')
os.makedirs(OUT, exist_ok=True)


def tumor_centroid(mask: np.ndarray):
    coords = np.argwhere(mask > 0)
    if len(coords) == 0:
        return tuple(s // 2 for s in mask.shape)
    return tuple(int(c) for c in coords.mean(axis=0))


def make_overlay_rgba(mask: np.ndarray, color=(0.0, 0.85, 0.0), alpha=0.55):
    h, w = mask.shape
    rgba = np.zeros((h, w, 4), dtype=np.float32)
    sel = mask > 0
    rgba[sel] = [*color, alpha]
    return rgba


def render_one(image_path: str, label_path: str, title: str, out_path: str,
               ct_window=None):
    img = nib.load(image_path).get_fdata().astype(np.float32)
    msk = nib.load(label_path).get_fdata()
    msk_bin = (msk > 0).astype(np.uint8)

    img_zyx = np.transpose(img, (2, 1, 0))
    msk_zyx = np.transpose(msk_bin, (2, 1, 0))
    z, y, x = tumor_centroid(msk_zyx)

    if ct_window is not None:
        lo, hi = ct_window
        img_zyx = np.clip(img_zyx, lo, hi)
    lo_p, hi_p = np.percentile(img_zyx, (1, 99))

    fig, axes = plt.subplots(2, 3, figsize=(10, 6.4))
    plane_specs = [
        ('axial',    z, img_zyx[z, :, :], msk_zyx[z, :, :]),
        ('coronal',  y, img_zyx[:, y, :], msk_zyx[:, y, :]),
        ('sagittal', x, img_zyx[:, :, x], msk_zyx[:, :, x]),
    ]
    for c, (plane, idx, im_slice, m_slice) in enumerate(plane_specs):
        axes[0, c].imshow(im_slice, cmap='gray', vmin=lo_p, vmax=hi_p, origin='lower')
        axes[0, c].set_title(f'{plane} = {idx} (image)', fontsize=9)
        axes[0, c].set_xticks([])
        axes[0, c].set_yticks([])
        axes[1, c].imshow(im_slice, cmap='gray', vmin=lo_p, vmax=hi_p, origin='lower')
        axes[1, c].imshow(make_overlay_rgba(m_slice), origin='lower')
        axes[1, c].set_title(f'{plane} = {idx} (image + tumor mask)', fontsize=9)
        axes[1, c].set_xticks([])
        axes[1, c].set_yticks([])

    fig.suptitle(title, fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(out_path, dpi=120, bbox_inches='tight')
    plt.close(fig)
    print(f'[saved] {out_path}')


# ---- BraTS 2021 FLAIR -----------------------------------------------------
BRATS21_ROOT = os.path.join(REPO, 'data/BraTS2021_Training')


def sample_brats21():
    dirs = sorted(glob.glob(os.path.join(BRATS21_ROOT, 'BraTS2021_*')))
    for d in dirs[:2]:
        cid = os.path.basename(d)
        img = os.path.join(d, f'{cid}_flair.nii.gz')
        seg = os.path.join(d, f'{cid}_seg.nii.gz')
        if os.path.exists(img) and os.path.exists(seg):
            render_one(img, seg,
                       f'BraTS 2021 FLAIR · whole-tumor binary · {cid}',
                       os.path.join(OUT, f'brats21_{cid}.png'))


# ---- BraTS 2024 GLI Post-Treatment clean cohort --------------------------
BRATS24_ROOT = os.path.join(REPO, 'data/BraTS2024_AdultGlioma_PostTreatment')
CASE_RE = re.compile(r'BraTS-GLI-(\d+)-(\d+)$')


def list_brats24_clean():
    by_patient = {}
    for sub in ('training_data1_v2', 'training_data_additional'):
        sub_root = os.path.join(BRATS24_ROOT, sub)
        if not os.path.isdir(sub_root):
            continue
        for entry in os.listdir(sub_root):
            m = CASE_RE.match(entry)
            if not m:
                continue
            patient, tp = int(m.group(1)), int(m.group(2))
            if patient < 2000 or tp < 101:
                continue
            by_patient.setdefault(patient, []).append((tp, os.path.join(sub_root, entry)))
    out = []
    for patient, tps in by_patient.items():
        tps.sort()
        tp, case_dir = tps[0]
        cid = os.path.basename(case_dir)
        flair = os.path.join(case_dir, f'{cid}-t2f.nii.gz')
        seg = os.path.join(case_dir, f'{cid}-seg.nii.gz')
        if os.path.exists(flair) and os.path.exists(seg):
            out.append({'image': flair, 'label': seg, 'id': cid})
    out.sort(key=lambda c: c['id'])
    return out


def sample_brats24():
    cases = list_brats24_clean()
    for case in cases[:2]:
        render_one(case['image'], case['label'],
                   f'BraTS 2024 GLI Post-Treatment FLAIR (t2f) · WT binary · {case["id"]}',
                   os.path.join(OUT, f'brats24_{case["id"]}.png'))


# ---- MSD Task06 Lung ------------------------------------------------------
MSD_ROOT = os.path.join(REPO, 'data/MSD_Task06_Lung/Task06_Lung')


def sample_msd():
    files = sorted(glob.glob(os.path.join(MSD_ROOT, 'imagesTr', '*.nii.gz')))
    files = [f for f in files if not os.path.basename(f).startswith('._')]
    for img in files[:2]:
        cid = os.path.basename(img).replace('.nii.gz', '')
        seg = os.path.join(MSD_ROOT, 'labelsTr', os.path.basename(img))
        if not os.path.exists(seg):
            continue
        render_one(img, seg,
                   f'MSD Task06 Lung · small tumor segmentation · {cid}',
                   os.path.join(OUT, f'msd_lung_{cid}.png'),
                   ct_window=(-1000, 300))


# ---- QIN Lung CT ----------------------------------------------------------
QIN_ROOT = os.path.join(REPO, 'data/qin_lung_ct')


def sample_qin():
    for d in sorted(glob.glob(os.path.join(QIN_ROOT, '*')))[:2]:
        if not os.path.isdir(d):
            continue
        cid = os.path.basename(d)
        img = os.path.join(d, 'image.nii.gz')
        seg = os.path.join(d, 'label.nii.gz')
        if not (os.path.exists(img) and os.path.exists(seg)):
            continue
        render_one(img, seg,
                   f'QIN Lung CT · {cid}',
                   os.path.join(OUT, f'qin_{cid}.png'),
                   ct_window=(-1000, 300))


def main():
    sample_brats21()
    sample_brats24()
    sample_msd()
    sample_qin()


if __name__ == '__main__':
    main()
