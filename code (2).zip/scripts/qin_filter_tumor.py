"""QIN-LungCT tumor-vs-whole-lung filter.

Jon (2026-06-01) noted that QIN-LungCT mixes per-lesion tumor segmentations
with whole-lung organ segmentations, and recommended a size-threshold + dark-
zone-fraction filter to keep only the tumor cases instead of dropping QIN.

Inspecting the 46 'ok' cases in data/qin_lung_ct/manifest.csv reveals a clean
bimodal split with no overlap:

  tumor-like    (10 cases)  mask_vox in    1.6k -   40k    dark_pct  1.8 - 60.0 %
  whole-lung    (36 cases)  mask_vox in 1.00M - 3.03M     dark_pct 92.1 - 99.1 %

Decision rule (chosen well inside the 25x mask-volume gap and the 32-pct
dark-fraction gap):
    is_tumor := (mask_vox <= 200_000)  AND  (dark_in_mask_frac <= 0.85)

where dark_in_mask_frac = fraction of masked voxels with HU < -300.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import nibabel as nib
import numpy as np

QIN_ROOT = Path("/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/qin_lung_ct")
DARK_HU_THRESH = -300
MAX_TUMOR_VOX = 200_000
MAX_TUMOR_DARK_FRAC = 0.85


def stats_for_case(case_dir: Path) -> dict:
    img = nib.load(case_dir / "image.nii.gz").get_fdata()
    lab = nib.load(case_dir / "label.nii.gz").get_fdata()
    mask = lab > 0
    mvox = int(mask.sum())
    out = {
        "patient_id": case_dir.name,
        "mask_vox": mvox,
        "mask_pct": float(mvox / mask.size) if mask.size else 0.0,
        "dark_in_mask_frac": 0.0,
        "mask_HU_median": 0.0,
        "is_tumor": False,
    }
    if mvox == 0:
        return out
    hus = img[mask]
    out["dark_in_mask_frac"] = float(np.mean(hus < DARK_HU_THRESH))
    out["mask_HU_median"] = float(np.median(hus))
    out["is_tumor"] = bool(
        mvox <= MAX_TUMOR_VOX and out["dark_in_mask_frac"] <= MAX_TUMOR_DARK_FRAC
    )
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=QIN_ROOT)
    ap.add_argument(
        "--out-csv",
        type=Path,
        default=QIN_ROOT / "manifest_tumor.csv",
        help="Filtered manifest of tumor-only cases.",
    )
    ap.add_argument(
        "--out-json",
        type=Path,
        default=QIN_ROOT / "filter_stats.json",
        help="Per-case statistics for the full manifest.",
    )
    args = ap.parse_args()

    src = list(csv.DictReader(open(args.root / "manifest.csv")))
    ok = [r for r in src if r["status"] == "ok"]
    print(f"scanning {len(ok)} ok cases from {args.root / 'manifest.csv'}")

    all_stats = []
    for r in ok:
        s = stats_for_case(args.root / r["patient_id"])
        all_stats.append(s)
        flag = "tumor" if s["is_tumor"] else "WHOLE_LUNG"
        print(
            f"  {s['patient_id']:<22} mvox={s['mask_vox']:>10d} "
            f"dark={100*s['dark_in_mask_frac']:>5.1f}%  median={s['mask_HU_median']:>5.0f}  {flag}"
        )

    tumors = [s for s in all_stats if s["is_tumor"]]
    whole = [s for s in all_stats if not s["is_tumor"]]
    summary = {
        "rule": {
            "dark_HU_threshold": DARK_HU_THRESH,
            "max_tumor_voxels": MAX_TUMOR_VOX,
            "max_tumor_dark_fraction": MAX_TUMOR_DARK_FRAC,
        },
        "n_scanned": len(all_stats),
        "n_tumor": len(tumors),
        "n_whole_lung": len(whole),
        "tumor_mask_vox_min": min((s["mask_vox"] for s in tumors), default=None),
        "tumor_mask_vox_max": max((s["mask_vox"] for s in tumors), default=None),
        "whole_mask_vox_min": min((s["mask_vox"] for s in whole), default=None),
        "whole_mask_vox_max": max((s["mask_vox"] for s in whole), default=None),
        "cases": all_stats,
    }
    args.out_json.write_text(json.dumps(summary, indent=2))
    print(f"\nwrote {args.out_json}")

    with open(args.out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["patient_id", "status", "note"])
        for s in tumors:
            w.writerow(
                [
                    s["patient_id"],
                    "ok",
                    f"mask_vox={s['mask_vox']};dark_frac={s['dark_in_mask_frac']:.3f}",
                ]
            )
    print(f"wrote {args.out_csv}  ({len(tumors)} tumor cases)")

    print(
        f"\nsummary: {len(tumors)} tumor / {len(whole)} whole-lung / "
        f"{len(all_stats)} total"
    )


if __name__ == "__main__":
    main()
