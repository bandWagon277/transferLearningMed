"""Simulation 1+5 from the 2026-06-19 Codex consult: Gaussian probes through
random conv nets, evaluated under raw CKA + null-corrected CKA + bootstrap CI.

Question: is our RI-RI ≈ 1 finding an architectural artifact of medical-probe
input correlation, or also reproducible on isotropic Gaussian probes? If
isotropic random probes through random conv nets give CKA ≈ 0 (Murphy 2024
prediction with debiased estimator), then the medical-MRI cohort really is
the dominant cause and the bias correction is the methodological fix.

Sweeps:
  - n_probes ∈ {40, 100, 400, 1000}
  - feature_extraction depth ∈ {1, 2, 3, 5, 8, 12}   (layers of 3x3x3 conv + ReLU)
  - input ∈ {iid_gauss, low_rank_gauss, real_brats_flair_subsample}
  - feature_pooling ∈ {GAP, full_spatial}
  - norm ∈ {none, IN_affine_false, BN_eval, GroupNorm_8}

For each cell: K = 5 random-init seeds, compute pairwise CKA + null-corrected
CKA + 200-resample bootstrap CI. Reports per-layer mean ± SD across pairs.

Output: runs/sim_cka_gaussian_probes_0619.json + runs/figures/0619/sim_cka_gaussian_probes.png

Timeline: ~30 min on A40 (small nets, small probes).
"""
from __future__ import annotations
import os
import sys
import json
import itertools

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

import numpy as np
import torch
import torch.nn as nn
import nibabel as nib

from affinity import linear_cka, null_corrected_cka_with_ci

REPO = os.path.dirname(THIS)
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
ROI = (32, 32, 32)  # smaller than BraTS (128³) — keeps the sim fast


class RandConvStack(nn.Module):
    """Stack of (Conv3d 3x3x3 + Norm + ReLU) layers, fixed channel width.

    Norm options: 'none', 'in_affine_false', 'bn_eval', 'gn_8'.
    """
    def __init__(self, in_ch=1, ch=32, depth=5, norm='in_affine_false'):
        super().__init__()
        self.layers = nn.ModuleList()
        prev = in_ch
        for _ in range(depth):
            block = [nn.Conv3d(prev, ch, kernel_size=3, padding=1)]
            if norm == 'in_affine_false':
                block.append(nn.InstanceNorm3d(ch, affine=False))
            elif norm == 'bn_eval':
                block.append(nn.BatchNorm3d(ch))
            elif norm == 'gn_8':
                block.append(nn.GroupNorm(8, ch))
            elif norm == 'none':
                pass
            else:
                raise ValueError(f'unknown norm {norm!r}')
            block.append(nn.ReLU(inplace=True))
            self.layers.append(nn.Sequential(*block))
            prev = ch

    def forward(self, x):
        outs = []
        for layer in self.layers:
            x = layer(x)
            outs.append(x)
        return outs


def init_seed(model, seed):
    torch.manual_seed(seed)
    for m in model.modules():
        if isinstance(m, nn.Conv3d):
            nn.init.kaiming_normal_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm3d, nn.InstanceNorm3d, nn.GroupNorm)):
            if getattr(m, 'weight', None) is not None:
                nn.init.ones_(m.weight)
            if getattr(m, 'bias', None) is not None:
                nn.init.zeros_(m.bias)


def make_inputs(kind: str, n: int, roi=ROI, seed=42):
    """Generate n × (1, *roi) input tensors of various kinds."""
    rng = np.random.default_rng(seed)
    if kind == 'iid_gauss':
        return rng.standard_normal((n, 1, *roi)).astype(np.float32)
    elif kind == 'low_rank_gauss':
        latent = rng.standard_normal((n, 8))             # 8-dim latent
        basis  = rng.standard_normal((8, np.prod(roi)))
        arr = (latent @ basis).reshape(n, 1, *roi)
        return arr.astype(np.float32)
    elif kind == 'real_brats':
        import glob
        cases = sorted(glob.glob(os.path.join(REPO,
            'data/BraTS2021_Training/BraTS2021_*/BraTS2021_*_flair.nii.gz')))
        idx = rng.permutation(len(cases))[:n]
        arrs = []
        for i in idx:
            x = nib.load(cases[i]).get_fdata().astype(np.float32)
            # center-crop to ROI
            cz, cy, cx = (np.array(x.shape) - np.array(roi)) // 2
            x = x[cz:cz+roi[0], cy:cy+roi[1], cx:cx+roi[2]]
            mask = x > 0
            if mask.any():
                x = (x - x[mask].mean()) / (x[mask].std() + 1e-6)
            arrs.append(x[None])
        return np.stack(arrs, axis=0).astype(np.float32)
    else:
        raise ValueError(f'unknown input kind {kind!r}')


def extract_per_layer(model, X_np, device=DEVICE, pool='gap'):
    """X_np: (n, 1, *roi).  Returns dict[layer_idx] -> (n, feature_dim)."""
    model.eval().to(device)
    n = X_np.shape[0]
    bufs = None
    with torch.no_grad():
        for i in range(n):
            x = torch.from_numpy(X_np[i:i+1]).to(device)
            outs = model(x)
            if bufs is None:
                bufs = [[] for _ in outs]
            for j, o in enumerate(outs):
                if pool == 'gap':
                    feat = o.mean(dim=tuple(range(2, o.ndim))).squeeze(0)
                else:
                    feat = o.reshape(-1)
                bufs[j].append(feat.cpu().numpy().astype(np.float32))
    return {j: np.stack(bufs[j], axis=0) for j in range(len(bufs))}


def main():
    INPUT_KINDS = ['iid_gauss', 'low_rank_gauss', 'real_brats']
    DEPTHS = [1, 2, 3, 5, 8, 12]
    NORMS = ['in_affine_false', 'bn_eval', 'gn_8', 'none']
    N_PROBES = [40, 200, 1000]
    POOL = 'gap'
    N_SEEDS = 5

    out = {
        'config': {
            'input_kinds': INPUT_KINDS, 'depths': DEPTHS, 'norms': NORMS,
            'n_probes': N_PROBES, 'pool': POOL, 'n_seeds': N_SEEDS, 'roi': list(ROI),
        },
        'results': {},
    }

    for n in N_PROBES:
        for kind in INPUT_KINDS:
            try:
                X = make_inputs(kind, n)
            except Exception as e:
                print(f'  [skip] kind={kind!r} n={n}: {e}', file=sys.stderr)
                continue
            for norm in NORMS:
                for depth in DEPTHS:
                    tag = f'n={n}|kind={kind}|norm={norm}|depth={depth}'
                    print(tag, flush=True)
                    feats_per_seed = []
                    for s in range(N_SEEDS):
                        m = RandConvStack(in_ch=1, ch=32, depth=depth, norm=norm)
                        init_seed(m, seed=s)
                        feats = extract_per_layer(m, X, pool=POOL)
                        feats_per_seed.append(feats)
                        del m
                        if DEVICE == 'cuda':
                            torch.cuda.empty_cache()

                    per_layer = {}
                    for L in range(depth):
                        ckas, R_vals = [], []
                        for a, b in itertools.combinations(range(N_SEEDS), 2):
                            stats = null_corrected_cka_with_ci(
                                feats_per_seed[a][L], feats_per_seed[b][L],
                                n_boot=50, n_perm=100, seed=a*100 + b)
                            ckas.append(stats['cka'])
                            R_vals.append(stats['cka_null_corrected'])
                        per_layer[f'layer_{L}'] = {
                            'cka_mean': float(np.mean(ckas)),
                            'cka_std':  float(np.std(ckas)),
                            'R_mean':   float(np.mean(R_vals)),
                            'R_std':    float(np.std(R_vals)),
                            'n_pairs':  len(ckas),
                        }
                    out['results'][tag] = per_layer

    out_json = os.path.join(REPO, 'runs/sim_cka_gaussian_probes_0619.json')
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    with open(out_json, 'w') as f:
        json.dump(out, f, indent=2)
    print(f'\n[saved] {out_json}')

    # Plot: per-input-kind, raw CKA vs depth for each norm, at n=1000, deepest layer
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        return

    fig, axes = plt.subplots(2, len(INPUT_KINDS), figsize=(5*len(INPUT_KINDS), 8),
                             sharex=True, sharey='row')
    for col, kind in enumerate(INPUT_KINDS):
        for norm, color in zip(NORMS, ['#4C78A8', '#F58518', '#54A24B', '#E45756']):
            xs, ys_raw, ys_R = [], [], []
            for depth in DEPTHS:
                tag = f'n=1000|kind={kind}|norm={norm}|depth={depth}'
                if tag not in out['results']:
                    continue
                # Use deepest captured layer
                deepest = f'layer_{depth-1}'
                rec = out['results'][tag][deepest]
                xs.append(depth)
                ys_raw.append(rec['cka_mean'])
                ys_R.append(rec['R_mean'])
            axes[0][col].plot(xs, ys_raw, marker='o', label=norm, color=color)
            axes[1][col].plot(xs, ys_R, marker='o', label=norm, color=color)
        axes[0][col].set_title(f'input = {kind}')
        axes[0][col].set_ylabel('raw CKA (deepest layer)') if col == 0 else None
        axes[1][col].set_ylabel('null-corrected R')         if col == 0 else None
        axes[1][col].set_xlabel('depth')
        axes[0][col].set_ylim(-0.1, 1.1)
        axes[1][col].set_ylim(-0.5, 1.1)
        axes[0][col].grid(alpha=0.3)
        axes[1][col].grid(alpha=0.3)
    axes[0][0].legend(loc='lower left', fontsize='small')
    fig.suptitle('Simulation: Gaussian/correlated probes through random conv stacks (Codex 0619 Q3-B)')
    fig.tight_layout()
    fig_path = os.path.join(REPO, 'runs/figures/0619/sim_cka_gaussian_probes.png')
    os.makedirs(os.path.dirname(fig_path), exist_ok=True)
    fig.savefig(fig_path, dpi=130, bbox_inches='tight')
    print(f'[saved] {fig_path}')


if __name__ == '__main__':
    main()
