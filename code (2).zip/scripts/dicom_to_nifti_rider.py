"""Build Task514_RIDER from RIDER LungCT DICOM (32 patients, 2072 series).

Each zipped series at data/RIDER_LungCT/rider_lungct/<PATIENT>__<MOD>__<SeriesUID>.zip
holds one DICOM modality (CT, SEG, RTSTRUCT, ...) for one series. For each
patient we:
  1. extract the earliest CT series (largest volume) -> NIfTI
  2. pick the matching SEG series (first one); decode it to a binary mask
     aligned to the CT grid; collapse any multi-segment SEG to "tumor != 0"
  3. write image.nii.gz / label.nii.gz under data/rider_lungct_nifti/<patient>/

After image/label NIfTIs are built, nnU-Net Task514_RIDER is populated and
its dataset.json written.

This pass is bounded:
  - skip a patient if no SEG zip is found
  - skip a patient if SEG cannot be aligned to a CT series (frame-of-ref
    mismatch); print why so it is visible in the SLURM log
The output count drives whether step 3C (RIDER training jobs) runs.
"""
from __future__ import annotations
import json, os, re, shutil, sys, tempfile, zipfile, glob, traceback
from collections import defaultdict

import numpy as np
import pydicom
import pydicom_seg
import SimpleITK as sitk

REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
SRC = f'{REPO}/data/RIDER_LungCT/rider_lungct'
NIFTI_DIR = f'{REPO}/data/rider_lungct_nifti'
DST = f'{REPO}/data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data/Task514_RIDER'

os.makedirs(NIFTI_DIR, exist_ok=True)
os.makedirs(f'{DST}/imagesTr', exist_ok=True)
os.makedirs(f'{DST}/labelsTr', exist_ok=True)

# RIDER zip names look like: RIDER-1129164940__CT__051767233894.zip
ZIP_RE = re.compile(r'^(RIDER-\d+)__([A-Z]+)__([\d.]+)\.zip$')

zips_by_patient: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
for f in sorted(os.listdir(SRC)):
    m = ZIP_RE.match(f)
    if not m:
        continue
    pid, mod, _ = m.group(1), m.group(2), m.group(3)
    zips_by_patient[pid][mod].append(f'{SRC}/{f}')

print(f'Found {len(zips_by_patient)} patients.')

def read_ct_series(extract_dir: str):
    """Read a CT series directory of DICOM files into a SimpleITK image."""
    reader = sitk.ImageSeriesReader()
    dicom_names = reader.GetGDCMSeriesFileNames(extract_dir)
    if not dicom_names:
        return None
    reader.SetFileNames(dicom_names)
    return reader.Execute()


def extract_one(zip_path: str, dst_dir: str):
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(dst_dir)


def biggest_ct(pid_zips: dict, tmpdir: str):
    """Extract every CT zip, pick the one with the most slices."""
    best = None
    best_n = 0
    best_img = None
    for zp in pid_zips.get('CT', []):
        sub = os.path.join(tmpdir, os.path.basename(zp)[:-4])
        os.makedirs(sub, exist_ok=True)
        try:
            extract_one(zp, sub)
            img = read_ct_series(sub)
            if img is None:
                continue
            n = img.GetSize()[2]
            if n > best_n:
                best_n = n
                best_img = img
                best = zp
        except Exception as e:
            print(f'    [CT-read-fail] {os.path.basename(zp)}: {e}')
    return best, best_img


def decode_seg(zp: str, ct_img):
    """Extract a DICOM-SEG zip and return a binary mask aligned to ct_img.

    Returns None if alignment fails.
    """
    tmpd = tempfile.mkdtemp(prefix='seg_')
    try:
        extract_one(zp, tmpd)
        dcms = glob.glob(f'{tmpd}/*.dcm') + glob.glob(f'{tmpd}/*.DCM')
        if not dcms:
            return None
        ds = pydicom.dcmread(dcms[0])
        # DICOM-SEG has Modality == 'SEG'
        if getattr(ds, 'Modality', None) != 'SEG':
            return None
        reader = pydicom_seg.SegmentReader()
        result = reader.read(ds)
        # Combine all segments into a single binary tumor mask.
        combined = None
        for seg_num in result.available_segments:
            seg_img = result.segment_image(seg_num)
            arr = sitk.GetArrayFromImage(seg_img)
            if combined is None:
                combined = (arr > 0).astype(np.uint8)
            else:
                # broadcast-pad / crop to same shape if necessary
                if combined.shape == arr.shape:
                    combined = np.maximum(combined, (arr > 0).astype(np.uint8))
        if combined is None:
            return None
        out = sitk.GetImageFromArray(combined)
        # We use any non-CT direction from result.segment_image to set spatial info.
        seg_img0 = result.segment_image(list(result.available_segments)[0])
        out.CopyInformation(seg_img0)
        # Resample to CT grid (nearest)
        out_resampled = sitk.Resample(out, ct_img, sitk.Transform(), sitk.sitkNearestNeighbor, 0)
        return out_resampled
    except Exception as e:
        print(f'    [SEG-decode-fail] {os.path.basename(zp)}: {e}')
        traceback.print_exc()
        return None
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)


training_entries = []
n_ok = 0
for pid, zips in zips_by_patient.items():
    if 'CT' not in zips or 'SEG' not in zips:
        print(f'{pid}: missing CT or SEG, skip')
        continue
    print(f'{pid}: CT={len(zips["CT"])} SEG={len(zips["SEG"])}')
    out_dir = f'{NIFTI_DIR}/{pid}'
    os.makedirs(out_dir, exist_ok=True)
    out_img = f'{out_dir}/image.nii.gz'
    out_lbl = f'{out_dir}/label.nii.gz'
    if os.path.exists(out_img) and os.path.exists(out_lbl):
        print('  already converted, reusing')
    else:
        with tempfile.TemporaryDirectory(prefix=f'rider_{pid}_') as tmpd:
            ct_zp, ct_img = biggest_ct(zips, tmpd)
            if ct_img is None:
                print('  no readable CT, skip'); continue
            seg = None
            for seg_zp in zips['SEG']:
                seg = decode_seg(seg_zp, ct_img)
                if seg is not None:
                    print(f'  CT={os.path.basename(ct_zp)}  SEG={os.path.basename(seg_zp)}')
                    break
            if seg is None:
                print('  no decodable SEG, skip'); continue
            seg_arr = sitk.GetArrayFromImage(seg)
            if seg_arr.sum() == 0:
                print('  SEG empty after alignment, skip'); continue
            sitk.WriteImage(ct_img, out_img)
            sitk.WriteImage(seg, out_lbl)
    safe = pid.replace('-', '_')
    img_out = f'{DST}/imagesTr/{safe}_0000.nii.gz'
    lbl_out = f'{DST}/labelsTr/{safe}.nii.gz'
    shutil.copyfile(out_img, img_out)
    shutil.copyfile(out_lbl, lbl_out)
    training_entries.append({'image': f'./imagesTr/{safe}.nii.gz',
                             'label': f'./labelsTr/{safe}.nii.gz'})
    n_ok += 1

dataset = {
    'name': 'Task514_RIDER',
    'description': 'RIDER Lung CT tumor segmentation (DICOM-SEG decoded; binary mask).',
    'reference': 'RIDER Lung CT (TCIA)',
    'licence': 'CC-BY-NC',
    'release': '1.0 (2026-06-22)',
    'tensorImageSize': '4D',
    'modality': {'0': 'CT'},
    'labels': {'0': 'background', '1': 'tumor'},
    'numTraining': n_ok,
    'numTest': 0,
    'training': training_entries,
    'test': []
}
with open(f'{DST}/dataset.json', 'w') as f:
    json.dump(dataset, f, indent=2)
print(f'\nRIDER: converted {n_ok} / {len(zips_by_patient)} patients.')
