"""Render prediction-vs-ground-truth overlays for two model families not
covered by the existing scratch/viz_pred/ tree.

Part 1: BraTS 2024 GLI Post-Treatment clean cohort, MONAI 3D U-Net fold 0
        scratch and BraTS21 -> BraTS24 full fine-tune.
Part 2: MSD Task06 Lung under the nnU-Net recipe (Generic_UNet, the
        2026-06-18 recipe-vs-architecture row): scratch and BraTS21 -> MSD
        full fine-tune. Inference goes through the 3D-TransUNet codebase's
        own inference.py, because its checkpoint layout uses the project's
        custom UNet_IN_NANFang results tree rather than the stock nnU-Net
        layout.

Layout per overlay PNG (same as code/visualize_predictions.py):
  3 rows (axial / coronal / sagittal at the tumor centroid)
  4 cols (image / ground truth / model prediction / colored overlay)

Outputs:
  deliverable/figures/visualizations/monai_recipe_brats24/
  deliverable/figures/visualizations/nnunet_recipe_msd/
"""
from __future__ import annotations

import argparse
import os
import pickle
import random
import re
import shutil
import subprocess
import sys

import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import torch
import monai.transforms as T
from monai.inferers import sliding_window_inference
from monai.networks.nets import UNet as MonaiUNet


REPO = '/nfs/turbo/jiankanggroup/gengyh/transferMRI'
OUT_BRATS24 = os.path.join(REPO, 'deliverable/figures/visualizations/monai_recipe_brats24')
OUT_MSD_NEW = os.path.join(REPO, 'deliverable/figures/visualizations/nnunet_recipe_msd')
os.makedirs(OUT_BRATS24, exist_ok=True)
os.makedirs(OUT_MSD_NEW, exist_ok=True)


# ---------------------------------------------------------------------------
# Shared rendering helpers
# ---------------------------------------------------------------------------

def tumor_centroid_3d(mask: np.ndarray):
    coords = np.argwhere(mask > 0)
    if len(coords) == 0:
        return tuple(s // 2 for s in mask.shape)
    return tuple(int(c) for c in coords.mean(axis=0))


def make_overlay_rgba(gt: np.ndarray, pred: np.ndarray, alpha: float = 0.55) -> np.ndarray:
    h, w = gt.shape
    rgba = np.zeros((h, w, 4), dtype=np.float32)
    tp = (gt == 1) & (pred == 1)
    fn = (gt == 1) & (pred == 0)
    fp = (gt == 0) & (pred == 1)
    rgba[tp] = [0.0, 0.85, 0.0, alpha]
    rgba[fn] = [0.0, 0.45, 1.0, alpha]
    rgba[fp] = [1.0, 0.15, 0.15, alpha]
    return rgba


def case_dice(pred: np.ndarray, gt: np.ndarray) -> float:
    inter = (pred * gt).sum()
    s = pred.sum() + gt.sum()
    if s == 0:
        return 1.0
    return float(2.0 * inter / s)


def render_3x4_panel(img_zyx: np.ndarray, gt_zyx: np.ndarray, pred_zyx: np.ndarray,
                     title: str, out_path: str):
    z, y, x = tumor_centroid_3d(gt_zyx)
    lo, hi = np.percentile(img_zyx, (1, 99))
    dice = case_dice(pred_zyx, gt_zyx)
    fig, axes = plt.subplots(3, 4, figsize=(13, 10))
    col_titles = ['image', 'ground truth', f'prediction  Dice={dice:.3f}',
                  'overlay  TP green / FN blue / FP red']
    plane_specs = [
        ('axial', z, img_zyx[z, :, :], gt_zyx[z, :, :], pred_zyx[z, :, :]),
        ('coronal', y, img_zyx[:, y, :], gt_zyx[:, y, :], pred_zyx[:, y, :]),
        ('sagittal', x, img_zyx[:, :, x], gt_zyx[:, :, x], pred_zyx[:, :, x]),
    ]
    for r, (plane, idx, im_slice, m_slice, p_slice) in enumerate(plane_specs):
        for c, kind in enumerate(['image', 'gt', 'pred', 'overlay']):
            axes[r, c].imshow(im_slice, cmap='gray', vmin=lo, vmax=hi, origin='lower')
            if kind == 'gt':
                mm = np.ma.masked_where(m_slice == 0, m_slice)
                axes[r, c].imshow(mm, cmap=plt.get_cmap('autumn'), alpha=0.55,
                                  origin='lower', vmin=0, vmax=1)
            elif kind == 'pred':
                pp = np.ma.masked_where(p_slice == 0, p_slice)
                axes[r, c].imshow(pp, cmap=plt.get_cmap('cool'), alpha=0.55,
                                  origin='lower', vmin=0, vmax=1)
            elif kind == 'overlay':
                axes[r, c].imshow(make_overlay_rgba(m_slice, p_slice), origin='lower')
            axes[r, c].set_title(f'{plane}={idx}  {col_titles[c]}', fontsize=9)
            axes[r, c].set_xticks([])
            axes[r, c].set_yticks([])
    fig.suptitle(title, fontsize=11, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(out_path, dpi=120, bbox_inches='tight')
    plt.close(fig)
    print(f'[saved] {out_path}  Dice={dice:.3f}', flush=True)
    return dice


# ---------------------------------------------------------------------------
# Part 1: BraTS 2024 MONAI U-Net (MONAI recipe)
# ---------------------------------------------------------------------------

CASE_RE = re.compile(r'BraTS-GLI-(\d+)-(\d+)$')


def list_brats24_clean():
    root = os.path.join(REPO, 'data/BraTS2024_AdultGlioma_PostTreatment')
    by_patient = {}
    for sub in ('training_data1_v2', 'training_data_additional'):
        sub_root = os.path.join(root, sub)
        if not os.path.isdir(sub_root):
            continue
        for entry in os.listdir(sub_root):
            m = CASE_RE.match(entry)
            if not m:
                continue
            patient, tp = int(m.group(1)), int(m.group(2))
            if patient < 2000 or tp < 101:
                continue
            by_patient.setdefault(patient, []).append((tp, os.path.join(sub_root, entry)))
    out = []
    for patient, tps in by_patient.items():
        tps.sort()
        tp, case_dir = tps[0]
        cid = os.path.basename(case_dir)
        flair = os.path.join(case_dir, f'{cid}-t2f.nii.gz')
        seg = os.path.join(case_dir, f'{cid}-seg.nii.gz')
        if os.path.exists(flair) and os.path.exists(seg):
            out.append({'image': flair, 'label': seg, 'case_id': cid})
    out.sort(key=lambda c: c['case_id'])
    return out


def split_kfold(cases, fold: int, n_folds: int = 5, seed: int = 42):
    rng = random.Random(seed)
    shuffled = list(cases)
    rng.shuffle(shuffled)
    n = len(shuffled)
    fold_size = n // n_folds
    rem = n % n_folds
    sizes = [fold_size + (1 if i < rem else 0) for i in range(n_folds)]
    starts = [sum(sizes[:i]) for i in range(n_folds)]
    val_start = starts[fold]
    val_end = val_start + sizes[fold]
    return shuffled[:val_start] + shuffled[val_end:], shuffled[val_start:val_end]


class BinarizeWT(T.MapTransform):
    def __call__(self, data):
        d = dict(data)
        for k in self.keys:
            d[k] = (d[k] > 0).float() if torch.is_tensor(d[k]) else (np.asarray(d[k]) > 0).astype(np.float32)
        return d


def brats_val_transforms():
    return T.Compose([
        T.LoadImaged(keys=['image', 'label']),
        T.EnsureChannelFirstd(keys=['image', 'label']),
        BinarizeWT(keys=['label']),
        T.Orientationd(keys=['image', 'label'], axcodes='RAS'),
        T.Spacingd(keys=['image', 'label'], pixdim=(1.0, 1.0, 1.0),
                   mode=('bilinear', 'nearest')),
        T.NormalizeIntensityd(keys='image', nonzero=True, channel_wise=True),
    ])


def build_unet(device):
    return MonaiUNet(spatial_dims=3, in_channels=1, out_channels=1,
                     channels=(32, 64, 128, 256, 512), strides=(2, 2, 2, 2),
                     num_res_units=0).to(device).eval()


def render_brats24_for_ckpt(ckpt_path: str, label: str, n_cases: int = 3):
    cases = list_brats24_clean()
    _, val = split_kfold(cases, fold=0, n_folds=5, seed=42)
    val = val[:n_cases]
    print(f'[brats24] {label} val cases:', [c['case_id'] for c in val], flush=True)

    device = torch.device('cuda')
    model = build_unet(device)
    ck = torch.load(os.path.join(REPO, ckpt_path), map_location=device, weights_only=True)
    sd = ck.get('state_dict', ck)
    model.load_state_dict(sd)
    transforms = brats_val_transforms()

    for case in val:
        item = transforms(case)
        img_t = item['image'].float()
        gt_arr = (np.asarray(item['label'])[0] > 0.5).astype(np.uint8)
        with torch.no_grad():
            with torch.cuda.amp.autocast(enabled=True):
                logits = sliding_window_inference(
                    inputs=img_t.unsqueeze(0).to(device),
                    roi_size=(192, 192, 144), sw_batch_size=1, predictor=model,
                    overlap=0.5, mode='gaussian')
        pred = (torch.sigmoid(logits.float()).cpu().numpy()[0, 0] > 0.5).astype(np.uint8)
        img_np = img_t.cpu().numpy()[0]
        img_zyx = np.transpose(img_np, (2, 1, 0))
        gt_zyx = np.transpose(gt_arr, (2, 1, 0))
        pred_zyx = np.transpose(pred, (2, 1, 0))
        out_path = os.path.join(OUT_BRATS24, f'{label}_{case["case_id"]}.png')
        render_3x4_panel(img_zyx, gt_zyx, pred_zyx,
                         title=f'BraTS 2024 GLI Post-Treatment · MONAI 3D U-Net · {label} · fold 0\n{case["case_id"]}',
                         out_path=out_path)


def part1_brats24():
    print('\n=== Part 1: BraTS 2024 MONAI U-Net overlays ===', flush=True)
    render_brats24_for_ckpt(
        ckpt_path='code/pretrained/brats2024_pretrain/scratch_fold0/best.pt',
        label='scratch')
    render_brats24_for_ckpt(
        ckpt_path='code/pretrained/brats2024_pretrain/from_brats21_full_fold0/best.pt',
        label='from_brats21_full')


# ---------------------------------------------------------------------------
# Part 2: MSD Task06 Lung under nnU-Net recipe (Generic_UNet)
# Inference goes through 3D-TransUNet's own inference.py.
# ---------------------------------------------------------------------------

TRANSUNET = os.path.join(REPO, 'code/external/3D-TransUNet')
TASK006_RAW = os.path.join(REPO, 'data/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data/Task006_Lung')
TASK006_PREP = os.path.join(REPO, 'data/nnUNet/nnUNet_preprocessed/Task006_Lung')


def msd_fold0_val_case_ids():
    with open(os.path.join(TASK006_PREP, 'splits_final.pkl'), 'rb') as f:
        splits = pickle.load(f)
    return list(splits[0]['val'])


def stage_val_inputs(case_ids, stage_dir: str):
    if os.path.exists(stage_dir):
        shutil.rmtree(stage_dir)
    os.makedirs(stage_dir)
    images_src = os.path.join(TASK006_RAW, 'imagesTr')
    for cid in case_ids:
        src = os.path.join(images_src, f'{cid}_0000.nii.gz')
        dst = os.path.join(stage_dir, f'{cid}_0000.nii.gz')
        if not os.path.exists(src):
            raise FileNotFoundError(src)
        os.symlink(src, dst)


def run_3d_transunet_inference(config_yaml: str, stage_dir: str, save_dir: str):
    """Invoke 3D-TransUNet inference.py on a staged subset of val cases.
    Predictions land in save_dir as <case_id>.nii.gz."""
    if os.path.exists(save_dir):
        shutil.rmtree(save_dir)
    os.makedirs(save_dir)
    env = os.environ.copy()
    env.setdefault('nnUNet_raw_data_base',
                   os.path.join(REPO, 'data/nnUNet/nnUNet_raw_data_base'))
    env.setdefault('nnUNet_preprocessed',
                   os.path.join(REPO, 'data/nnUNet/nnUNet_preprocessed'))
    env.setdefault('RESULTS_FOLDER',
                   os.path.join(REPO, 'data/nnUNet/nnUNet_results'))
    env['PYTHONPATH'] = TRANSUNET + ':' + env.get('PYTHONPATH', '')
    cmd = [
        sys.executable, os.path.join(TRANSUNET, 'inference.py'),
        '--config', config_yaml,
        '--fold', '0',
        '--raw_data_dir', stage_dir,
        '--save_folder', save_dir,
        '--disable_split',
    ]
    print('[inference.py]', ' '.join(cmd), flush=True)
    subprocess.run(cmd, check=True, env=env, cwd=TRANSUNET)


def render_msd_new_for_config(config_yaml: str, label: str, val_case_ids):
    stage_dir = os.path.join(REPO, f'scratch/viz_msd_new_in_{label}')
    save_dir = os.path.join(REPO, f'scratch/viz_msd_new_out_{label}')
    stage_val_inputs(val_case_ids, stage_dir)
    run_3d_transunet_inference(config_yaml, stage_dir, save_dir)

    images_src = os.path.join(TASK006_RAW, 'imagesTr')
    labels_src = os.path.join(TASK006_RAW, 'labelsTr')
    for cid in val_case_ids:
        img = nib.load(os.path.join(images_src, f'{cid}_0000.nii.gz')).get_fdata().astype(np.float32)
        gt = (nib.load(os.path.join(labels_src, f'{cid}.nii.gz')).get_fdata() > 0).astype(np.uint8)
        pred_path = os.path.join(save_dir, f'{cid}.nii.gz')
        if not os.path.exists(pred_path):
            print(f'[warn] no prediction for {cid} at {pred_path}', flush=True)
            continue
        pred = (nib.load(pred_path).get_fdata() > 0).astype(np.uint8)
        img = np.clip(img, -1000, 300)
        img_zyx = np.transpose(img, (2, 1, 0))
        gt_zyx = np.transpose(gt, (2, 1, 0))
        pred_zyx = np.transpose(pred, (2, 1, 0))
        out_path = os.path.join(OUT_MSD_NEW, f'{label}_{cid}.png')
        render_3x4_panel(img_zyx, gt_zyx, pred_zyx,
                         title=f'MSD Task06 Lung · nnU-Net Generic_UNet · {label} · fold 0\n{cid}',
                         out_path=out_path)


def part2_msd_new_scheme():
    print('\n=== Part 2: MSD Task06 Lung nnU-Net new-scheme overlays ===', flush=True)
    val_case_ids = msd_fold0_val_case_ids()[:3]
    print(f'fold 0 val cases used: {val_case_ids}', flush=True)
    render_msd_new_for_config(
        config_yaml=os.path.join(TRANSUNET, 'configs/TransferMRI/lung_cnn_unet_scratch.yaml'),
        label='scratch', val_case_ids=val_case_ids)
    render_msd_new_for_config(
        config_yaml=os.path.join(TRANSUNET, 'configs/TransferMRI/lung_encoder_only_transfer_full.yaml'),
        label='from_brats21_full', val_case_ids=val_case_ids)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--skip-brats24', action='store_true')
    p.add_argument('--skip-msd-new', action='store_true')
    args = p.parse_args()
    # Part 2 must run first: it spawns nnU-Net's inference.py as a subprocess
    # that uses DDP / nccl, and that fails if this parent process has already
    # initialized a CUDA context (which Part 1 would do).
    if not args.skip_msd_new:
        part2_msd_new_scheme()
    if not args.skip_brats24:
        part1_brats24()


if __name__ == '__main__':
    main()
