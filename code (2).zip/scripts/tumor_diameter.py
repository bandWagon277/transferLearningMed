"""Compute physical tumor size descriptors from a binary segmentation mask.

For each case the script reports:
  * voxel spacing (sx, sy, sz) in millimetres, read from the NIfTI affine,
  * total foreground voxel count and physical volume in cm^3,
  * 3D longest diameter in mm: the maximum Euclidean distance, in physical
    coordinates, between any two voxels of the largest connected component.
    This is the orientation-invariant "longest chord" through the tumor.
  * RECIST-style axial longest diameter in mm: per axial slice of the largest
    connected component, the maximum in-plane chord; we then take the max
    across slices.  This matches the clinical RECIST 1.1 definition that the
    RIDER trial radiologists used.

Both diameters use the convex hull of the relevant voxel set in physical
coordinates and then a pairwise distance over hull vertices only, so the
runtime stays near-linear in the number of foreground voxels for any
realistic tumor size.

CLI
---
Single case:
    python tumor_diameter.py --label /path/to/mask.nii.gz

Whole task (writes a CSV next to it):
    python tumor_diameter.py --labels-dir <dir> --out <csv>

Programmatic use
----------------
    import nibabel as nib
    from tumor_diameter import case_metrics_from_nifti
    metrics = case_metrics_from_nifti('mask.nii.gz')

The metrics dict has keys: case, spacing_mm, n_fg_voxels, volume_cm3,
diameter_3d_mm, diameter_axial_mm.
"""
from __future__ import annotations

import argparse
import csv
import glob
import os
from dataclasses import dataclass, asdict
from multiprocessing import Pool
from typing import Iterable

import nibabel as nib
import numpy as np
from scipy import ndimage
from scipy.spatial import ConvexHull, QhullError


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def voxel_coords_to_physical(ijk: np.ndarray, affine: np.ndarray) -> np.ndarray:
    """Apply a 4x4 NIfTI affine to (N,3) integer voxel indices.

    Returns an (N,3) array of physical coordinates in millimetres.
    """
    homog = np.concatenate([ijk, np.ones((ijk.shape[0], 1), dtype=ijk.dtype)], axis=1)
    out = homog @ affine.T
    return out[:, :3]


def largest_pairwise_distance(points: np.ndarray) -> float:
    """Maximum pairwise Euclidean distance among (N,3) points.

    Uses the convex hull's vertices when N is large (which is almost always),
    falling back to a direct O(N^2) sweep for tiny point sets where ConvexHull
    refuses to build.
    """
    n = len(points)
    if n < 2:
        return 0.0
    # ConvexHull needs at least d+1 points to span a simplex; otherwise distances
    # are computed directly anyway.
    if n >= 4:
        try:
            hull = ConvexHull(points)
            hull_pts = points[hull.vertices]
        except QhullError:
            hull_pts = points
    else:
        hull_pts = points
    diffs = hull_pts[:, None, :] - hull_pts[None, :, :]
    d2 = (diffs ** 2).sum(axis=-1)
    return float(np.sqrt(d2.max()))


def largest_axial_diameter(mask3d: np.ndarray, affine: np.ndarray) -> float:
    """Max in-plane diameter across all axial slices of mask3d, in mm.

    The mask is assumed to be in (X, Y, Z) order (the NIfTI default), with
    axial slices being the Z dimension.  Within a slice we work in the (X, Y)
    plane mapped to physical coordinates via the affine, then run a 2D
    ConvexHull (rather than a 3D one on a degenerate plane, which scipy/Qhull
    handles poorly and was the per-case bottleneck on glioma masks).
    """
    best = 0.0
    for z in range(mask3d.shape[2]):
        sl = mask3d[:, :, z]
        if sl.sum() == 0:
            continue
        ij = np.argwhere(sl > 0)
        ijk = np.concatenate(
            [ij, np.full((ij.shape[0], 1), z, dtype=ij.dtype)], axis=1
        )
        phys = voxel_coords_to_physical(ijk, affine)
        pts2d = phys[:, :2]
        d = largest_pairwise_distance(pts2d)
        if d > best:
            best = d
    return best


def largest_connected_component(mask3d: np.ndarray) -> np.ndarray:
    """Return the binary mask of the single largest 26-connected component.

    If the mask is empty, returns it unchanged.  Equal-sized ties are resolved
    by component index (stable).
    """
    if mask3d.sum() == 0:
        return mask3d
    structure = np.ones((3, 3, 3), dtype=np.uint8)
    labelled, n = ndimage.label(mask3d, structure=structure)
    if n <= 1:
        return mask3d.astype(np.uint8)
    sizes = ndimage.sum(mask3d, labelled, index=np.arange(1, n + 1))
    keep = int(np.argmax(sizes)) + 1
    return (labelled == keep).astype(np.uint8)


# ---------------------------------------------------------------------------
# Top-level metric computation
# ---------------------------------------------------------------------------

@dataclass
class CaseMetrics:
    case: str
    spacing_mm: tuple
    n_fg_voxels: int
    n_largest_component: int
    volume_cm3: float
    diameter_3d_mm: float
    diameter_axial_mm: float


def case_metrics_from_arrays(
    mask3d: np.ndarray,
    affine: np.ndarray,
    spacing: tuple,
    case_id: str = '',
    use_largest_component: bool = True,
) -> CaseMetrics:
    """Compute size metrics from a 3D mask + 4x4 affine + voxel spacing tuple."""
    mask3d = (mask3d > 0).astype(np.uint8)
    n_fg = int(mask3d.sum())
    if n_fg == 0:
        return CaseMetrics(case_id, tuple(float(x) for x in spacing), 0, 0,
                           0.0, 0.0, 0.0)
    work = largest_connected_component(mask3d) if use_largest_component else mask3d
    n_lcc = int(work.sum())
    vol_mm3 = float(n_fg) * float(np.prod(spacing))
    ij_all = np.argwhere(work > 0)
    phys = voxel_coords_to_physical(ij_all, affine)
    d3 = largest_pairwise_distance(phys)
    d_ax = largest_axial_diameter(work, affine)
    return CaseMetrics(
        case=case_id,
        spacing_mm=tuple(float(x) for x in spacing),
        n_fg_voxels=n_fg,
        n_largest_component=n_lcc,
        volume_cm3=vol_mm3 / 1000.0,
        diameter_3d_mm=d3,
        diameter_axial_mm=d_ax,
    )


def case_metrics_from_nifti(label_path: str, use_largest_component: bool = True) -> CaseMetrics:
    img = nib.load(label_path)
    mask = (img.get_fdata() > 0).astype(np.uint8)
    spacing = tuple(float(x) for x in img.header.get_zooms()[:3])
    cid = os.path.basename(label_path).replace('.nii.gz', '').replace('.nii', '')
    return case_metrics_from_arrays(mask, img.affine, spacing,
                                    case_id=cid,
                                    use_largest_component=use_largest_component)


def metrics_to_dict(m: CaseMetrics) -> dict:
    d = asdict(m)
    d['spacing_mm'] = ','.join(f'{s:.4f}' for s in m.spacing_mm)
    return d


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def iter_label_files(labels_dir: str) -> Iterable[str]:
    for p in sorted(glob.glob(os.path.join(labels_dir, '*.nii.gz'))):
        yield p
    for p in sorted(glob.glob(os.path.join(labels_dir, '*.nii'))):
        yield p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--label', help='single label NIfTI to inspect')
    ap.add_argument('--labels-dir', help='directory of label NIfTIs')
    ap.add_argument('--out', default=None, help='output CSV path (for --labels-dir)')
    ap.add_argument('--all-components', action='store_true',
                    help='diameter uses ALL foreground voxels, not just the '
                         'largest connected component (matches RECIST poorly '
                         'when the tumor is multifocal).')
    ap.add_argument('--workers', type=int, default=1,
                    help='process pool size for --labels-dir mode. '
                         'Glioma-sized masks take ~10-20s each so '
                         'parallelism helps on the standard partition.')
    args = ap.parse_args()

    use_lcc = not args.all_components

    if args.label:
        m = case_metrics_from_nifti(args.label, use_largest_component=use_lcc)
        print(f'case: {m.case}')
        print(f'  spacing (mm): {m.spacing_mm}')
        print(f'  fg voxels: {m.n_fg_voxels}  (largest component: {m.n_largest_component})')
        print(f'  volume: {m.volume_cm3:.3f} cm^3')
        print(f'  3D longest diameter: {m.diameter_3d_mm:.2f} mm')
        print(f'  axial RECIST diameter: {m.diameter_axial_mm:.2f} mm')
        return

    if args.labels_dir:
        out = args.out or os.path.join(args.labels_dir, 'tumor_diameter.csv')
        paths = list(iter_label_files(args.labels_dir))
        if not paths:
            print(f'no NIfTI labels in {args.labels_dir}')
            return
        if args.workers > 1:
            with Pool(args.workers) as pool:
                metrics_list = pool.starmap(
                    case_metrics_from_nifti,
                    [(p, use_lcc) for p in paths],
                )
        else:
            metrics_list = [case_metrics_from_nifti(p, use_largest_component=use_lcc)
                            for p in paths]
        rows = []
        for m in metrics_list:
            rows.append(metrics_to_dict(m))
            print(f'{m.case:30}  vol={m.volume_cm3:7.2f}cm3  '
                  f'D3D={m.diameter_3d_mm:6.1f}mm  '
                  f'D_ax={m.diameter_axial_mm:6.1f}mm')
        keys = list(rows[0].keys())
        with open(out, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(rows)
        print(f'\nwrote {len(rows)} rows -> {out}')
        return

    ap.print_help()


if __name__ == '__main__':
    main()
