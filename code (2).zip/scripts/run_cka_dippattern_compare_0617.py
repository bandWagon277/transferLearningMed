"""Compare CKA-vs-epoch trajectory across three source-target similarity levels
(meetplan0617 follow-up).

Three transfer scenarios:
  (A) Random -> BraTS21        — no relation source; expected to start far,
                                 climb monotonically (or dip-then-climb if the
                                 early-reorganization phase is universal).
  (B) MSD-Lung -> BraTS21      — cross-organ; the original observation (dip at
                                 D1_up_outer to 0.10 at ep 10, then rebound).
  (C) BraTS21 -> BraTS24       — same modality, similar adult-glioma cohort;
                                 expected: trajectory near 1.0 throughout
                                 (encoder barely reorganizes).

For each scenario, we compute linear CKA between the SOURCE-side encoder f_S
(or random init for A) and the FINE-TUNED-AT-EPOCH-N model. Layers covered:
L0_stem..D2_up_inner (7 layers per the existing _full_ladder_modules ladder).

Probes: 40 BraTS21-FLAIR images (deterministic from seed=42), matching the
existing fine-grid trajectory at runs/cka_finegrid_trajectory_0616.json.

Output:
  runs/cka_dippattern_compare_0617.json
  runs/figures/0617/cka_dippattern_compare.png

The figure is a 7-panel grid (one per layer) with 3 lines per panel.
"""
from __future__ import annotations
import glob
import json
import os
import re
import sys

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

import numpy as np
import torch

from affinity import (
    DatasetSpec, list_cases, linear_cka, _extract_layer_ladder_features,
)


REPO = os.path.dirname(THIS)
N_PROBES = 40
SEED = 42

# Source-side checkpoints used as f_S for each scenario.
F_S_RANDOM = None  # signals random-init for _extract_layer_ladder_features
F_S_MSD = os.path.join(
    REPO, 'code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt')
F_S_BRATS21 = os.path.join(
    REPO, 'code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt')

# Trajectory runs: (run_dir, source_ckpt, probe_layout, probe_root, in_channels)
TRAJS = {
    'random -> BraTS21': (
        'code/pretrained/brats_flair_pretrain/brats_scratch_finegrid_0617',
        F_S_RANDOM, 'brats_flair', 'data/BraTS2021_Training'),
    'MSD -> BraTS21':    (
        'code/pretrained/brats_flair_pretrain/brats_from_msd_finegrid',
        F_S_MSD, 'brats_flair', 'data/BraTS2021_Training'),
    'BraTS21 -> BraTS24': (
        'code/pretrained/brats2024_pretrain/from_brats21_full_finegrid_0617',
        F_S_BRATS21, 'brats24_clean',
        'data/BraTS2024_AdultGlioma_PostTreatment'),
}


def gather_probes(layout, root, n):
    spec = DatasetSpec(name='probe', root=os.path.join(REPO, root), layout=layout)
    cases = list_cases(spec)
    rng = np.random.default_rng(SEED)
    idx = rng.permutation(len(cases))[:n]
    return [cases[i]['image'] for i in sorted(idx.tolist())]


def epoch_from_name(name: str):
    m = re.match(r'checkpoint_epoch_0*(\d+)\.pt', name)
    if m:
        return int(m.group(1))
    if name == 'best.pt':
        return None
    if name == 'last.pt':
        return -1
    return None


def main():
    out_json = os.path.join(REPO, 'runs/cka_dippattern_compare_0617.json')
    fig_path = os.path.join(REPO, 'runs/figures/0617/cka_dippattern_compare.png')
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    os.makedirs(os.path.dirname(fig_path), exist_ok=True)

    # For the BraTS24 trajectory we need BraTS24 probes (since the trajectory
    # was trained on BraTS24 and we want to capture features under the target
    # distribution). For the other two trajectories the probes are BraTS21.
    probe_cache = {
        'brats_flair': gather_probes('brats_flair', 'data/BraTS2021_Training', N_PROBES),
    }

    # For 'brats24_clean' layout we need a custom probe-gatherer because
    # affinity.list_cases doesn't know that layout.
    def gather_brats24_probes(n):
        import glob
        roots = [os.path.join(REPO, 'data/BraTS2024_AdultGlioma_PostTreatment/training_data1_v2'),
                 os.path.join(REPO, 'data/BraTS2024_AdultGlioma_PostTreatment/training_data_additional')]
        ids = []
        for r in roots:
            for d in sorted(glob.glob(os.path.join(r, 'BraTS-GLI-*-101'))):
                cid = os.path.basename(d)
                m = re.match(r'BraTS-GLI-(\d+)-101$', cid)
                if not m:
                    continue
                if int(m.group(1)) < 2000:
                    continue
                t2f = os.path.join(d, f'{cid}-t2f.nii.gz')
                if os.path.isfile(t2f):
                    ids.append(t2f)
        rng = np.random.default_rng(SEED)
        idx = rng.permutation(len(ids))[:n]
        return [ids[i] for i in sorted(idx.tolist())]

    probe_cache['brats24_clean'] = gather_brats24_probes(N_PROBES)
    for k, v in probe_cache.items():
        print(f'[probes] {k}: n={len(v)}')

    # For each trajectory, compute source features once + per-epoch features.
    results = {}
    for tag, (rel, src_ckpt, layout, _root) in TRAJS.items():
        run_dir = os.path.join(REPO, rel)
        if not os.path.isdir(run_dir):
            print(f'[skip] {tag}: run dir missing {run_dir}')
            continue
        probes = probe_cache['brats_flair' if layout == 'brats_flair' else 'brats24_clean']

        print(f'\n=== {tag} ===')
        print(f'[source] {src_ckpt or "RANDOM_INIT"}')
        feats_s = _extract_layer_ladder_features(
            ckpt_path=src_ckpt, probe_paths=probes,
            in_channels=1, out_channels=1, layout=layout,
            random_init_seed=0,
        )

        ckpts = sorted(glob.glob(os.path.join(run_dir, 'checkpoint_epoch_*.pt')))
        for extra in ('best.pt', 'last.pt'):
            p = os.path.join(run_dir, extra)
            if os.path.isfile(p):
                ckpts.append(p)
        if not ckpts:
            print(f'  no checkpoints in {run_dir}')
            continue

        epoch_recs = []
        for ck in ckpts:
            name = os.path.basename(ck)
            ep = epoch_from_name(name)
            print(f'  {name} (ep={ep})')
            feats_t = _extract_layer_ladder_features(
                ckpt_path=ck, probe_paths=probes,
                in_channels=1, out_channels=1, layout=layout,
            )
            per_layer = {L: float(linear_cka(feats_s[L], feats_t[L]))
                         for L in feats_s}
            epoch_recs.append({'ckpt_name': name, 'epoch': ep,
                               'cka_per_layer': per_layer})
        results[tag] = {
            'run_dir': rel,
            'src_ckpt': src_ckpt or 'RANDOM_INIT',
            'probe_layout': layout,
            'epochs': epoch_recs,
        }

    with open(out_json, 'w') as f:
        json.dump({'n_probes': N_PROBES, 'seed': SEED, 'runs': results}, f, indent=2)
    print(f'\n[saved] {out_json}')

    # Plot 7-panel grid.
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        return

    if not results:
        print('[plot] nothing to plot')
        return
    layers = list(next(iter(results.values()))['epochs'][0]['cka_per_layer'].keys())
    fig, axes = plt.subplots(2, 4, figsize=(16, 8), sharex=True, sharey=True)
    axes = axes.flatten()
    colors = {
        'random -> BraTS21':   '#E45756',
        'MSD -> BraTS21':      '#F58518',
        'BraTS21 -> BraTS24':  '#4C78A8',
    }
    for ax, L in zip(axes, layers):
        for tag in results:
            recs = [e for e in results[tag]['epochs']
                    if e['epoch'] is not None and e['epoch'] >= 0]
            recs.sort(key=lambda r: r['epoch'])
            if not recs:
                continue
            xs = [r['epoch'] for r in recs]
            ys = [r['cka_per_layer'][L] for r in recs]
            ax.plot(xs, ys, marker='o', label=tag, color=colors.get(tag, 'k'))
        ax.set_title(L)
        ax.set_ylim(-0.05, 1.05)
        ax.grid(alpha=0.3)
    for ax in axes[-4:]:
        ax.set_xlabel('epoch')
    for ax in axes[::4]:
        ax.set_ylabel('CKA(f_S, f_S->T,e)')
    axes[0].legend(loc='lower right', fontsize='small')
    fig.suptitle('CKA-vs-epoch dip pattern across source-target similarity '
                 '(meetplan0617: similar / cross-organ / no-relation)')
    fig.tight_layout()
    fig.savefig(fig_path, dpi=130, bbox_inches='tight')
    print(f'[saved] {fig_path}')


if __name__ == '__main__':
    main()
