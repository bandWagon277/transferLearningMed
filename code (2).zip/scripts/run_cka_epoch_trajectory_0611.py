"""Per-epoch CKA trajectory for the MSD->BraTS runs that retained
intermediate checkpoints.

Operationalizes meetplan0611 item 4 (record change over epochs).
For each available checkpoint_epoch_<E>.pt in a transfer run, compute
layer-wise CKA(f_S, f_{S->T,E}) on 40 target probes. Output:
runs/cka_epoch_trajectory_0611.json -- for a CKA-vs-epoch line plot.

Available coverage (verified 2026-06-11):
  brats_from_msd_v1       : 5 epoch checkpoints
  brats_from_msd_freeze1  : 5 epoch checkpoints
  (the BraTS->MSD direction's intermediate ckpts were cleaned up by
  the oktaykurt training script and are not available.)
"""
from __future__ import annotations
import glob
import json
import os
import re
import sys

THIS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS)

import numpy as np  # noqa: E402

from affinity import (  # noqa: E402
    DatasetSpec, list_cases, linear_cka, _extract_layer_ladder_features,
)

REPO = os.path.dirname(THIS)
N_PROBES = 40

F_S_MSD = os.path.join(REPO,
    'code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt')

TRAJ_RUNS = {
    'MSD_to_BraTS/full':    'code/pretrained/brats_flair_pretrain/brats_from_msd_v1',
    'MSD_to_BraTS/freeze1': 'code/pretrained/brats_flair_pretrain/brats_from_msd_freeze1',
}


def _gather_probes(layout: str, root: str, n: int) -> list[str]:
    spec = DatasetSpec(name='probe', root=root, layout=layout)
    cases = list_cases(spec)
    rng = np.random.default_rng(42)
    idx = rng.permutation(len(cases))[:n]
    return [cases[i]['image'] for i in sorted(idx.tolist())]


def main():
    out_path = os.path.join(REPO, 'runs/cka_epoch_trajectory_0611.json')
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    brats_probes = _gather_probes('brats_flair',
        os.path.join(REPO, 'data/BraTS2021_Training'), N_PROBES)
    print(f'[probes] {len(brats_probes)} BraTS')

    feats_s = _extract_layer_ladder_features(
        ckpt_path=F_S_MSD, probe_paths=brats_probes,
        in_channels=1, out_channels=1, layout='brats_flair',
    )

    results = {}
    for tag, rel in TRAJ_RUNS.items():
        run_dir = os.path.join(REPO, rel)
        ckpts = sorted(glob.glob(os.path.join(run_dir, 'checkpoint_epoch_*.pt')))
        ckpts += [os.path.join(run_dir, 'best.pt')]   # include best as "endpoint"
        epochs = []
        for ck in ckpts:
            name = os.path.basename(ck)
            m = re.match(r'checkpoint_epoch_0*(\d+)\.pt', name)
            ep = int(m.group(1)) if m else None  # None -> best
            print(f'[{tag}] {name} (ep={ep})')
            feats_t = _extract_layer_ladder_features(
                ckpt_path=ck, probe_paths=brats_probes,
                in_channels=1, out_channels=1, layout='brats_flair',
            )
            per_layer = {L: linear_cka(feats_s[L], feats_t[L])
                         for L in feats_s}
            epochs.append({
                'ckpt_name': name, 'epoch': ep,
                'cka_per_layer': per_layer,
            })
        results[tag] = epochs

    with open(out_path, 'w') as f:
        json.dump({
            'f_s': F_S_MSD,
            'n_probes': N_PROBES,
            'probe_paths': brats_probes,
            'runs': results,
        }, f, indent=2)
    print(f'\n[saved] {out_path}')

    layers = list(feats_s.keys())
    for tag in results:
        print(f'\n=== {tag} ===')
        print(f'{"epoch":>8}', *[f'{L:>14}' for L in layers])
        for ep in results[tag]:
            row = [f'{ep["cka_per_layer"][L]:>14.3f}' for L in layers]
            label = f'{ep["epoch"]}' if ep['epoch'] is not None else 'best'
            print(f'{label:>8}', *row)


if __name__ == '__main__':
    main()
