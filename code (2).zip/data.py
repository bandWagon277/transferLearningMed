"""Per-dataset case enumeration, transform pipelines, and K-fold splits.

Each dataset is represented by a DatasetBuilder subclass. The public surface
is small: list_cases() returns dicts of file paths, train_transforms() and
val_transforms() return MONAI Compose objects, fold_split() returns the
train/val case lists for a given K-fold index.

All datasets sit under the same root /nfs/turbo/jiankanggroup/gengyh/transferMRI/data
on the working filesystem. Override the root in the constructor if running
elsewhere.
"""
from __future__ import annotations

import glob
import os
import random
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass

import monai.transforms as T


DATA_ROOT_DEFAULT = '/nfs/turbo/jiankanggroup/gengyh/transferMRI/data'


@dataclass
class DatasetBuilder(ABC):
    root: str = DATA_ROOT_DEFAULT
    roi: tuple[int, int, int] = (128, 128, 128)
    rotation_deg: float = 30.0

    def __post_init__(self):
        # Subclasses override to set self.cases_root from self.root.
        self.cases_root = self.root

    @abstractmethod
    def list_cases(self) -> list[dict]:
        ...

    @abstractmethod
    def in_channels(self) -> int:
        ...

    @abstractmethod
    def out_channels(self) -> int:
        ...

    def fold_split(self, fold: int, n_folds: int = 5, seed: int = 42
                   ) -> tuple[list[dict], list[dict]]:
        cases = self.list_cases()
        rng = random.Random(seed)
        shuffled = list(cases)
        rng.shuffle(shuffled)
        n = len(shuffled)
        size = n // n_folds
        lo = fold * size
        hi = (fold + 1) * size if fold < n_folds - 1 else n
        val = shuffled[lo:hi]
        train = shuffled[:lo] + shuffled[hi:]
        return train, val

    def train_transforms(self) -> T.Compose:
        return T.Compose(self._mri_or_ct_pipeline(training=True))

    def val_transforms(self) -> T.Compose:
        return T.Compose(self._mri_or_ct_pipeline(training=False))

    def _mri_or_ct_pipeline(self, training: bool) -> list:
        """Base pipeline with the layout-specific intensity step overridden
        by subclasses via _intensity_steps()."""
        steps = [
            T.LoadImaged(keys=['image', 'label']),
            T.EnsureChannelFirstd(keys=['image', 'label']),
            T.EnsureTyped(keys=['image', 'label']),
            T.Orientationd(keys=['image', 'label'], axcodes='RAS'),
            T.Spacingd(keys=['image', 'label'], pixdim=(1.0, 1.0, 1.0),
                       mode=('bilinear', 'nearest')),
        ]
        steps.extend(self._intensity_steps())
        steps.append(T.CropForegroundd(keys=['image', 'label'],
                                       source_key='image', k_divisible=16))
        steps.append(T.SpatialPadd(keys=['image', 'label'],
                                   spatial_size=self.roi))
        if training:
            rad = self.rotation_deg * 3.14159 / 180.0
            steps.extend([
                T.RandSpatialCropd(keys=['image', 'label'],
                                   roi_size=self.roi, random_size=False),
                T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=0),
                T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=1),
                T.RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=2),
                T.RandRotated(keys=['image', 'label'],
                              range_x=rad, range_y=rad, range_z=rad,
                              mode=('bilinear', 'nearest'),
                              padding_mode='zeros', prob=0.5),
                T.RandScaleIntensityd(keys='image', factors=0.1, prob=1.0),
                T.RandShiftIntensityd(keys='image', offsets=0.1, prob=1.0),
            ])
        return steps

    def _intensity_steps(self) -> list:
        """Default to MRI-style foreground z-score; CT datasets override."""
        return [T.NormalizeIntensityd(keys='image', nonzero=True, channel_wise=True)]


class BraTS2021FlairBinary(DatasetBuilder):
    """BraTS 2021 with FLAIR as the single input modality and binary WT label."""

    def __post_init__(self):
        self.cases_root = os.path.join(self.root, 'BraTS2021_Training')

    def list_cases(self) -> list[dict]:
        cases = []
        for d in sorted(glob.glob(os.path.join(self.cases_root, 'BraTS2021_*'))):
            cid = os.path.basename(d)
            flair = os.path.join(d, f'{cid}_flair.nii.gz')
            seg = os.path.join(d, f'{cid}_seg.nii.gz')
            if os.path.exists(flair) and os.path.exists(seg):
                cases.append({'image': flair, 'label': seg, 'id': cid})
        return cases

    def in_channels(self) -> int:
        return 1

    def out_channels(self) -> int:
        return 1

    def _intensity_steps(self) -> list:
        return [
            BinarizeLabel(keys='label'),
            T.NormalizeIntensityd(keys='image', nonzero=True, channel_wise=True),
        ]


class BraTS2024GLIClean(DatasetBuilder):
    """BraTS 2024 GLI post-treatment, after the 38-patient overlap filter.

    Drops patient IDs below 2000 (the BraTS21 UCSF overlap range). Keeps one
    canonical -101 (or earliest available) post-treatment timepoint per
    remaining patient.
    """

    PATIENT_ID_THRESHOLD = 2000

    def __post_init__(self):
        self.cases_root = os.path.join(
            self.root, 'BraTS2024_AdultGlioma_PostTreatment')

    def list_cases(self) -> list[dict]:
        regex = re.compile(r'BraTS-GLI-(\d+)-(\d+)$')
        per_patient: dict[int, list[tuple[int, str]]] = {}
        for sub in ('training_data1_v2', 'training_data_additional'):
            sub_root = os.path.join(self.cases_root, sub)
            if not os.path.isdir(sub_root):
                continue
            for entry in os.listdir(sub_root):
                m = regex.match(entry)
                if not m:
                    continue
                patient, tp = int(m.group(1)), int(m.group(2))
                if patient < self.PATIENT_ID_THRESHOLD or tp < 101:
                    continue
                per_patient.setdefault(patient, []).append(
                    (tp, os.path.join(sub_root, entry)))
        cases = []
        for patient, tps in per_patient.items():
            tps.sort()
            tp, case_dir = tps[0]
            cid = os.path.basename(case_dir)
            flair = os.path.join(case_dir, f'{cid}-t2f.nii.gz')
            seg = os.path.join(case_dir, f'{cid}-seg.nii.gz')
            if os.path.exists(flair) and os.path.exists(seg):
                cases.append({'image': flair, 'label': seg, 'id': cid})
        cases.sort(key=lambda c: c['id'])
        return cases

    def in_channels(self) -> int:
        return 1

    def out_channels(self) -> int:
        return 1

    def _intensity_steps(self) -> list:
        return [
            BinarizeLabel(keys='label'),
            T.NormalizeIntensityd(keys='image', nonzero=True, channel_wise=True),
        ]


class MSDTask06Lung(DatasetBuilder):
    """MSD Task06 Lung: chest CT, binary lung tumor."""

    def __post_init__(self):
        self.cases_root = os.path.join(self.root, 'MSD_Task06_Lung/Task06_Lung')

    def list_cases(self) -> list[dict]:
        cases = []
        for img in sorted(glob.glob(os.path.join(self.cases_root, 'imagesTr', '*.nii.gz'))):
            if os.path.basename(img).startswith('._'):
                continue
            lbl = os.path.join(self.cases_root, 'labelsTr', os.path.basename(img))
            if os.path.exists(lbl):
                cases.append({'image': img, 'label': lbl,
                              'id': os.path.basename(img).replace('.nii.gz', '')})
        return cases

    def in_channels(self) -> int:
        return 1

    def out_channels(self) -> int:
        return 1

    def _intensity_steps(self) -> list:
        return [
            T.ScaleIntensityRanged(keys='image', a_min=-1000, a_max=300,
                                   b_min=0.0, b_max=1.0, clip=True),
        ]


class QINLungCT(DatasetBuilder):
    """QIN Lung CT (47 patients, chest CT, binary tumor)."""

    def __post_init__(self):
        self.cases_root = os.path.join(self.root, 'qin_lung_ct')

    def list_cases(self) -> list[dict]:
        cases = []
        for d in sorted(glob.glob(os.path.join(self.cases_root, '*'))):
            if not os.path.isdir(d):
                continue
            img = os.path.join(d, 'image.nii.gz')
            lbl = os.path.join(d, 'label.nii.gz')
            if os.path.exists(img) and os.path.exists(lbl):
                cases.append({'image': img, 'label': lbl,
                              'id': os.path.basename(d)})
        return cases

    def in_channels(self) -> int:
        return 1

    def out_channels(self) -> int:
        return 1

    def _intensity_steps(self) -> list:
        return [
            T.ScaleIntensityRanged(keys='image', a_min=-1000, a_max=300,
                                   b_min=0.0, b_max=1.0, clip=True),
        ]


class BinarizeLabel(T.MapTransform):
    """Collapse a multi-class BraTS segmentation to binary whole-tumor."""
    def __call__(self, data):
        d = dict(data)
        for key in self.key_iterator(d):
            d[key] = (d[key] > 0).float()
        return d
