"""Linear CKA with null-correction and bootstrap CIs.

Kornblith et al. 2019 HSIC form. Cross-checked against the open-source
reference at https://github.com/RistoAle97/centered-kernel-alignment;
both implementations agree to floating-point precision on identical inputs.

The companion debiased/null-correction recipe follows Murphy et al. 2024,
which shows that biased linear CKA inflates toward 1 in the d >> n regime
that this project lives in.
"""
from __future__ import annotations

import numpy as np


class CKA:
    """Linear CKA for (n_probes, feature_dim) feature matrices."""

    @staticmethod
    def linear(X: np.ndarray, Y: np.ndarray) -> float:
        Xc = X - X.mean(axis=0, keepdims=True)
        Yc = Y - Y.mean(axis=0, keepdims=True)
        num = float(np.linalg.norm(Yc.T @ Xc, ord='fro') ** 2)
        den_x = float(np.linalg.norm(Xc.T @ Xc, ord='fro'))
        den_y = float(np.linalg.norm(Yc.T @ Yc, ord='fro'))
        return num / (den_x * den_y + 1e-12)

    @staticmethod
    def gram(X: np.ndarray, Y: np.ndarray) -> float:
        """Gram-form linear CKA. Equivalent to .linear but n x n math;
        prefer this when n << feature_dim."""
        n = X.shape[0]
        H = np.eye(n) - np.ones((n, n)) / n
        Kx = H @ (X @ X.T) @ H
        Ky = H @ (Y @ Y.T) @ H
        num = float((Kx * Ky).sum())
        den = float(np.sqrt((Kx * Kx).sum() * (Ky * Ky).sum()))
        return num / (den + 1e-12)

    @classmethod
    def metric_audit(cls, X: np.ndarray, Y: np.ndarray,
                     n_boot: int = 200, n_perm: int = 200, seed: int = 0) -> dict:
        """Run CKA, Procrustes shape distance, and Spearman RSA on the same
        pair. Used in the 2026-06-11 multi-metric audit table (Codex
        methodology consult)."""
        return {
            'cka': cls.with_null(X, Y, n_boot=n_boot, n_perm=n_perm, seed=seed),
            'procrustes': procrustes_shape_distance(X, Y),
            'rsa': rsa_spearman(X, Y),
        }

    @classmethod
    def with_null(cls, X: np.ndarray, Y: np.ndarray,
                  n_boot: int = 200, n_perm: int = 200, seed: int = 0) -> dict:
        """Point CKA plus case-bootstrap CI and row-permutation null.

        Returns a dict with the raw point estimate, the 2.5/97.5 quantile
        case-bootstrap interval, the median null, and the null-corrected
        score R = (cka - null_median) / (1 - null_median).
        """
        rng = np.random.default_rng(seed)
        n = X.shape[0]
        point = cls.linear(X, Y)
        boot = np.empty(n_boot)
        for b in range(n_boot):
            idx = rng.integers(0, n, n)
            boot[b] = cls.linear(X[idx], Y[idx])
        ci_lo, ci_hi = np.quantile(boot, [0.025, 0.975])
        null = np.empty(n_perm)
        for k in range(n_perm):
            null[k] = cls.linear(X, Y[rng.permutation(n)])
        null_med = float(np.median(null))
        return {
            'cka': float(point),
            'cka_ci': (float(ci_lo), float(ci_hi)),
            'null_median': null_med,
            'cka_null_corrected': (point - null_med) / (1 - null_med + 1e-12),
            'p_value': float((null >= point).mean()),
        }


def procrustes_shape_distance(X: np.ndarray, Y: np.ndarray) -> dict:
    """Williams 2021 orthogonal Procrustes shape distance on the centered,
    Frobenius-normalized feature matrices. Returns the squared distance
    d_P^2 = 2 - 2 * ||X^T Y||_nuc, the corresponding distance, and the
    Procrustes similarity (the nuclear norm, in [0, 1])."""
    Xc = X - X.mean(axis=0, keepdims=True)
    Yc = Y - Y.mean(axis=0, keepdims=True)
    nX = np.linalg.norm(Xc, ord='fro')
    nY = np.linalg.norm(Yc, ord='fro')
    if nX < 1e-12 or nY < 1e-12:
        return {'d_procrustes': float('nan'), 'sim_procrustes': float('nan')}
    Xn, Yn = Xc / nX, Yc / nY
    nuc = float(np.linalg.norm(Xn.T @ Yn, ord='nuc'))
    return {
        'd_procrustes': float(max(0.0, 2.0 - 2.0 * nuc) ** 0.5),
        'sim_procrustes': nuc,
    }


def rsa_spearman(X: np.ndarray, Y: np.ndarray) -> dict:
    """Spearman correlation between within-encoder cosine-distance RDMs.
    Captures whether two encoders organize the same probes similarly,
    invariant to feature basis on either side.
    """
    from scipy.stats import spearmanr

    def rdm(M):
        Mn = M / (np.linalg.norm(M, axis=1, keepdims=True) + 1e-12)
        sim = Mn @ Mn.T
        iu = np.triu_indices(M.shape[0], k=1)
        return 1.0 - sim[iu]

    r, p = spearmanr(rdm(X), rdm(Y))
    return {'rsa_spearman': float(r), 'p_value': float(p)}


def jon_metric(Za: np.ndarray, Zb: np.ndarray) -> dict:
    """Diagonal-minus-off-diagonal cosine similarity between two encoders'
    per-probe embeddings (the project's first cross-encoder metric, 06-03).
    Positive means the two encoders agree on which probes are similar.
    """
    Za = Za / (np.linalg.norm(Za, axis=1, keepdims=True) + 1e-12)
    Zb = Zb / (np.linalg.norm(Zb, axis=1, keepdims=True) + 1e-12)
    sim = Za @ Zb.T
    n = sim.shape[0]
    diag = float(np.mean(np.diag(sim)))
    off = float((sim.sum() - np.trace(sim)) / (n * (n - 1)))
    return {'diag': diag, 'off_diag': off, 'gap': diag - off}


def orthohash_metric(Za: np.ndarray, Zb: np.ndarray, T: float | None = None) -> dict:
    """OrthoHash-style InfoNCE log-likelihood (Hoe NeurIPS 2021).

    For row-normalized embeddings Za, Zb of shape (N, d), the cosine
    similarity matrix S_ij = (1/T) * cos(z_a^i, z_b^j) defines a softmax
    classification over distractor probes. L_OH is the mean negative
    log-likelihood of the diagonal; acc@1 is the fraction of probes whose
    diagonal wins; log_odds_advantage is mean(log P_diag) - log(1/N).
    """
    Za = Za / (np.linalg.norm(Za, axis=1, keepdims=True) + 1e-12)
    Zb = Zb / (np.linalg.norm(Zb, axis=1, keepdims=True) + 1e-12)
    N, d = Za.shape
    if T is None:
        T = 1.0 / (d ** 0.5)
    sim = (Za @ Zb.T) / T
    log_softmax = sim - np.log(np.exp(sim).sum(axis=1, keepdims=True))
    diag = np.diag(log_softmax)
    L_OH = float(-np.mean(diag))
    pred = np.argmax(sim, axis=1)
    acc1 = float(np.mean(pred == np.arange(N)))
    return {
        'L_OH': L_OH,
        'accuracy_at_1': acc1,
        'log_odds_advantage': float(np.mean(diag) - np.log(1.0 / N)),
    }
