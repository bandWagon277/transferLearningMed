# Code

Four modules. Each is meant to be readable end-to-end.

cka.py defines the linear CKA estimator, the Gram-form alternative for
large feature dimensions, a method that returns the raw point estimate
together with a case-bootstrap confidence interval, a row-permutation null,
and the null-corrected score R = (CKA - median_null) / (1 - median_null).
The same file holds the companion metrics used in the earlier result
sections of results.md: jon_metric and orthohash_metric for cross-encoder
embedding alignment (used in the 2026-06-03 and 2026-06-05 tables), and
procrustes_shape_distance plus rsa_spearman for the multi-metric audit
in the 2026-06-11 row.

extract.py defines a FeatureLadder class that hooks the seven canonical
layer positions on a MONAI 3D U-Net (stem, three downsample blocks, the
bottleneck, two decoder upsample blocks). It also has small helpers for
building the U-Net at the channel ladder used in the project and for
loading checkpoints under DDP-vs-plain key conventions.

experiments.py wraps three workflows as classes. EpochTrajectory iterates
over checkpoint_epoch_*.pt files in a target run directory and computes the
CKA against a fixed source. PairwiseCKA computes the null-corrected CKA
across an arbitrary set of source/scratch/transfer checkpoints. The
RandomNetSimulation class sweeps input kind, normalization, and depth
through a small Conv3d-Norm-ReLU stack and reports CKA and null-corrected
R per cell. The simulation is what showed that the apparent "RI vs RI ~ 1"
finding is dominated by probe correlation rather than the architecture.

plotting.py contains two helpers used to draw the trajectory grid and the
simulation sweep panels in the figures directory.

training.py defines a Trainer class with the four configurations the project
uses: scratch, full fine-tune from a source checkpoint, encoder-frozen
fine-tune, and encoder-plus-bottleneck-frozen fine-tune. It encapsulates
weight loading (with DDP prefix normalization), freeze-depth selection,
DiceCE optimization, periodic checkpointing, and sliding-window
validation. The production scripts at ../code/pretrain_brats_flair.py and
../code/pretrain_oktaykurt.py are wider versions of the same flow with
K-fold splits and source-dispatch logic.

model.py defines the model factories used in the project. MonaiUNet3D
wraps monai.networks.nets.UNet with the channel ladder and normalization
choices used everywhere in this project. build_segresnet and
build_swinunetr are kept for historical reference because the May-13 v1
results in results.md compare against these architectures; the production
runs that followed used the MonaiUNet3D wrapper.

The actual architecture source is vendored under models/. That folder
contains the MONAI UNet implementation, the Generic_TransUNet_max_ppbp
class plus its ViT building blocks, and the nnU-Net Generic_UNet used in
the recipe-versus-architecture comparison. See models/README.md for the
provenance of each file.

data.py defines DatasetBuilder, an abstract base for per-dataset case
enumeration, transform pipelines, and K-fold patient-level splits. The
four concrete subclasses cover the datasets used in the project's MONAI
3D U-Net experiments: BraTS2021FlairBinary, BraTS2024GLIClean (with the
38-patient overlap filter and the canonical -101 timepoint rule),
MSDTask06Lung, and QINLungCT. MRI datasets default to per-volume
foreground z-score; CT datasets clip to HU [-1000, 300] and scale to
[0, 1]. The training transforms add the flip/rotate/intensity augmentation
stack used across the project.

cases.py wraps each transfer-learning configuration as an Experiment
dataclass. The named factory functions at the bottom of that file
(scratch_brats21, scratch_msd_lung, transfer_brats21_to_brats24,
transfer_brats21_to_msd_lung, transfer_msd_lung_to_brats21) match the
experimental cells that produced numbers in models.md and results.md.
Each one returns an Experiment whose .run() method trains the model and
writes the checkpoints. The MSD and BraTS source checkpoints used as
transfer-learning starts are referenced by their working-filesystem paths
at the top of cases.py.

The 3D TransUNet experiments use a different training framework (the
upstream nnU-Net trainer from the cloned Chen 2023 codebase). They are
documented in TRANSUNET.md in this folder rather than wrapped in a Trainer
class, because the training pipeline lives in ../code/external/3D-TransUNet
and is invoked via YAML configs and sbatch wrappers.

To reproduce any number in the results, build the U-Net via build_monai_unet,
load the corresponding checkpoint, and feed it through FeatureLadder.extract.
For per-epoch trajectories use EpochTrajectory; for pairwise comparisons use
PairwiseCKA. The simulation harness has its own data generator.
