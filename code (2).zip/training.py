"""Training and transfer-learning entry point for the MONAI 3D U-Net.

A single Trainer class wraps the four configurations used in the project:
scratch, pretrained-full-finetune, encoder-frozen, encoder-and-bottleneck
frozen. The data side uses MONAI transforms; the loss is DiceCE.

The full production scripts at code/pretrain_brats_flair.py and
code/pretrain_oktaykurt.py are wider (K-fold splits, multi-source dispatch,
checkpoint cleanup, augmentation knobs). Trainer here is a minimal core
that produces equivalent checkpoints when invoked with the same data + seed.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Iterable

import torch
from torch import nn
from torch.utils.data import DataLoader

from extract import build_monai_unet, load_state


@dataclass
class TrainConfig:
    out_dir: str
    epochs: int = 50
    batch_size: int = 2
    lr: float = 1e-4
    weight_decay: float = 1e-5
    channels: tuple[int, ...] = (32, 64, 128, 256, 512)
    in_channels: int = 1
    out_channels: int = 1
    norm: str = 'instance'
    freeze_depth: int = 0           # 0 full FT; 1 encoder frozen; 2 encoder+bottleneck
    pretrained_ckpt: str | None = None
    ckpt_every: int = 20
    seed: int = 42
    device: str = 'cuda'
    amp: bool = True


# Prefixes used by MONAI UNet state_dict to identify encoder + bottleneck.
# These match channels=(32,64,128,256,512), strides=(2,2,2,2), num_res_units=0.
ENCODER_PREFIXES = [
    'model.0.',
    'model.1.submodule.0.',
    'model.1.submodule.1.submodule.0.',
    'model.1.submodule.1.submodule.1.submodule.0.',
]
BOTTLENECK_PREFIX = 'model.1.submodule.1.submodule.1.submodule.1.'


class Trainer:
    """Train a 3D U-Net with optional pretrained init and freeze depth."""

    def __init__(self, cfg: TrainConfig,
                 train_loader: DataLoader, val_loader: DataLoader,
                 loss_fn: nn.Module | None = None):
        self.cfg = cfg
        self.train_loader = train_loader
        self.val_loader = val_loader

        torch.manual_seed(int(cfg.seed))
        self.device = torch.device(cfg.device if torch.cuda.is_available() else 'cpu')
        self.model = build_monai_unet(cfg.in_channels, cfg.out_channels,
                                      cfg.channels, cfg.norm).to(self.device)
        if cfg.pretrained_ckpt:
            report = load_state(self.model, cfg.pretrained_ckpt)
            print(f'[init] loaded {report["loaded"]}/{report["total"]} params '
                  f'from {cfg.pretrained_ckpt}')
        self._apply_freeze(cfg.freeze_depth)
        self.optimizer = torch.optim.Adam(
            [p for p in self.model.parameters() if p.requires_grad],
            lr=cfg.lr, weight_decay=cfg.weight_decay)
        if loss_fn is None:
            from monai.losses import DiceCELoss
            loss_fn = DiceCELoss(sigmoid=True)
        self.loss_fn = loss_fn.to(self.device)
        self.scaler = torch.cuda.amp.GradScaler(enabled=cfg.amp)
        os.makedirs(cfg.out_dir, exist_ok=True)

    def _apply_freeze(self, depth: int) -> None:
        if depth == 0:
            return
        freeze_prefixes = list(ENCODER_PREFIXES)
        if depth >= 2:
            freeze_prefixes.append(BOTTLENECK_PREFIX)
        n_frozen = 0
        for name, p in self.model.named_parameters():
            if any(name.startswith(pref) for pref in freeze_prefixes):
                p.requires_grad = False
                n_frozen += 1
        print(f'[freeze] depth={depth}, froze {n_frozen} parameter tensors')

    def fit(self) -> None:
        log_path = os.path.join(self.cfg.out_dir, 'metrics.jsonl')
        best_dice = -1.0
        for epoch in range(self.cfg.epochs):
            train_loss = self._train_epoch()
            val_dice = self._validate()
            self._log(log_path, epoch, train_loss, val_dice)
            if val_dice > best_dice:
                best_dice = val_dice
                self._save(os.path.join(self.cfg.out_dir, 'best.pt'),
                           epoch=epoch, val_dice=val_dice)
            self._save(os.path.join(self.cfg.out_dir, 'last.pt'),
                       epoch=epoch, val_dice=val_dice)
            if self.cfg.ckpt_every and (epoch + 1) % self.cfg.ckpt_every == 0:
                self._save(os.path.join(self.cfg.out_dir,
                                        f'checkpoint_epoch_{epoch+1:03d}.pt'),
                           epoch=epoch, val_dice=val_dice)
        print(f'[done] best val Dice = {best_dice:.4f}')

    def _train_epoch(self) -> float:
        self.model.train()
        total = 0.0
        n = 0
        for batch in self.train_loader:
            x = batch['image'].to(self.device, non_blocking=True)
            y = batch['label'].to(self.device, non_blocking=True)
            self.optimizer.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=self.cfg.amp):
                pred = self.model(x)
                loss = self.loss_fn(pred, y)
            self.scaler.scale(loss).backward()
            self.scaler.step(self.optimizer)
            self.scaler.update()
            total += float(loss.item()) * x.shape[0]
            n += x.shape[0]
        return total / max(n, 1)

    @torch.no_grad()
    def _validate(self) -> float:
        from monai.inferers import sliding_window_inference
        from monai.metrics import DiceMetric
        from monai.transforms import AsDiscrete, Activations
        self.model.eval()
        metric = DiceMetric(include_background=False, reduction='mean')
        post_pred = AsDiscrete(threshold=0.5)
        post_label = AsDiscrete()
        sigmoid = Activations(sigmoid=True)
        for batch in self.val_loader:
            x = batch['image'].to(self.device)
            y = batch['label'].to(self.device)
            roi = tuple(x.shape[-3:])
            pred = sliding_window_inference(x, roi, 1, self.model)
            pred = post_pred(sigmoid(pred))
            metric(y_pred=pred, y=post_label(y))
        score = float(metric.aggregate().item())
        metric.reset()
        return score

    def _save(self, path: str, epoch: int, val_dice: float) -> None:
        torch.save({
            'state_dict': self.model.state_dict(),
            'epoch': epoch,
            'val_dice': val_dice,
            'config': self.cfg.__dict__,
        }, path)

    def _log(self, log_path: str, epoch: int,
             train_loss: float, val_dice: float) -> None:
        rec = {'epoch': epoch, 'train_loss': train_loss, 'val_dice': val_dice}
        with open(log_path, 'a') as f:
            f.write(json.dumps(rec) + '\n')
        print(json.dumps(rec))


def scratch(cfg: TrainConfig, train_loader, val_loader) -> Trainer:
    """Equivalent to: pretrain from random init, no freezing."""
    cfg.pretrained_ckpt = None
    cfg.freeze_depth = 0
    return Trainer(cfg, train_loader, val_loader)


def transfer(cfg: TrainConfig, train_loader, val_loader,
             source_ckpt: str, freeze_depth: int = 0) -> Trainer:
    """Load source weights and fine-tune at the requested freeze depth."""
    cfg.pretrained_ckpt = source_ckpt
    cfg.freeze_depth = freeze_depth
    return Trainer(cfg, train_loader, val_loader)
