# TransUNet experiments

The 3D TransUNet experiments do not use the Trainer in training.py. They
use the upstream nnUNetTrainerV2_DDP from Chen et al. 2023 wrapped via
torchrun. The clone, with the project patches, lives at
../code/external/3D-TransUNet on the working filesystem.

Each TransUNet configuration is a YAML file plus a sbatch wrapper. The four
configurations that produced results in this project are:

| Config | YAML | Result |
|---|---|---|
| TransUNet scratch on Task006_Lung | lung_encoder_only_scratch.yaml | peak val Dice 0.838 at epoch 37 |
| TransUNet pretrain on Task500_BraTS2021 | brats_encoder_only_pretrain.yaml | peak val Dice 0.936 |
| TransUNet BraTS21 to MSD transfer | lung_encoder_only_transfer_full.yaml plus -pretrained_weights | peak val Dice 0.850 at epoch 37 |
| Generic_UNet (CNN) under nnU-Net recipe | lung_cnn_unet_scratch.yaml | peak val Dice 0.839 (recipe vs architecture control) |

The YAMLs are at ../code/external/3D-TransUNet/configs/TransferMRI/. The
sbatch wrappers are ../code/sbatch_transunet3d_*_0615.slurm and
../code/sbatch_cnn_unet_scratch_lung_0618.slurm.

Patches applied to the upstream clone (each is small and local to one file):

1. Removed an upstream debug print that referenced an undefined env var
   (default_configuration.py around line 67).
2. plans_per_stage index fallback for single-stage Task500
   (train.py around line 200).
3. torchrun --local-rank compatibility (train.py around line 109).
4. A tolerant load_pretrained_weights replacement inside train.py that
   does double-sided module. prefix normalization and shape-tolerant
   matching, so cross-task heads are skipped without raising
   (replaces the strict upstream loader from nnunet.run.load_pretrained_weights).
5. --extract_attention_out and --extract_conv_out flags in train.py that
   capture ViT attention or CNN features from N validation patches and
   write them to .npz, then exit. Used to produce
   data/cka_transunet_attention_0617.json and
   data/cka_transunet_conv_0619.json in this deliverable.
6. A Generic_UNet dispatch branch in
   nn_transunet/trainer/nnUNetTrainerV2_DDP.py that builds the nnU-Net
   plain CNN U-Net under the same trainer, so the recipe-vs-architecture
   comparison runs against an identical training pipeline.

To reproduce a TransUNet result:

    sbatch ../code/sbatch_transunet3d_scratch_lung_0615.slurm

To reproduce the recipe-vs-architecture control:

    sbatch ../code/sbatch_cnn_unet_scratch_lung_0618.slurm

To extract features for the conv-CKA comparison from three checkpoints and
then compute the null-corrected CKA:

    sbatch ../code/sbatch_cka_transunet_conv_analysis_0619.slurm
    sbatch ../code/sbatch_cka_transunet_conv_analysis_0619.slurm

The TransUNet attention-CKA from data/cka_transunet_attention_0617.json
uses the --extract_attention_out flag and an analogous SLURM wrapper at
../code/sbatch_transunet_attention_extract_0617.slurm.
