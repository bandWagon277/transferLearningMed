# Runnable examples for `deliverable/code/`

One example per module. Each example is self-contained and safe to run from
`deliverable/code/`. Smoke-tested end-to-end on this workstation (2026-06-30).

| Script | What it does | Runs on | Wall-clock |
|---|---|---|---|
| `example_model.py`       | Build `MonaiUNet3D`, print param count, forward 128^3 random tensor | CPU | ~10 s |
| `example_cka.py`         | All 6 metrics in `cka.py` on synthetic features; asserts CKA(X,X)=1 | CPU | ~3 s |
| `example_data.py`        | Enumerate cases + apply train pipeline on one case per dataset       | CPU + data | ~60 s |
| `example_extract.py`     | Load a UNet, hook the 7-layer ladder, extract features on 2 probes  | CPU or GPU | ~2 min CPU / 15 s GPU |
| `example_cases.py`       | Describe all 6 named `cases.py` experiment factories                | CPU (inspect); GPU (`--run`) | <1 s inspect |
| `example_experiments.py` | `EpochTrajectory` + `PairwiseCKA` on toy ckpts + tiny simulation    | CPU (with monkey-patch) or GPU | ~3 min CPU |
| `example_plotting.py`    | Render both `plotting.py` figures against synthetic JSONs           | CPU | ~2 s |
| `example_training.py`    | Full train loop wired to `training.scratch` / `training.transfer`   | **GPU required** | ~1-2 h per fold |

## How to run

```bash
cd /nfs/turbo/jiankanggroup/gengyh/transferMRI/deliverable/code
source /home/gengyh/miniconda3/etc/profile.d/conda.sh && conda activate medicaldiffusion

python examples/example_model.py
python examples/example_cka.py
python examples/example_data.py
python examples/example_plotting.py
python examples/example_cases.py
python examples/example_extract.py     # optionally: --ckpt /path/to/best.pt
python examples/example_experiments.py

# Training example (needs GPU):
python examples/example_training.py --mode scratch --out runs/msd_lung_scratch
python examples/example_training.py --mode transfer \
    --out runs/msd_lung_from_brats21 \
    --pretrained /nfs/turbo/jiankanggroup/gengyh/transferMRI/code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt
```

## Notes

- `example_experiments.py` monkey-patches `FeatureLadder.__init__` to fall back
  to CPU when no CUDA device is visible. This is a workaround for smoke-testing
  on the login node; the underlying `extract.FeatureLadder` still defaults to
  `device='cuda'` in the production code.
- `example_extract.py` and `example_training.py` are the only two that
  meaningfully benefit from a real GPU; the rest run in a few seconds on CPU.
- `example_plotting.py` writes its two demo PNGs into `examples/out/`.
