"""Example: build one Experiment for every named factory in cases.py and
show what it will train, without actually starting training.

Optional --run flag actually runs the experiment for a small number of epochs
(useful for a smoke test -- do NOT use to produce a reportable Dice).

Run:
    cd deliverable/code
    python examples/example_cases.py                    # inspect-only, no training
    python examples/example_cases.py --run --epochs 1   # 1-epoch smoke test
"""
from __future__ import annotations
import sys, os, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cases import (scratch_brats21, scratch_msd_lung, scratch_brats24_clean,
                    transfer_brats21_to_brats24, transfer_brats21_to_msd_lung,
                    transfer_msd_lung_to_brats21,
                    BRATS21_SCRATCH_CKPT, MSD_LUNG_SCRATCH_CKPT)


def summarize(exp):
    kind = "scratch" if exp.source_ckpt is None else \
           f"transfer freeze={exp.freeze_depth}"
    src  = exp.source_ckpt or "(random init)"
    tgt  = type(exp.target).__name__
    print(f"  name        : {exp.name}")
    print(f"    target    : {tgt}  (in={exp.target.in_channels()} out={exp.target.out_channels()})")
    print(f"    mode      : {kind}")
    print(f"    source_ckpt: {src}")
    print(f"    fold/epochs: {exp.fold}/{exp.epochs}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", action="store_true",
                    help="Actually run one small experiment (a smoke test).")
    ap.add_argument("--epochs", type=int, default=1)
    args = ap.parse_args()

    factories = [
        ("scratch_brats21",              scratch_brats21()),
        ("scratch_msd_lung",             scratch_msd_lung()),
        ("scratch_brats24_clean",        scratch_brats24_clean()),
        ("transfer_brats21_to_brats24",  transfer_brats21_to_brats24()),
        ("transfer_brats21_to_msd_lung", transfer_brats21_to_msd_lung()),
        ("transfer_msd_lung_to_brats21", transfer_msd_lung_to_brats21()),
    ]
    for tag, exp in factories:
        print(f"\n[{tag}]")
        summarize(exp)

    print(f"\nSource-checkpoint constants (used as defaults):")
    print(f"  BRATS21_SCRATCH_CKPT   = {BRATS21_SCRATCH_CKPT}")
    print(f"  MSD_LUNG_SCRATCH_CKPT  = {MSD_LUNG_SCRATCH_CKPT}")

    if args.run:
        exp = scratch_msd_lung()
        exp.epochs = args.epochs
        exp.name = f"smoketest_scratch_msd_lung_epochs{args.epochs}"
        exp.out_dir_root = "runs_smoketest"
        print(f"\n>> running smoke test: {exp.name}")
        exp.run()
        print(f">> smoke test done. Checkpoints in {exp.out_dir_root}/{exp.name}/")


if __name__ == "__main__":
    main()
