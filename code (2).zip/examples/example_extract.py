"""Example: build a U-Net, load weights (optional), and pull the 7-layer
feature ladder on two probe volumes.

Requires MONAI + torch. Runs on GPU by default; will fall back to CPU
(slow -- 2-3 minutes) if no GPU is visible. Uses two BraTS-21 FLAIR probes
by default; substitute --probes-glob for MSD or QIN CT probes.

Run:
    cd deliverable/code
    python examples/example_extract.py                             # random init
    python examples/example_extract.py --ckpt <path/to/best.pt>    # load weights
"""
from __future__ import annotations
import sys, os, glob, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
from extract import (build_monai_unet, load_state, kaiming_init,
                      FeatureLadder, LADDER_NAMES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", default=None,
                    help="MONAI-UNet checkpoint; None => Kaiming-random init")
    ap.add_argument("--probes-glob", default=None,
                    help="glob for probe .nii.gz files. Default: 2 BraTS FLAIR volumes.")
    ap.add_argument("--layout", default="brats_flair",
                    choices=["brats_flair", "brats24_clean", "lgg", "msd", "qin", "rider"])
    ap.add_argument("--roi", type=int, nargs=3, default=(128, 128, 128))
    args = ap.parse_args()

    if args.probes_glob:
        probes = sorted(glob.glob(args.probes_glob))[:2]
    else:
        probes = sorted(glob.glob(
            "/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/"
            "BraTS2021_Training/BraTS2021_000[0-3]?/BraTS2021_000[0-3]?_flair.nii.gz"))[:2]
    if len(probes) < 1:
        raise SystemExit("no probes found -- pass --probes-glob to point at .nii.gz files")
    print(f"probes: {probes}")

    net = build_monai_unet(in_channels=1, out_channels=1)
    if args.ckpt:
        report = load_state(net, args.ckpt)
        print(f"[load_state] {report['loaded']}/{report['total']} params loaded from {args.ckpt}")
        if report['skipped']:
            print(f"  (first 5 skipped: {report['skipped'][:5]})")
    else:
        kaiming_init(net, seed=0)
        print("[init] Kaiming random init (seed 0)")

    # decide device
    import torch
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"device: {device}")

    ladder = FeatureLadder(net, device=device)
    feats = ladder.extract(probes, layout=args.layout, roi=tuple(args.roi),
                            in_channels=1, pool='gap')

    print("\nlayer                shape            mean       std")
    for L in LADDER_NAMES:
        m = feats[L]
        print(f"  {L:16s}   {str(m.shape):15s}  {m.mean():+.3f}   {m.std():.3f}")


if __name__ == "__main__":
    main()
