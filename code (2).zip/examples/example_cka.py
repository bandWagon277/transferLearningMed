"""Example: every metric in cka.py, on synthetic features.

Runs on CPU in a second. Confirms:
  - CKA(X, X) == 1
  - CKA(X, Y) < CKA(X, X) when Y is unrelated noise
  - Null-correction, bootstrap CI, and multi-metric audit all execute

Run:
    cd deliverable/code
    python examples/example_cka.py
"""
from __future__ import annotations
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
from cka import CKA, procrustes_shape_distance, rsa_spearman, \
                 jon_metric, orthohash_metric


def main():
    rng = np.random.default_rng(42)
    n_probes, d = 40, 128

    X = rng.standard_normal((n_probes, d))
    # Y_related shares row-structure with X; Y_noise is independent.
    Y_related = 0.7 * X + 0.3 * rng.standard_normal((n_probes, d))
    Y_noise   = rng.standard_normal((n_probes, d))

    # ---- 1) point CKA (feature form and gram form must agree) ----
    self_lin  = CKA.linear(X, X)
    self_gram = CKA.gram(X, X)
    print(f"CKA(X, X) linear form = {self_lin:.4f}  gram form = {self_gram:.4f}")
    assert abs(self_lin - 1.0)  < 1e-6
    assert abs(self_gram - 1.0) < 1e-6

    lin_rel  = CKA.linear(X, Y_related)
    lin_null = CKA.linear(X, Y_noise)
    print(f"CKA(X, related) = {lin_rel:.3f}   CKA(X, unrelated) = {lin_null:.3f}")
    assert lin_rel > lin_null

    # ---- 2) with_null: point + bootstrap CI + null-corrected R ----
    audit = CKA.with_null(X, Y_related, n_boot=200, n_perm=200, seed=0)
    print("with_null(X, Y_related) =")
    for k, v in audit.items():
        print(f"   {k}: {v}")

    # ---- 3) multi-metric audit (used in the 06-11 methodology table) ----
    combo = CKA.metric_audit(X, Y_related, n_boot=100, n_perm=100)
    print("\nmetric_audit(X, Y_related):")
    print(json.dumps({k: v if not isinstance(v, dict)
                       else {kk: round(vv, 4) if isinstance(vv, float) else vv
                             for kk, vv in v.items()}
                      for k, v in combo.items()}, indent=2))

    # ---- 4) Procrustes, Spearman RSA, Jon-metric, OrthoHash ----
    print("\nprocrustes:", procrustes_shape_distance(X, Y_related))
    print("rsa       :", rsa_spearman(X, Y_related))
    print("jon       :", jon_metric(X, Y_related))
    print("orthohash :", orthohash_metric(X, Y_related))


if __name__ == "__main__":
    main()
