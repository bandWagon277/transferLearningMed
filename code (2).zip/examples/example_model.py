"""Example: build the project's MONAI 3D U-Net via model.MonaiUNet3D.

Runs on CPU in a few seconds -- no data, no training. Just constructs the
architecture, prints parameter count, and forwards a random tensor through
it to confirm shapes.

Run:
    cd deliverable/code
    python examples/example_model.py
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from model import MonaiUNet3D, build_segresnet, build_swinunetr


def main():
    # 1) The project default: 5-stage 3D U-Net, 1 input channel (FLAIR or CT),
    #    1 output channel (binary tumor), instance norm.
    factory = MonaiUNet3D(in_channels=1, out_channels=1,
                          channels=(32, 64, 128, 256, 512),
                          norm='instance')
    print(f"[MonaiUNet3D] {factory.parameter_count/1e6:.2f} M parameters")
    net = factory.build().eval()

    # 2) Forward-pass a random 128^3 tensor and confirm shapes match.
    x = torch.randn(1, 1, 128, 128, 128)
    with torch.no_grad():
        y = net(x)
    print(f"[forward] input  {tuple(x.shape)}  ->  output {tuple(y.shape)}")
    assert y.shape == (1, 1, 128, 128, 128), y.shape

    # 3) Confirm the norm swap works (batch vs instance).
    factory_bn = MonaiUNet3D(in_channels=1, out_channels=1, norm='batch')
    net_bn = factory_bn.build().eval()
    print(f"[MonaiUNet3D norm=batch] {sum(p.numel() for p in net_bn.parameters())/1e6:.2f} M params")

    # 4) The two auxiliary architectures (used only in the May-13 v1 multi-
    #    region BraTS comparison; kept for provenance).
    seg = build_segresnet(in_channels=4, out_channels=3)
    print(f"[SegResNet 4->3]         {sum(p.numel() for p in seg.parameters())/1e6:.2f} M params")
    swin = build_swinunetr(in_channels=4, out_channels=3)
    print(f"[SwinUNETR 4->3]         {sum(p.numel() for p in swin.parameters())/1e6:.2f} M params")


if __name__ == "__main__":
    main()
