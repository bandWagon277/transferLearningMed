"""Example: render both figures from plotting.py against small synthetic JSONs.

Runs on CPU in < 5 seconds. Writes two PNGs into examples/out/:
  trajectory_grid_demo.png
  simulation_sweep_demo.png

Neither figure is meaningful -- the point is to confirm the calling shape
of plotting.trajectory_grid and plotting.simulation_sweep so someone can
swap in real JSONs from experiments.py output.

Run:
    cd deliverable/code
    python examples/example_plotting.py
"""
from __future__ import annotations
import sys, os, json, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from plotting import trajectory_grid, simulation_sweep


OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
os.makedirs(OUT_DIR, exist_ok=True)

LAYERS = ('L0_stem', 'L1_down', 'L2_down', 'L3_down',
          'L4_bottleneck', 'D1_up_outer', 'D2_up_inner')


def make_trajectory_json(path):
    epochs = [0, 5, 10, 15, 20, 25, 30]
    def series(offset, drop):
        return [{'epoch': e,
                 'cka_per_layer': {L: max(0.05, offset - drop * (i / max(len(LAYERS)-1, 1)))
                                    for i, L in enumerate(LAYERS)}}
                for e in epochs]
    data = {
        'runs': {
            'MSD->BraTS/full':    {'epochs': series(0.95, 0.35)},
            'MSD->BraTS/freeze1': {'epochs': series(0.98, 0.15)},
            'BraTS->MSD/full':    {'epochs': series(0.90, 0.55)},
            'random_init':        {'epochs': series(0.94, 0.05)},
        }
    }
    with open(path, 'w') as f:
        json.dump(data, f)


def make_simulation_json(path):
    cfg = {
        'input_kinds': ['iid_gauss', 'low_rank_gauss'],
        'norms':       ['in_affine_false', 'bn_eval', 'gn_8', 'none'],
        'depths':      [1, 2, 3, 5, 8],
        'n_probes':    [40, 200, 1000],
    }
    res = {}
    for kind in cfg['input_kinds']:
        for norm in cfg['norms']:
            for depth in cfg['depths']:
                tag = f'n=1000|kind={kind}|norm={norm}|depth={depth}'
                res[tag] = {}
                for lyr in range(depth):
                    # Deepest layer trends higher CKA; corrected R stays lower.
                    cka = 0.4 + 0.5 * (lyr + 1) / depth
                    R   = max(0.0, cka - (0.3 if norm == 'bn_eval' else 0.15))
                    res[tag][f'layer_{lyr}'] = {'cka_mean': cka, 'R_mean': R}
    with open(path, 'w') as f:
        json.dump({'config': cfg, 'results': res}, f)


def main():
    with tempfile.TemporaryDirectory() as tmp:
        traj_json = os.path.join(tmp, 'trajectory.json')
        sim_json  = os.path.join(tmp, 'simulation.json')
        make_trajectory_json(traj_json)
        make_simulation_json(sim_json)

        out_traj = os.path.join(OUT_DIR, 'trajectory_grid_demo.png')
        out_sim  = os.path.join(OUT_DIR, 'simulation_sweep_demo.png')
        trajectory_grid(traj_json, out_traj, layers=LAYERS,
                        title='trajectory_grid demo (synthetic JSON)')
        simulation_sweep(sim_json, out_sim)
        print(f"wrote {out_traj}")
        print(f"wrote {out_sim}")


if __name__ == "__main__":
    main()
