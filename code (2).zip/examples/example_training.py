"""Example: train a 3D U-Net via deliverable/code/training.py, either from
scratch or by fine-tuning from a source checkpoint.

Run from inside deliverable/code/ so the local imports resolve:

    cd deliverable/code
    python examples/example_training.py --mode scratch  \
        --out runs/msd_lung_scratch

    python examples/example_training.py --mode transfer \
        --out runs/msd_lung_from_brats21 \
        --pretrained /nfs/turbo/jiankanggroup/gengyh/transferMRI/code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt

The Trainer / TrainConfig / scratch() / transfer() surface is unchanged.
This file is a thin, single-CLI caller so a reviewer can see how each
argument maps to a hyperparameter.
"""
from __future__ import annotations
import sys, os, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from monai.data import Dataset
from torch.utils.data import DataLoader

from data     import MSDTask06Lung
from training import TrainConfig, scratch, transfer


def make_loaders(builder, fold: int, n_folds: int, batch_size: int):
    train_cases, val_cases = builder.fold_split(fold=fold, n_folds=n_folds)
    train_ds = Dataset(data=train_cases, transform=builder.train_transforms())
    val_ds   = Dataset(data=val_cases,   transform=builder.val_transforms())
    return (DataLoader(train_ds, batch_size=batch_size, shuffle=True,  num_workers=4),
            DataLoader(val_ds,   batch_size=1,         shuffle=False, num_workers=2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode",       choices=["scratch", "transfer"], required=True)
    ap.add_argument("--out",        required=True, help="output run dir")
    ap.add_argument("--pretrained", default=None,
                    help="source-ckpt for --mode transfer (path to .pt)")
    ap.add_argument("--fold",       type=int, default=0)
    ap.add_argument("--n-folds",    type=int, default=5)
    ap.add_argument("--epochs",     type=int, default=50)
    ap.add_argument("--freeze",     type=int, default=0,
                    help="0 = full fine-tune; 1 = encoder frozen; 2 = encoder + bottleneck frozen")
    args = ap.parse_args()

    # 1) Dataset side (data.py)
    builder = MSDTask06Lung(roi=(128, 128, 128))
    train_loader, val_loader = make_loaders(builder, args.fold, args.n_folds,
                                            batch_size=2)

    # 2) Training config (training.py)
    cfg = TrainConfig(
        out_dir       = args.out,
        epochs        = args.epochs,
        batch_size    = 2,
        lr            = 1e-4,
        weight_decay  = 1e-5,
        channels      = (32, 64, 128, 256, 512),
        in_channels   = builder.in_channels(),
        out_channels  = builder.out_channels(),
        norm          = "instance",
        ckpt_every    = 20,
        seed          = 42,
        amp           = True,
    )

    # 3) Build trainer
    if args.mode == "scratch":
        trainer = scratch(cfg, train_loader, val_loader)
    else:
        assert args.pretrained, "--pretrained is required for --mode transfer"
        trainer = transfer(cfg, train_loader, val_loader,
                           source_ckpt = args.pretrained,
                           freeze_depth = args.freeze)

    # 4) Train, validate every epoch, log to <out>/metrics.jsonl,
    #    save best.pt / last.pt / periodic checkpoints.
    trainer.fit()


if __name__ == "__main__":
    main()
