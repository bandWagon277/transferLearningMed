"""Example: enumerate cases and materialize one transformed volume per dataset.

Runs on CPU. Requires the datasets on disk under
/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/ (the default DATA_ROOT).
Loads exactly ONE case per dataset -- no training.

Run:
    cd deliverable/code
    python examples/example_data.py
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data import (BraTS2021FlairBinary, BraTS2024GLIClean,
                   MSDTask06Lung, QINLungCT)


def demo(builder):
    name = type(builder).__name__
    cases = builder.list_cases()
    print(f"\n=== {name} ===")
    print(f"  cases_root       : {builder.cases_root}")
    print(f"  n cases          : {len(cases)}")
    print(f"  in/out channels  : {builder.in_channels()} -> {builder.out_channels()}")
    if not cases:
        print("  (no cases found -- dataset not present)"); return

    # deterministic 5-fold split, fold 0
    train, val = builder.fold_split(fold=0, n_folds=5, seed=42)
    print(f"  fold 0/5         : train n={len(train)}  val n={len(val)}")
    print(f"  first train case : {train[0]['id']}")

    # apply the train transform pipeline to one case and print shapes
    tform = builder.train_transforms()
    out = tform(train[0])
    print(f"  transformed dict keys           : {list(out.keys())}")
    print(f"  image shape (C, D, H, W)         : {tuple(out['image'].shape)}")
    print(f"  label shape                      : {tuple(out['label'].shape)}")
    print(f"  image dtype / label unique       : {out['image'].dtype} / "
          f"{sorted(set(out['label'].unique().tolist()))[:5]}")


def main():
    demo(BraTS2021FlairBinary())
    demo(BraTS2024GLIClean())
    demo(MSDTask06Lung())
    demo(QINLungCT())


if __name__ == "__main__":
    main()
