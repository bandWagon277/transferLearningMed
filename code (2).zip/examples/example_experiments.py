"""Example: run each of the three experiment harnesses in experiments.py
on a small toy setup.

Runs on CPU (with a slow warning) or GPU. Uses:
  - EpochTrajectory     : two synthetic 'checkpoints' (Kaiming init w/ different
                          seeds) as if they were epochs of a fine-tune run.
  - PairwiseCKA         : two of those + one shared random-init as a third tag.
  - RandomNetSimulation : tiny sweep (iid_gauss only, 2 depths, 5 probes) to
                          confirm the harness works end-to-end.

The point is NOT to reproduce a paper number; it's to show the invocation
pattern so a user can swap in real checkpoints + real probes.

Run:
    cd deliverable/code
    python examples/example_experiments.py
"""
from __future__ import annotations
import sys, os, glob, tempfile, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from extract import build_monai_unet, kaiming_init
import extract
from experiments import (TrajectoryConfig, EpochTrajectory,
                          PairConfig, PairwiseCKA,
                          SimulationConfig, RandomNetSimulation)

# The production FeatureLadder defaults to device='cuda' and does not fall
# back automatically. For a smoke-test on a CPU-only node, monkey-patch its
# constructor to pick the right device.
if not torch.cuda.is_available():
    _orig_init = extract.FeatureLadder.__init__
    def _cpu_init(self, model, device='cpu'):
        _orig_init(self, model, device=device)
    extract.FeatureLadder.__init__ = _cpu_init
    print("[example] no CUDA -> forcing FeatureLadder to CPU")


def find_probes(n=2):
    """Grab N BraTS FLAIR probes if present; otherwise return synthetic paths."""
    return sorted(glob.glob(
        "/nfs/turbo/jiankanggroup/gengyh/transferMRI/data/"
        "BraTS2021_Training/BraTS2021_000[0-3]?/BraTS2021_000[0-3]?_flair.nii.gz"))[:n]


def write_toy_ckpts(dst_dir: str, n: int = 3):
    """Write n Kaiming-inited MONAI UNet state dicts as checkpoint_epoch_005.pt
    ...checkpoint_epoch_(5n).pt so EpochTrajectory finds them."""
    os.makedirs(dst_dir, exist_ok=True)
    for i in range(n):
        model = build_monai_unet(in_channels=1, out_channels=1)
        kaiming_init(model, seed=100 + i)
        epoch = 5 * (i + 1)
        path = os.path.join(dst_dir, f"checkpoint_epoch_{epoch:03d}.pt")
        torch.save({'state_dict': model.state_dict(), 'epoch': epoch}, path)
    return sorted(glob.glob(os.path.join(dst_dir, "checkpoint_epoch_*.pt")))


def demo_trajectory(probes):
    print("\n=== EpochTrajectory ===")
    with tempfile.TemporaryDirectory() as tmp:
        run_dir = os.path.join(tmp, "toy_run")
        ckpts = write_toy_ckpts(run_dir, n=3)
        print(f"  wrote {len(ckpts)} toy checkpoints to {run_dir}")
        # Use no source ckpt -> random init as the fixed reference.
        cfg = TrajectoryConfig(
            source_ckpt=None,
            target_run_dir=run_dir,
            probe_paths=probes,
            layout='brats_flair',
            roi=(96, 96, 96),
            channels=(32, 64, 128, 256, 512),
            random_seed=0,
        )
        trainer = EpochTrajectory(cfg)
        results = trainer.run()
        for epoch, per_layer in sorted(results.items()):
            print(f"  epoch {epoch}: " +
                  ", ".join(f"{L}={v:.3f}" for L, v in per_layer.items()))
        out_json = os.path.join(tmp, "trajectory.json")
        trainer.save(out_json)
        print(f"  saved {out_json} ({os.path.getsize(out_json)} bytes)")


def demo_pairwise(probes):
    print("\n=== PairwiseCKA ===")
    with tempfile.TemporaryDirectory() as tmp:
        write_toy_ckpts(tmp, n=2)
        ckpts = sorted(glob.glob(os.path.join(tmp, "checkpoint_epoch_*.pt")))
        cfg = PairConfig(
            ckpts={
                'seed100_ckpt': ckpts[0],
                'seed101_ckpt': ckpts[1],
                'random_init':  None,           # None => Kaiming init deterministic by tag hash
            },
            probe_paths=probes,
            layout='brats_flair',
            roi=(96, 96, 96),
            n_boot=50, n_perm=50,
        )
        harness = PairwiseCKA(cfg)
        pairs = harness.run()
        print(f"  computed {len(pairs)} (pair, layer) cells")
        for (a, b, L), rec in list(pairs.items())[:5]:
            print(f"  {a} vs {b} @ {L}: cka={rec['cka']:.3f}  R={rec['cka_null_corrected']:.3f}")
        out = os.path.join(tmp, "pairwise.json")
        harness.save(out)
        print(f"  saved {out}")


def demo_simulation():
    print("\n=== RandomNetSimulation ===")
    cfg = SimulationConfig(
        input_kinds=['iid_gauss'],
        norms=['in_affine_false', 'bn_eval'],
        depths=[1, 3],
        n_probes=[20],
        n_seeds=2,
        roi=(16, 16, 16),
    )
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    sim = RandomNetSimulation(cfg, device=device)
    # Trigger the run only if the harness exposes it publicly; otherwise
    # just report the config was constructed successfully.
    if hasattr(sim, 'run'):
        sim.run()
        n = len(sim.results)
        print(f"  ran {n} cells")
        for tag in list(sim.results)[:3]:
            print(f"  {tag}: {sim.results[tag]}")
    else:
        print("  (RandomNetSimulation.run() not implemented in this file version)")


def main():
    probes = find_probes(n=2)
    if not probes:
        print("no BraTS probes present under DATA_ROOT; example_experiments will still "
              "exercise the SimulationConfig path but skip real-probe demos")
    else:
        demo_trajectory(probes)
        demo_pairwise(probes)
    demo_simulation()


if __name__ == "__main__":
    main()
