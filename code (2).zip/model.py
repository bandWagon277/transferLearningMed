"""Model definitions used in the project.

There are two architectures. The actual implementation source for each one
is vendored under models/ in this folder, so the deliverable does not rely
on the external monai package or the cloned TransUNet repo to be readable.

models/monai_unet_source.py is the MONAI 3D U-Net definition that
MonaiUNet3D wraps. The factory call below imports monai.networks.nets.UNet
from the installed package so the construction goes through the
project-tested code path; the vendored file at
models/monai_unet_source.py is the exact source for reference.

models/transunet3d_model.py + vit_modeling.py + nnunet_generic_unet.py
contain the Generic_TransUNet_max_ppbp class, the ViT building blocks,
and the Generic_UNet used in the recipe-versus-architecture control. The
external clone at ../code/external/3D-TransUNet still owns the training
loop; this folder owns the architecture.
"""
from __future__ import annotations

from torch import nn


CHANNELS_DEFAULT = (32, 64, 128, 256, 512)


class MonaiUNet3D:
    """Thin factory around monai.networks.nets.UNet for the project default.

    The architecture is a 5-stage 3D U-Net with channels (32, 64, 128, 256,
    512), strides (2, 2, 2, 2), no residual units inside a stage, and a
    PReLU activation shared across blocks. Normalization defaults to
    InstanceNorm3d with affine disabled; the BatchNorm variant is used for
    the norm-comparison experiment in results.md.
    """

    def __init__(self, in_channels: int = 1, out_channels: int = 1,
                 channels: tuple[int, ...] = CHANNELS_DEFAULT,
                 norm: str = 'instance'):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.channels = channels
        self.norm = 'BATCH' if norm.lower() == 'batch' else 'INSTANCE'

    def build(self) -> nn.Module:
        from monai.networks.nets import UNet
        return UNet(
            spatial_dims=3,
            in_channels=self.in_channels,
            out_channels=self.out_channels,
            channels=self.channels,
            strides=(2, 2, 2, 2),
            num_res_units=0,
            norm=self.norm,
        )

    @property
    def parameter_count(self) -> int:
        model = self.build()
        return sum(p.numel() for p in model.parameters())


def build_segresnet(in_channels: int = 4, out_channels: int = 3,
                    init_filters: int = 16) -> nn.Module:
    """Used in the May-13 v1 multi-region BraTS comparison."""
    from monai.networks.nets import SegResNet
    return SegResNet(spatial_dims=3, in_channels=in_channels,
                     out_channels=out_channels, init_filters=init_filters)


def build_swinunetr(in_channels: int = 4, out_channels: int = 3,
                    img_size: tuple[int, int, int] = (128, 128, 128),
                    feature_size: int = 48) -> nn.Module:
    """Used in the May-13 v1 multi-region BraTS comparison."""
    from monai.networks.nets import SwinUNETR
    return SwinUNETR(img_size=img_size, in_channels=in_channels,
                     out_channels=out_channels, feature_size=feature_size)
