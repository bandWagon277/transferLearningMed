"""Feature extraction from MONAI 3D U-Net checkpoints.

Captures per-layer features at the seven-point ladder used throughout the
project: three encoder downsample blocks, the bottleneck, and two decoder
upsample blocks (plus the stem). Pooling defaults to spatial global average;
full-spatial flatten is available for n < 20 probes.
"""
from __future__ import annotations

import os
from typing import Iterable

import nibabel as nib
import numpy as np
import torch
from torch import nn


LADDER_NAMES = ('L0_stem', 'L1_down', 'L2_down', 'L3_down',
                'L4_bottleneck', 'D1_up_outer', 'D2_up_inner')


class FeatureLadder:
    """Hook the seven canonical ladder points on a MONAI UNet."""

    def __init__(self, model: nn.Module, device: str = 'cuda'):
        self.device = device
        self.model = model.eval().to(device)
        self._layer_modules = self._locate_ladder(model)
        if len(self._layer_modules) != len(LADDER_NAMES):
            raise RuntimeError(
                f'expected {len(LADDER_NAMES)} ladder points, '
                f'found {len(self._layer_modules)}')

    @staticmethod
    def _locate_ladder(model: nn.Module) -> dict[str, nn.Module]:
        # MONAI UNet builds nested Sequential(down, SkipConnection(sub), up).
        # SkipConnection exposes its nested block as .submodule (not by index).
        # The five-level ladder at channels (C, 2C, 4C, 8C, 16C):
        m = model.model
        ladder = {
            'L0_stem':        m[0],
            'L1_down':        m[1].submodule[0],
            'L2_down':        m[1].submodule[1].submodule[0],
            'L3_down':        m[1].submodule[1].submodule[1].submodule[0],
            'L4_bottleneck':  m[1].submodule[1].submodule[1].submodule[1],
            'D2_up_inner':    m[1].submodule[1].submodule[2],
            'D1_up_outer':    m[1].submodule[2],
        }
        return {name: ladder[name] for name in LADDER_NAMES}

    def extract(self, probe_paths: Iterable[str],
                layout: str = 'brats_flair',
                roi: tuple[int, int, int] = (128, 128, 128),
                pool: str = 'gap',
                in_channels: int = 1) -> dict[str, np.ndarray]:
        captured = {name: [] for name in self._layer_modules}
        handles = []
        for name, module in self._layer_modules.items():
            handles.append(module.register_forward_hook(self._make_hook(name, captured, pool)))
        with torch.no_grad():
            for p in probe_paths:
                arr = self._load_probe(p, layout, roi)
                x = torch.from_numpy(arr).float()[None, None].to(self.device)
                if in_channels > 1:
                    x = x.repeat(1, in_channels, 1, 1, 1)
                self.model(x)
        for h in handles:
            h.remove()
        return {name: np.stack(arrs, axis=0) for name, arrs in captured.items()}

    @staticmethod
    def _make_hook(name, captured, pool):
        def hook(_module, _inputs, output):
            if pool == 'gap':
                feat = output.mean(dim=tuple(range(2, output.ndim))).squeeze(0)
            elif pool == 'flatten':
                feat = output.reshape(-1)
            else:
                raise ValueError(f'unknown pool {pool!r}')
            captured[name].append(feat.detach().cpu().float().numpy())
        return hook

    @staticmethod
    def _load_probe(path: str, layout: str, roi) -> np.ndarray:
        arr = nib.load(path).get_fdata().astype(np.float32)
        if arr.ndim == 4:
            arr = arr[..., 0]
        if layout in ('brats_flair', 'lgg', 'brats24_clean'):
            # MRI: per-volume foreground z-score.
            mask = arr > 0
            if mask.any():
                arr = (arr - arr[mask].mean()) / (arr[mask].std() + 1e-6)
        elif layout in ('msd', 'qin', 'rider'):
            # CT: HU clip then min-max to [0, 1].
            arr = np.clip(arr, -1000.0, 300.0)
            arr = (arr + 1000.0) / 1300.0
        else:
            raise ValueError(
                f'unknown layout {layout!r}. Expected one of '
                f"brats_flair, brats24_clean, lgg, msd, qin, rider.")
        return FeatureLadder._center_crop_pad(arr, roi)

    @staticmethod
    def _center_crop_pad(arr: np.ndarray, roi) -> np.ndarray:
        for d in range(3):
            s, t = arr.shape[d], roi[d]
            if s >= t:
                start = (s - t) // 2
                arr = np.take(arr, range(start, start + t), axis=d)
            else:
                pad = (t - s) // 2
                pads = [(0, 0)] * 3
                pads[d] = (pad, t - s - pad)
                arr = np.pad(arr, pads)
        return arr.astype(np.float32)


def build_monai_unet(in_channels: int = 1, out_channels: int = 1,
                     channels=(32, 64, 128, 256, 512),
                     norm: str = 'instance'):
    """Convenience wrapper around model.MonaiUNet3D.build()."""
    from model import MonaiUNet3D
    return MonaiUNet3D(in_channels=in_channels, out_channels=out_channels,
                       channels=channels, norm=norm).build()


def load_state(model: nn.Module, ckpt_path: str) -> dict:
    """Load weights into model. Strips 'module.' DDP prefix on either side
    if necessary. Returns a load report with counts of loaded / skipped
    parameters so silent partial loads can be detected.
    """
    sd = torch.load(ckpt_path, map_location='cpu', weights_only=False)
    sd = sd.get('state_dict', sd) if isinstance(sd, dict) else sd
    target = model.state_dict()

    def strip(k):
        return k[7:] if k.startswith('module.') else k

    src_by_stripped = {strip(k): v for k, v in sd.items()}
    matched = {}
    for tgt_k, tgt_v in target.items():
        src_v = src_by_stripped.get(strip(tgt_k))
        if src_v is not None and src_v.shape == tgt_v.shape:
            matched[tgt_k] = src_v
    target.update(matched)
    model.load_state_dict(target)
    return {
        'loaded': len(matched),
        'total':  len(target),
        'skipped': [k for k in target if k not in matched],
    }


def kaiming_init(model: nn.Module, seed: int = 0) -> None:
    torch.manual_seed(int(seed))
    for p in model.parameters():
        if p.ndim > 1:
            torch.nn.init.kaiming_normal_(p)
    for m in model.modules():
        if isinstance(m, (nn.BatchNorm3d, nn.InstanceNorm3d, nn.GroupNorm, nn.LayerNorm)):
            if getattr(m, 'weight', None) is not None:
                torch.nn.init.ones_(m.weight)
            if getattr(m, 'bias', None) is not None:
                torch.nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Conv3d) and m.bias is not None:
            torch.nn.init.zeros_(m.bias)
