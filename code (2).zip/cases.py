"""Concrete training entry points for each experiment in the project.

Each Experiment instance pairs a target dataset, a source checkpoint (or
None for scratch), a freeze depth, and a fold index. The .run() method
trains the configured model and writes checkpoints under out_dir.

The named factories at the bottom (e.g. scratch_brats21, transfer_brats21_to_msd)
match the experiments described in models.md and results.md. The 3D
TransUNet experiments use a different trainer; see TRANSUNET.md in this
folder for how to invoke those.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

from monai.data import CacheDataset, DataLoader

from data import (DatasetBuilder, BraTS2021FlairBinary, BraTS2024GLIClean,
                  MSDTask06Lung, QINLungCT)
from training import TrainConfig, Trainer


@dataclass
class Experiment:
    """One transfer configuration. Construction is declarative; .run() trains.

    target:            the dataset to train on
    source_ckpt:       weights to initialize from (None for scratch)
    freeze_depth:      0 full FT, 1 encoder frozen, 2 encoder + bottleneck frozen
    fold:              fold index for K-fold patient split
    n_folds:           5 by default
    epochs:            50 by default
    out_dir_root:      checkpoints written to <out_dir_root>/<name>/
    name:              descriptive tag for the run
    """
    target: DatasetBuilder
    name: str
    source_ckpt: str | None = None
    freeze_depth: int = 0
    fold: int = 0
    n_folds: int = 5
    epochs: int = 50
    seed: int = 42
    batch_size: int = 2
    norm: str = 'instance'
    out_dir_root: str = 'pretrained_runs'

    def loaders(self):
        train_cases, val_cases = self.target.fold_split(
            self.fold, self.n_folds, self.seed)
        train_ds = CacheDataset(train_cases, transform=self.target.train_transforms(),
                                cache_rate=0.0, num_workers=4)
        val_ds = CacheDataset(val_cases, transform=self.target.val_transforms(),
                              cache_rate=0.0, num_workers=4)
        return (DataLoader(train_ds, batch_size=self.batch_size, shuffle=True,
                           num_workers=4, pin_memory=True),
                DataLoader(val_ds, batch_size=1, shuffle=False,
                           num_workers=4, pin_memory=True))

    def run(self):
        out_dir = os.path.join(self.out_dir_root, self.name)
        cfg = TrainConfig(
            out_dir=out_dir,
            epochs=self.epochs,
            batch_size=self.batch_size,
            in_channels=self.target.in_channels(),
            out_channels=self.target.out_channels(),
            freeze_depth=self.freeze_depth,
            pretrained_ckpt=self.source_ckpt,
            norm=self.norm,
            seed=self.seed,
        )
        train_loader, val_loader = self.loaders()
        Trainer(cfg, train_loader, val_loader).fit()


# ---------------------------------------------------------------------------
# Named factories — one per experimental cell that produced a Dice in
# results.md or a checkpoint that feeds a CKA comparison.
# ---------------------------------------------------------------------------

BRATS21_SCRATCH_CKPT = '/nfs/turbo/jiankanggroup/gengyh/transferMRI/code/pretrained/brats_flair_pretrain/brats_vanilla_v1/best.pt'
MSD_LUNG_SCRATCH_CKPT = '/nfs/turbo/jiankanggroup/gengyh/transferMRI/code/pretrained/oktaykurt_retrain/msd_lung_vanilla_kfold/fold0/best.pt'


def scratch_brats21(fold: int = 0, seed: int = 42,
                    norm: str = 'instance', epochs: int = 100) -> Experiment:
    return Experiment(
        target=BraTS2021FlairBinary(),
        name=f'brats21_scratch_fold{fold}_seed{seed}_norm{norm}',
        source_ckpt=None, freeze_depth=0,
        fold=fold, seed=seed, epochs=epochs, norm=norm,
    )


def scratch_msd_lung(fold: int = 0, seed: int = 42,
                     epochs: int = 100) -> Experiment:
    return Experiment(
        target=MSDTask06Lung(),
        name=f'msd_lung_scratch_fold{fold}_seed{seed}',
        source_ckpt=None, freeze_depth=0,
        fold=fold, seed=seed, epochs=epochs,
    )


def scratch_brats24_clean(fold: int = 0, seed: int = 42,
                          epochs: int = 50) -> Experiment:
    return Experiment(
        target=BraTS2024GLIClean(),
        name=f'brats24_scratch_fold{fold}',
        source_ckpt=None, freeze_depth=0,
        fold=fold, seed=seed, epochs=epochs,
    )


def transfer_brats21_to_brats24(fold: int = 0, freeze_depth: int = 0,
                                source_ckpt: str = BRATS21_SCRATCH_CKPT,
                                epochs: int = 50) -> Experiment:
    return Experiment(
        target=BraTS2024GLIClean(),
        name=f'brats21_to_brats24_fold{fold}_freeze{freeze_depth}',
        source_ckpt=source_ckpt, freeze_depth=freeze_depth,
        fold=fold, epochs=epochs,
    )


def transfer_brats21_to_msd_lung(fold: int = 0, freeze_depth: int = 0,
                                 source_ckpt: str = BRATS21_SCRATCH_CKPT,
                                 epochs: int = 100) -> Experiment:
    return Experiment(
        target=MSDTask06Lung(),
        name=f'brats21_to_msd_lung_fold{fold}_freeze{freeze_depth}',
        source_ckpt=source_ckpt, freeze_depth=freeze_depth,
        fold=fold, epochs=epochs,
    )


def transfer_msd_lung_to_brats21(fold: int = 0, freeze_depth: int = 0,
                                 source_ckpt: str = MSD_LUNG_SCRATCH_CKPT,
                                 epochs: int = 30) -> Experiment:
    return Experiment(
        target=BraTS2021FlairBinary(),
        name=f'msd_lung_to_brats21_fold{fold}_freeze{freeze_depth}',
        source_ckpt=source_ckpt, freeze_depth=freeze_depth,
        fold=fold, epochs=epochs,
    )
