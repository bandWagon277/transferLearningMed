"""Three experiment harnesses: epoch trajectory, similarity comparison,
and a simulation that sweeps random conv stacks across probe types.

Each entry point is a class with .run() and .save() methods. The intent is
that someone can re-derive every CKA number in the project from the three
classes here plus a checkpoint directory and a probe list.
"""
from __future__ import annotations

import glob
import json
import os
import re
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import torch
from torch import nn

from cka import CKA
from extract import FeatureLadder, build_monai_unet, kaiming_init, load_state, LADDER_NAMES


@dataclass
class TrajectoryConfig:
    source_ckpt: str | None        # None signals random-init with seed 0
    target_run_dir: str            # contains checkpoint_epoch_*.pt files
    probe_paths: list[str]
    layout: str = 'brats_flair'
    roi: tuple[int, int, int] = (128, 128, 144)
    channels: tuple[int, ...] = (32, 64, 128, 256, 512)
    in_channels: int = 1
    out_channels: int = 1
    random_seed: int = 0


class EpochTrajectory:
    """For each checkpoint in target_run_dir, compute layer-wise CKA against
    a fixed source. Returns dict keyed by epoch."""

    def __init__(self, cfg: TrajectoryConfig):
        self.cfg = cfg
        self.results: dict = {}

    def _build(self):
        return build_monai_unet(self.cfg.in_channels, self.cfg.out_channels,
                                self.cfg.channels)

    def _features(self, ckpt: str | None) -> dict[str, np.ndarray]:
        model = self._build()
        if ckpt is None:
            kaiming_init(model, seed=self.cfg.random_seed)
        else:
            load_state(model, ckpt)
        return FeatureLadder(model).extract(
            self.cfg.probe_paths, layout=self.cfg.layout,
            roi=self.cfg.roi, in_channels=self.cfg.in_channels)

    def run(self):
        feats_source = self._features(self.cfg.source_ckpt)
        ckpts = sorted(glob.glob(os.path.join(self.cfg.target_run_dir,
                                              'checkpoint_epoch_*.pt')))
        for ck in ckpts:
            m = re.match(r'checkpoint_epoch_0*(\d+)\.pt$', os.path.basename(ck))
            if not m:
                continue
            epoch = int(m.group(1))
            feats_t = self._features(ck)
            self.results[epoch] = {
                L: CKA.linear(feats_source[L], feats_t[L]) for L in feats_source
            }
        return self.results

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        with open(path, 'w') as f:
            json.dump({
                'source_ckpt': self.cfg.source_ckpt or 'random_init',
                'target_run_dir': self.cfg.target_run_dir,
                'n_probes': len(self.cfg.probe_paths),
                'roi': list(self.cfg.roi),
                'epochs': self.results,
            }, f, indent=2)


@dataclass
class PairConfig:
    ckpts: dict[str, str | None]   # tag -> ckpt path (None = random init)
    probe_paths: list[str]
    layout: str = 'brats_flair'
    roi: tuple[int, int, int] = (128, 128, 128)
    channels: tuple[int, ...] = (32, 64, 128, 256, 512)
    in_channels: int = 1
    out_channels: int = 1
    n_boot: int = 200
    n_perm: int = 200


class PairwiseCKA:
    """Compute null-corrected CKA across every ordered pair of provided
    checkpoints, on a shared probe set."""

    def __init__(self, cfg: PairConfig):
        self.cfg = cfg
        self.features: dict[str, dict[str, np.ndarray]] = {}
        self.pairs: dict[tuple[str, str], dict] = {}

    def _extract(self, tag: str):
        model = build_monai_unet(self.cfg.in_channels, self.cfg.out_channels,
                                 self.cfg.channels)
        ckpt = self.cfg.ckpts[tag]
        if ckpt is None:
            # Use a deterministic per-tag seed (Python's hash() is salted
            # at process start and is not stable across runs).
            seed = sum(ord(c) for c in tag) & 0xFFFF
            kaiming_init(model, seed=seed)
        else:
            load_state(model, ckpt)
        self.features[tag] = FeatureLadder(model).extract(
            self.cfg.probe_paths, layout=self.cfg.layout,
            roi=self.cfg.roi, in_channels=self.cfg.in_channels)

    def run(self):
        for tag in self.cfg.ckpts:
            self._extract(tag)
        tags = list(self.cfg.ckpts)
        for i, a in enumerate(tags):
            for b in tags[i+1:]:
                for L in LADDER_NAMES:
                    self.pairs[(a, b, L)] = CKA.with_null(
                        self.features[a][L], self.features[b][L],
                        n_boot=self.cfg.n_boot, n_perm=self.cfg.n_perm)
        return self.pairs

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        serial = {f'{a}__{b}__{L}': v for (a, b, L), v in self.pairs.items()}
        with open(path, 'w') as f:
            json.dump({'pairs': serial,
                       'n_probes': len(self.cfg.probe_paths)}, f, indent=2)


class RandomConvStack(nn.Module):
    """Conv3d-Norm-ReLU stack with configurable depth and norm.

    Used by the simulation. Not part of the production U-Net.
    """
    def __init__(self, in_ch=1, ch=32, depth=5, norm='in_affine_false'):
        super().__init__()
        layers = []
        prev = in_ch
        for _ in range(depth):
            block = [nn.Conv3d(prev, ch, kernel_size=3, padding=1)]
            if norm == 'in_affine_false':
                block.append(nn.InstanceNorm3d(ch, affine=False))
            elif norm == 'bn_eval':
                block.append(nn.BatchNorm3d(ch))
            elif norm == 'gn_8':
                block.append(nn.GroupNorm(8, ch))
            elif norm != 'none':
                raise ValueError(f'unknown norm {norm!r}')
            block.append(nn.ReLU(inplace=True))
            layers.append(nn.Sequential(*block))
            prev = ch
        self.layers = nn.ModuleList(layers)

    def forward(self, x):
        outs = []
        for layer in self.layers:
            x = layer(x)
            outs.append(x)
        return outs


@dataclass
class SimulationConfig:
    input_kinds: list[str] = field(default_factory=lambda: ['iid_gauss', 'low_rank_gauss', 'real_brats'])
    norms: list[str] = field(default_factory=lambda: ['in_affine_false', 'bn_eval', 'gn_8', 'none'])
    depths: list[int] = field(default_factory=lambda: [1, 2, 3, 5, 8, 12])
    n_probes: list[int] = field(default_factory=lambda: [40, 200, 1000])
    n_seeds: int = 5
    roi: tuple[int, int, int] = (32, 32, 32)
    real_brats_glob: str | None = None


class RandomNetSimulation:
    """Sweep input correlation, normalization, and depth through K random-init
    conv stacks; compute pairwise CKA and null-corrected R per cell."""

    def __init__(self, cfg: SimulationConfig, device: str = 'cuda'):
        self.cfg = cfg
        self.device = device
        self.results: dict = {}

    def _make_inputs(self, kind: str, n: int, seed: int = 42) -> np.ndarray:
        rng = np.random.default_rng(seed)
        roi = self.cfg.roi
        if kind == 'iid_gauss':
            return rng.standard_normal((n, 1, *roi)).astype(np.float32)
        if kind == 'low_rank_gauss':
            latent = rng.standard_normal((n, 8))
            basis = rng.standard_normal((8, int(np.prod(roi))))
            return (latent @ basis).reshape(n, 1, *roi).astype(np.float32)
        if kind == 'real_brats':
            if not self.cfg.real_brats_glob:
                raise ValueError('real_brats requires cfg.real_brats_glob')
            import nibabel as nib
            cases = sorted(glob.glob(self.cfg.real_brats_glob))
            idx = rng.permutation(len(cases))[:n]
            arrs = []
            for i in idx:
                x = nib.load(cases[i]).get_fdata().astype(np.float32)
                arrs.append(FeatureLadder._center_crop_pad(x, roi)[None])
            return np.stack(arrs).astype(np.float32)
        raise ValueError(f'unknown input kind {kind!r}')

    def _features(self, model, X: np.ndarray) -> dict[int, np.ndarray]:
        model.eval().to(self.device)
        bufs = None
        with torch.no_grad():
            for i in range(X.shape[0]):
                x = torch.from_numpy(X[i:i+1]).to(self.device)
                outs = model(x)
                if bufs is None:
                    bufs = [[] for _ in outs]
                for j, o in enumerate(outs):
                    feat = o.mean(dim=tuple(range(2, o.ndim))).squeeze(0)
                    bufs[j].append(feat.cpu().numpy().astype(np.float32))
        return {j: np.stack(bufs[j], axis=0) for j in range(len(bufs))}

    def run(self):
        import itertools
        for n in self.cfg.n_probes:
            for kind in self.cfg.input_kinds:
                try:
                    X = self._make_inputs(kind, n)
                except Exception as e:
                    print(f'  skip kind={kind!r} n={n}: {e}')
                    continue
                for norm in self.cfg.norms:
                    for depth in self.cfg.depths:
                        tag = f'n={n}|kind={kind}|norm={norm}|depth={depth}'
                        print(tag, flush=True)
                        per_seed = []
                        for s in range(self.cfg.n_seeds):
                            m = RandomConvStack(in_ch=1, ch=32, depth=depth, norm=norm)
                            kaiming_init(m, seed=s)
                            per_seed.append(self._features(m, X))
                            del m
                            if self.device == 'cuda':
                                torch.cuda.empty_cache()
                        per_layer = {}
                        for L in range(depth):
                            ckas, R_vals = [], []
                            for a, b in itertools.combinations(range(self.cfg.n_seeds), 2):
                                st = CKA.with_null(
                                    per_seed[a][L], per_seed[b][L],
                                    n_boot=50, n_perm=100, seed=a * 100 + b)
                                ckas.append(st['cka'])
                                R_vals.append(st['cka_null_corrected'])
                            per_layer[f'layer_{L}'] = {
                                'cka_mean': float(np.mean(ckas)),
                                'cka_std': float(np.std(ckas)),
                                'R_mean': float(np.mean(R_vals)),
                                'R_std': float(np.std(R_vals)),
                            }
                        self.results[tag] = per_layer
        return self.results

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        with open(path, 'w') as f:
            json.dump({'config': self.cfg.__dict__, 'results': self.results},
                      f, indent=2)
